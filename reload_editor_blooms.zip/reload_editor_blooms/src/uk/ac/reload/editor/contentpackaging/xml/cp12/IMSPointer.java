/**
 *  Content Re-Engineerng Tool
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Roy P Cherian
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Roy P Cherian
 *  e-mail:   rc3@bolton.ac.uk
 *
 *
 */
package uk.ac.reload.editor.contentpackaging.xml.cp12;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.jdom.Element;
import org.jdom.Namespace;
import org.jdom.input.DOMBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import uk.ac.reload.diva.util.GeneralUtils;

public class IMSPointer {
    private static final String IDENTIFIER = "identifier";

    private static final String IDENTIFIERREF = "identifierref";

    private static final String MANIFEST = "manifest";
    private static final String RESOURCE = "resource";

    private static final String RESOURCES = "resources";

    private static final String HREF = "href";

    public static final String FILE = "file";

    private static Namespace cp12NS = Namespace.getNamespace("",
            "http://www.imsglobal.org/xsd/imscp_v1p1");

    private String urlStr;

    private String xpathStr;

    private File fileURLBase;

    private List resourceElements;

    private List remoteElements;

    private org.jdom.Document remoteDocument;

    private static Hashtable resolvedIMSPtrs = new Hashtable();

    public IMSPointer(String pntrstring) {
        // TODO Auto-generated constructor stub
        String[] strs = pntrstring.split("#");
        if (strs.length > 1) {
            urlStr = strs[0];
            xpathStr = strs[1];
        }
        resourceElements = new ArrayList();
        remoteElements = new ArrayList();
    }

    public IMSPointer(String value, File baseFolder) {
        // TODO Auto-generated constructor stub
        this(value);
        fileURLBase = baseFolder;

    }

    /**
     * Returns the element at the remote link 
     * @param pntrstring
     * @param file
     * @return
     */
    public static IMSPointer getIMSPointer(String pntrstring, File file) {

        IMSPointer remotePtr = (IMSPointer) resolvedIMSPtrs.get(pntrstring);
        if (remotePtr == null) {
            remotePtr = new IMSPointer(pntrstring, file);
            if (remotePtr != null)
                resolvedIMSPtrs.put(pntrstring, remotePtr);
        }
        return remotePtr;
    }

    /**
     * 
     * @param pntrstring 
     * @return NodeSet
     */

    public void buildElementLst() {
        URL url = null;
        NodeList nodeLst = null;
        try {
            if (urlStr.indexOf("http") == -1) {
                // file URL
                File file = new File(fileURLBase, urlStr);
                if (file.exists()) {
                    url = file.toURL();
                }
            } else {
                // proper URL ?
                url = new URL(urlStr);

            }
        } catch (MalformedURLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        if (url != null) {
            XPath xpath = XPathFactory.newInstance().newXPath();
            BufferedReader in;
            try {
                in = new BufferedReader(new InputStreamReader(url.openStream()));
                InputSource inputSource = new InputSource(in);
                //xpointer(........)
                String xpathstr1 = xpathStr.substring(9, xpathStr.length() - 1);
                DocumentBuilder builder = DocumentBuilderFactory.newInstance()
                        .newDocumentBuilder();
                Document document = builder.parse(inputSource);
                nodeLst = (NodeList) xpath.evaluate(xpathstr1, document,
                        XPathConstants.NODESET);
                DOMBuilder domBuildr = new DOMBuilder();
                remoteDocument = domBuildr.build(document);

            } catch (XPathExpressionException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (IOException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            } catch (Exception e) {
                // TODO: handle exception
            }

        }

        if (nodeLst == null) {
            return;
        }

        // the following is to stop adding an element and it child elements the list
        //XPath is returning all

        for (int i = 0; i < nodeLst.getLength();) {
            org.w3c.dom.Element domElmnt = (org.w3c.dom.Element) nodeLst
                    .item(i++);
            if (!isParentinNodeLst(nodeLst, domElmnt)) {
                DOMBuilder buildr = new DOMBuilder();
                Element elmnt = buildr.build(domElmnt);
                elmnt.detach();
                removeEmptyNSOfChildren(elmnt);
                if(elmnt.getName().equals(RESOURCE) || (elmnt.getName().equals(MANIFEST))) {
                    updateFileHREFs(elmnt);
                }
                remoteElements.add(elmnt);

            }

        }

    }

    /**
     * Remove Empty xmlns="" stuff from detached elements
     * 
     * @param current
     */
    public static void removeEmptyNSOfChildren(Element current) {

        if (current.getNamespace().getURI().equals("")) {
            current.setNamespace(cp12NS);
        }
        List children = current.getChildren();
        Iterator iterator = children.iterator();
        while (iterator.hasNext()) {
            Element child = (Element) iterator.next();
            removeEmptyNSOfChildren(child);
        }

    }

    /**
     * check whether the node's parent is already in the list
     * @param nodeLst
     * @param node
     * @return
     */

    boolean isParentinNodeLst(NodeList nodeLst, Node node) {
        for (int i = 0; i < nodeLst.getLength();) {
            if (nodeLst.item(i++).equals(node.getParentNode()))
                return true;
        }
        return false;
    }

    /**
     * Add to the resource list elements that are IDREF'd by this element
     */

    private void buildResourceList() {
        // TODO Auto-generated method stub
        Element manifest = remoteDocument.getRootElement();
        if (manifest == null) {
            return;
        }
        // Search the Resources first
        Element resource = remoteDocument.getRootElement().getChild(RESOURCES,
                remoteDocument.getRootElement().getNamespace());
        if (resource == null) {
            return;
        }
        List list = resource.getChildren(RESOURCE, resource.getNamespace());

        for (Iterator iter = remoteElements.iterator(); iter.hasNext();) {
            Element elmnt = (Element) iter.next();
            if(!elmnt.getName().equals(MANIFEST)) {
                buildResourceList(elmnt, list);
            }
        }

    }

    /**
     * Build a list of resouce elements referred by this element el
     * @param el
     */
    private void buildResourceList(Element el, List resList) {
        String idref = el.getAttributeValue(IDENTIFIERREF);
        if (idref != null) {
            for (Iterator iter1 = resList.iterator(); iter1.hasNext();) {
                Element resElement = (Element) iter1.next();
                String id = resElement.getAttributeValue(IDENTIFIER);
                if (id != null) {
                    if (idref.equals(id)) {
                        Element resourceElement = (Element) resElement.clone();
                        //Element resourceElement = (Element)resElement.detach();
                        updateFileHREFs(resourceElement);
                        resourceElements.add(resourceElement.detach());
                    }
                }

            }

        }
        List children = el.getChildren();
        Iterator iterator = children.iterator();
        while (iterator.hasNext()) {
            Element child = (Element) iterator.next();
            buildResourceList(child, resList);
        }

    }

    private void updateFileHREFs(Element resourceElement) {
        // TODO Auto-generated method stub
        if((resourceElement.getName().equals(FILE))||(resourceElement.getName().equals(RESOURCE))) {
        String href = resourceElement.getAttributeValue(HREF);

        // Some people use backslashes  :-(
        if (href != null) {
            href = href.replace('\\', '/');
        }

        if (href != null && GeneralUtils.isExternalURL(href) == false) {
            String baseURLStr = urlStr.substring(0, urlStr.lastIndexOf("/"));
            if (baseURLStr != null) {
                href = baseURLStr + File.separatorChar + href;
                resourceElement.setAttribute(HREF, href);
            }
        }
        }

        //List fileElements = resourceElement.getChildren(FILE, resourceElement
         //       .getNamespace());
        List fileElements = resourceElement.getChildren();
        Iterator iterator = fileElements.iterator();
        while (iterator.hasNext()) {
            Element child = (Element) iterator.next();
            updateFileHREFs(child);
        }

    }

    /**
     * 
     * @return
     */
    public org.jdom.Document getRemoteDocument() {
        return remoteDocument;
    }

    /**
     * 
     * @return
     */
    public List getRemoteElements() {
        if (remoteElements.size() == 0) {
            buildElementLst();
        }
        return remoteElements;
    }

    /**
     * 
     * @return
     */
    public List getResourceElements() {
        if (resourceElements.size() == 0) {
            buildResourceList();
        }
        return resourceElements;
    }

}
