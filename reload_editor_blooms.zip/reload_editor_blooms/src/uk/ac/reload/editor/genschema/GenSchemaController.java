/**
 *  RELOAD TOOLS
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Phillip Beauvoir
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Phillip Beauvoir
 *  e-mail:   p.beauvoir@bolton.ac.uk
 *
 *  Web:      http://www.reload.ac.uk
 *
 */
package uk.ac.reload.editor.genschema;

import java.io.File;
import java.io.IOException;
import java.net.URL;

import javax.swing.Icon;

import org.jdom.JDOMException;
import org.jdom.Namespace;

import uk.ac.reload.dweezil.util.DweezilUIManager;
import uk.ac.reload.editor.IIcons;
import uk.ac.reload.editor.gui.TreeIconInterface;
import uk.ac.reload.moonunit.ProfiledSchemaController;
import uk.ac.reload.moonunit.schema.SchemaException;
import uk.ac.reload.moonunit.schema.SchemaModel;
import uk.ac.reload.moonunit.schema.SchemaNode;


/**
 * Schema controller for local non ims  schemas 
 */
public class GenSchemaController extends ProfiledSchemaController implements
TreeIconInterface, IIcons {
    
    String root;
    String version ="";
    File schemaFile;
    String schemaUrl; // for cases when schemalocation is referring to http locations
  
       
    /**
	 * Default Profile
	 */
	public static String defaultProfile = "Generic Profile";
    
    /**
     * 
     * @param file
     * @throws SchemaException
     * @throws IOException
     * @throws JDOMException
     */
    
    public GenSchemaController(File file) throws JDOMException, SchemaException, IOException {
        super();
        schemaFile = file;
        version=""; //$NON-NLS-1$
    }
    
   /**
    * 
    * @param model
    * @throws JDOMException
    * @throws SchemaException
    * @throws IOException
    */
    
    public GenSchemaController(SchemaModel model) throws JDOMException, SchemaException, IOException {
        super(model);
        version=model.getVersion();
        root = model.getRootElementName();
    }
    
    /**
     * 
     * @param file
     * @param root
     * @throws SchemaException
     * @throws IOException
     * @throws JDOMException
     */
    
    public GenSchemaController(File file, String root) throws JDOMException, SchemaException, IOException {
        super(file.getAbsolutePath(), file, root);
        schemaFile = file;
        this.root = root;
        //loadSchemaModel(root);
        version=getSchemaModel().getVersion();
    }
    
    /**
     * @param schema version
     * @param file
     * @param root
     * @throws SchemaException
     * @throws IOException
     * @throws JDOMException
     */
    
    public GenSchemaController(String version, File file, String root) throws JDOMException, SchemaException, IOException {
       //super("", file, root);
        //super(version, file.toURL(), root);
        super(version, file, root);
        schemaFile = file;
        this.root = root;
        this.version = version;
        
    }
    
    /**
     * 
     * @param url
     * @param root
     * @throws SchemaException
     * @throws IOException
     * @throws JDOMException
     */
    
    public GenSchemaController(URL url, String root) throws JDOMException, SchemaException, IOException {
        //super();
        super(url.toString(), url, root);
        schemaUrl = url.toString();
        this.root = root;
        //loadSchemaModel(root, url);
        //version=""; //$NON-NLS-1$
        version = getSchemaModel().getVersion();
    }
    
    
    /**
     * Load in the SchemaModel as determined by getSchemaFile() and getRootElementName().
     * If the SchemaModel has already been set and loaded, nothing happens.
     * @throws SchemaException
     * @throws IOException
     */
    public void loadSchemaModel(String rootName) throws SchemaException, IOException {
        // a temp work around for until decided about versions
        if(version == null){
            SchemaModel sm = new SchemaModel(getSchemaFile(), rootName);            
            version = SchemaModel.getCurrentVerison();
            setSchemaModel(sm);
            } else {
                //added on 24/04
                setSchemaModel(SchemaModel.getSchemaModel(getSchemaFile()
                    .getAbsolutePath(), getSchemaFile(), rootName));
          
        }
        
    }
    
    
   
    public void loadSchemaModel(String rootName, URL url) throws SchemaException, IOException {
        // a temp work around for until decided about versions
        if(version == null){
            SchemaModel sm = new SchemaModel(url, rootName);
            //FIXME
            version = SchemaModel.getCurrentVerison();
            setSchemaModel(sm);
            } else {
                //added on 24/04
                setSchemaModel(SchemaModel.getSchemaModel(getSchemaFile()
                    .getAbsolutePath(), getSchemaFile(), rootName));
          
        }
        
    }
    
    /**
     * 
     */
    public String getVersion() {
        return version;
        
    }
    
    
    /**
     * 
     */
    public String getRootElementName() {
        return root;
        
    }
    
    /**
     * 
     */
    public File getSchemaFile() {        
            return schemaFile;
    }
  
    
    /* (non-Javadoc)
     * @see uk.ac.reload.moonunit.SchemaController#getDefaultValue(uk.ac.reload.moonunit.schema.SchemaNode)
     */
    public String getDefaultValue(SchemaNode schemaNode) {
        // TODO Auto-generated method stub
        return super.getDefaultValue(schemaNode);
    }
    /**
     * Get The Leaf Icon
     */
    public Icon getLeafIcon(String name, Namespace ns) {
        if(name.equals(getRootElementName())) {
            return DweezilUIManager.getIcon(ICON_MD);
        }
        return DweezilUIManager.getIcon(ICON_MDLEAF);
    }
    
    /**
     * Get The Open Icon
     */
    public Icon getOpenIcon(String name, Namespace ns) {
        if(name.equals(getRootElementName())) {
            return DweezilUIManager.getIcon(ICON_MD);
        }
        return DweezilUIManager.getIcon(ICON_MDFOLDER);
    }
    
    /**
     * Get The Closed Icon
     */
    public Icon getClosedIcon(String name, Namespace ns) {
        return getOpenIcon(name, ns);
    }
    
  
    public String getSchemaUrl() {
        return schemaUrl;
    }
    
  

/* (non-Javadoc)
 * @see uk.ac.reload.moonunit.ProfiledSchemaController#getProfileFolder()
 */
public File getProfileFolder() {
    // TODO Auto-generated method stub
    return GenSchemaEditorHandler.PROFILE_FOLDER;
}

/* (non-Javadoc)
 * @see uk.ac.reload.moonunit.ProfiledSchemaController#getDefaultProfileName()
 */
public String getDefaultProfileName() {
    // TODO Auto-generated method stub
    return defaultProfile;
}

/* (non-Javadoc)
 * @see uk.ac.reload.moonunit.ProfiledSchemaController#getSchemaHelperFolder()
 */
public File getSchemaHelperFolder() {
    // TODO Auto-generated method stub
    return GenSchemaEditorHandler.SCHEMAHELPER_FOLDER;
}

/* (non-Javadoc)
 * @see uk.ac.reload.moonunit.ProfiledSchemaController#getVocabFolder()
 */
public File getVocabFolder() {
    // TODO Auto-generated method stub
    return GenSchemaEditorHandler.VOCAB_FOLDER;
}

}
