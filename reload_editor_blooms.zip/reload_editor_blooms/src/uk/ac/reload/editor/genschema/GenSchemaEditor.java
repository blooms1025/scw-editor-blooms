/**
 *  Content Re-Engineerng Tool
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Roy P Cherian
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Roy P Cherian
 *  e-mail:   rc3@bolton.ac.uk
 *
 *
 */
package uk.ac.reload.editor.genschema;


import uk.ac.reload.dweezil.gui.DweezilFileChooser;
import uk.ac.reload.dweezil.gui.DweezilProgressMonitor;
import uk.ac.reload.jdom.XMLDocument;
import uk.ac.reload.dweezil.gui.ErrorDialogBox;

import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.JTabbedPane;

import uk.ac.reload.jdom.XMLDocumentListener;
import uk.ac.reload.editor.EditorFrame;
import uk.ac.reload.editor.EditorHandler;
import uk.ac.reload.editor.EditorInternalFrame;
import uk.ac.reload.editor.IIcons;
import uk.ac.reload.editor.Messages;

import javax.swing.SwingUtilities;
import uk.ac.reload.dweezil.menu.ProxyAction;
import uk.ac.reload.dweezil.menu.MenuAction;
import uk.ac.reload.editor.menu.MainMenu;
import uk.ac.reload.editor.metadata.editor.formPlus.CVDocValidator;

import java.io.IOException;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.InternalFrameEvent;
import uk.ac.reload.dweezil.menu.DweezilMenuEvent;
import uk.ac.reload.dweezil.util.DweezilUIManager;

import javax.swing.event.InternalFrameAdapter;
import uk.ac.reload.dweezil.gui.DweezilFileFilter;
import java.io.File;
import uk.ac.reload.jdom.XMLDocumentListenerEvent;
/**
 * Editor for editing non-ims local schema instances
 */
public class GenSchemaEditor extends EditorInternalFrame implements
        XMLDocumentListener, IIcons {

    /**
     * The Schema Instance Editor Panel
     */
    private GenSchemaEditorPanel _sdEditorPanel;

    /**
     * Handles Save and SaveAs Events
     */
    private ProxySaveHandler _saveHandler, _saveAsHandler;
    private ProxyValidationHandler _validationHandler;

    /**
     * Constructor
     */
    public GenSchemaEditor() {
        super(Messages.getString("GenSchemaEditor.0"), ICON_MD); //$NON-NLS-1$

        // Ensure we handle closing
        setDefaultCloseOperation(JInternalFrame.DO_NOTHING_ON_CLOSE);

        // We listen for what this frame is doing
        addInternalFrameListener(new InternalFrameAdapter() {
            // The Frame is closing
            public void internalFrameClosing(InternalFrameEvent e) {
                // Make sure button stuff is completed
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        checkNeedsSaving();
                    }
                });
            }

            // The Frame is activated
            public void internalFrameActivated(InternalFrameEvent e) {
                setFocusGained();
            }

            // The Frame is deactivated
            public void internalFrameDeactivated(InternalFrameEvent e) {
                setFocusLost();
            }
        });

        // New editor panel
        _sdEditorPanel = new GenSchemaEditorPanel(
                MainMenu.getSharedInstance().editMenu);

        getContentPane().add(_sdEditorPanel);

    }

    /**
     * New Metadata Editor
     * @param md
     */
    public GenSchemaEditor(GenMetadata md) {
        this();

        if (md.getFile() == null) {
            setTitle(Messages.getString("GenSchemaEditor.0") + " - " + Messages.getString("uk.ac.reload.editor.metadata.MD_Editor.1")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
        } else {
            setTitle("Schema Instance " + " - " + md.getFile().getPath()); //$NON-NLS-1$ //$NON-NLS-2$
        }

        // Load
        _sdEditorPanel.setDocument(md);

        // Document listener
        md.addXMLDocumentListener(this);

        // Proxy Save Handlers
        _saveHandler = new ProxySaveHandler(
                MainMenu.getSharedInstance().actionSave);
        _saveAsHandler = new ProxySaveHandler(
                MainMenu.getSharedInstance().actionSaveAs);
        _validationHandler = new ProxyValidationHandler();
        addTabListener();
    }

 
    /**
     * Over-ride this so we can set view stuff
     */
    public void show() {
        super.show();
        _sdEditorPanel.initView();
    }

    // =============================================================================
    // Document Listener Events so we know when to set Save Menu
    // =============================================================================

    public void elementAdded(XMLDocumentListenerEvent e) {
        if (isSelected()) {
            _saveHandler.setEnabled(_sdEditorPanel.getMetadata().isDirty());
        }
    }

    public void elementChanged(XMLDocumentListenerEvent e) {
        if (isSelected()) {
            _saveHandler.setEnabled(_sdEditorPanel.getMetadata().isDirty());
        }
    }

    public void elementRemoved(XMLDocumentListenerEvent e) {
        if (isSelected()) {
            _saveHandler.setEnabled(_sdEditorPanel.getMetadata().isDirty());
        }
    }

    public void documentSaved(XMLDocument doc) {
        if (isSelected()) {
            _saveHandler.setEnabled(_sdEditorPanel.getMetadata().isDirty());
        }
    }

    // =============================================================================
    // Focus Handler
    // =============================================================================

    /**
     * We got the focus
     */
    protected void setFocusGained() {
        if (_sdEditorPanel.getMetadata() != null) {
            _sdEditorPanel.getUndoManager().setFocusGained();

            _saveHandler.setEnabled(_sdEditorPanel.getMetadata().isDirty());
            _saveHandler.addListener();

            _saveAsHandler.setEnabled(true);
            _saveAsHandler.addListener();
            if(_sdEditorPanel.getTabPane().getSelectedIndex() == 0){
                _validationHandler.setEnabled(true);
                _validationHandler.addListener();
            }
            

        }
    }

    /**
     * We lost the focus
     */
    protected void setFocusLost() {
        _sdEditorPanel.getUndoManager().setFocusLost();

        _saveHandler.setEnabled(false);
        _saveHandler.removeListener();

        _saveAsHandler.setEnabled(false);
        _saveAsHandler.removeListener();
        
    	// added for Telcert
		_validationHandler.clear();
    }

    // =============================================================================
    // Window Closing, Cleanup and Saving Handlers
    // =============================================================================

    /**
     * We have been told by the Application that it is closing.
     * Here we can save if need be.
     * @return true if all is OK, false if not.
     */
    public boolean applicationClosing() {
        return checkNeedsSaving();
    }

    /**
     * We can check if the File needs saving
     * @return true if all is OK, false if not.
     */
    protected boolean checkNeedsSaving() {
        boolean isOK = true;

        GenMetadata md = _sdEditorPanel.getMetadata();

        if (md != null && md.isDirty()) {
            File file = md.getFile();
            String msg;
            if (file != null) {
                msg = file.getName()
                        + " " + Messages.getString("uk.ac.reload.editor.metadata.MD_Editor.2"); //$NON-NLS-1$ //$NON-NLS-2$
            } else {
                msg = Messages
                        .getString("uk.ac.reload.editor.metadata.MD_Editor.3"); //$NON-NLS-1$
            }

            int doSave = JOptionPane
                    .showConfirmDialog(
                            this,
                            msg
                                    + " " + //$NON-NLS-1$
                                    Messages
                                            .getString("uk.ac.reload.editor.metadata.MD_Editor.4"), //$NON-NLS-1$
                            Messages
                                    .getString("uk.ac.reload.editor.metadata.MD_Editor.5"), //$NON-NLS-1$
                            JOptionPane.YES_NO_CANCEL_OPTION);

            if (doSave == JOptionPane.YES_OPTION) {
                isOK = saveDocument();
            } else if (doSave == JOptionPane.CANCEL_OPTION) {
                isOK = false;
            }
        }

        if (isOK) {
            dispose();
        }

        return isOK;
    }

    /**
     * Dispose of this Window and clean up
     */
    public void dispose() {
        try {
            // Have to check for nulls.  Since launching this Editor is on a thread,
            // if user closes the app before this window appears then these objects will be null

            if (_saveHandler != null) {
                _saveHandler.removeListener();
            }

            if (_saveAsHandler != null) {
                _saveAsHandler.removeListener();
            }

            if (_sdEditorPanel != null) {
                GenMetadata md = _sdEditorPanel.getMetadata();
                if (md != null) {
                    md.removeXMLDocumentListener(this);
                }
                _sdEditorPanel.destroy();
            }

            super.dispose();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * If the Metadata file has been edited, ask whether we should save it
     * @return true if OK, false if not
     */
    protected boolean saveDocument() {
        // If we don't have a file name, ask for one
        if (_sdEditorPanel.getMetadata().getFile() == null) {
            return saveAsDocument();
        }

        try {
            _sdEditorPanel.getMetadata().saveDocument();
        } catch (IOException ex) {
            ErrorDialogBox
                    .showWarning(
                            this,
                            Messages
                                    .getString("uk.ac.reload.editor.metadata.MD_Editor.6"), //$NON-NLS-1$
                            Messages
                                    .getString("uk.ac.reload.editor.metadata.MD_Editor.5"), ex); //$NON-NLS-1$
            return false;
        }
        return true;
    }

    /**
     * Save As...
     * @return true if OK
     */
    protected boolean saveAsDocument() {
        // Ask for name
        DweezilFileFilter filter = new DweezilFileFilter(
                new String[] { "xml" }, "xml files"); //$NON-NLS-1$ //$NON-NLS-2$
        File file = DweezilFileChooser
                .askFileNameSave(
                        this,
                        Messages
                                .getString("uk.ac.reload.editor.metadata.MD_Editor.5"), filter, "xml"); //$NON-NLS-1$ //$NON-NLS-2$
        // User cancelled
        if (file == null)
            return false;

        // Set Title bar
        setTitle(Messages.getString("GenSchemaEditor.0") + " - " + file.getPath()); //$NON-NLS-1$ //$NON-NLS-2$

        try {
            _sdEditorPanel.getMetadata().saveAsDocument(file);
        } catch (IOException ex) {
            ErrorDialogBox
                    .showWarning(
                            this,
                            Messages
                                    .getString("uk.ac.reload.editor.metadata.MD_Editor.6"), //$NON-NLS-1$
                            Messages
                                    .getString("uk.ac.reload.editor.metadata.MD_Editor.5"), //$NON-NLS-1$
                            ex);
            return false;
        }

        // Put it in the opened list
        EditorHandler.getSharedInstance().registerOpenedFile(file, this);

        return true;
    }

    /**
     * Deals with Save Menu Events
     */
    class ProxySaveHandler extends ProxyAction {
        public ProxySaveHandler(MenuAction menuAction) {
            super(menuAction);
        }

        public void menuActionPerformed(DweezilMenuEvent event) {
            if (isSelected()
                    && event.getSource() == MainMenu.getSharedInstance().actionSave) {
                saveDocument();
            }

            if (isSelected()
                    && event.getSource() == MainMenu.getSharedInstance().actionSaveAs) {
                saveAsDocument();
            }
        }
    }
    
    /**
	 * Deals with validation of instance using parser
	 */
	class ProxyValidationHandler extends ProxyAction {
		public ProxyValidationHandler() {
			super(MainMenu.getSharedInstance().actionValidate);
		}
		
	
		public void menuActionPerformed(DweezilMenuEvent event) {
			Thread thread = new Thread() {
				public void run() {
					validateIt();
				}                
			};
			
			if(isSelected()) {
			    thread.start();
			}
		}
	}
	
	public void validateIt() {
        // TODO Auto-generated method stub
	    
	    _validationHandler.setEnabled(false);
	    
	    DweezilProgressMonitor progressMonitor = new DweezilProgressMonitor(EditorFrame.getInstance(),
		        Messages.getString("GenSchemaEditor.1"), //$NON-NLS-1$
		        Messages.getString("GenSchemaEditor.2"), //$NON-NLS-1$
		        "", //$NON-NLS-1$
				true,
				DweezilUIManager.getIcon(ICON_APP16));
	    
        CVDocValidator.validateXMLDoc(_sdEditorPanel.getMetadata(), this, _sdEditorPanel.getFormPanel().getController());
        
        progressMonitor.close();
        _validationHandler.setEnabled(true);
    }
	
	protected void addTabListener(){
	    _sdEditorPanel.getTabPane().addChangeListener(new ChangeListener() {
            // This method is called whenever the selected tab changes
            public void stateChanged(ChangeEvent evt) {
                JTabbedPane pane = (JTabbedPane)evt.getSource();
                      if(pane.getSelectedIndex() == 0){
                          _validationHandler.setEnabled(true);
              			_validationHandler.addListener();
                      }else{
                          _validationHandler.setEnabled(false);    
                      }
            }
        });
	}

}
