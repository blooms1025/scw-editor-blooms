/**
 *  RELOAD TOOLS
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Phillip Beauvoir
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Phillip Beauvoir
 *  e-mail:   p.beauvoir@bolton.ac.uk
 *
 *  Web:      http://www.reload.ac.uk
 *
 */
package uk.ac.reload.editor.genschema;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.swing.AbstractAction;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.Namespace;

import uk.ac.reload.dweezil.gui.ErrorDialogBox;
import uk.ac.reload.editor.EditorFrame;
import uk.ac.reload.editor.Messages;
import uk.ac.reload.editor.ctt.helper.ListFiles;
import uk.ac.reload.jdom.XMLUtils;

import com.brunchboy.util.swing.relativelayout.AttributeConstraint;
import com.brunchboy.util.swing.relativelayout.AttributeType;
import com.brunchboy.util.swing.relativelayout.DependencyManager;
import com.brunchboy.util.swing.relativelayout.RelativeLayout;



/**
 * Dialog screen for selecting schema for creating new instances
 */
public class NewSchemaSelectionDialog extends JDialog {
    
    
    /**
     * Selected schema file name 
     */
    private static File schemaFName = null;
    private String schemaPath = null;
    private static File schemaFolder = null;
    private static boolean loaded;
    private static Document localSchemas;
    private String root = null;
    private JList schemaList;
    private DefaultListModel model;
    private Element schemaLstEl = null;
    private JScrollPane schemaLstSP;
    private JTextArea schemaInfoTA;
    
    
    /**
     * Constructor
     */
    public NewSchemaSelectionDialog(File schemaDir) throws FileNotFoundException {
        super(EditorFrame.getInstance(), Messages.getString("NewSchemaSelectionDialog.0"), true); //$NON-NLS-1$
        
        setSize(450, 400);
        setResizable(false);
        
        model = new DefaultListModel();
        schemaList = new JList(model);
        
        schemaList.addListSelectionListener(new listSelListener());
        
        // add a double click for selection
        
        schemaList.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                JList list = (JList)evt.getSource();
                if (evt.getClickCount() == 2) {          // Double-click
                    // Get item index
                    //int index = list.locationToIndex(evt.getPoint());
                    schemaFName = new File(schemaPath);
                    dispose();
                }
            }
        });
        
        if(!loaded)
            setSchemaDir(schemaDir);
        else
            updateList();
        
        RelativeLayout ourLayout = new RelativeLayout();
        getContentPane().setLayout(ourLayout);
        
        
        // Title Label
        JLabel title = new JLabel(Messages.getString("NewSchemaSelectionDialog.1")); //$NON-NLS-1$
        title.setFont(title.getFont().deriveFont(14.0f));
        getContentPane().add(title, "title"); //$NON-NLS-1$
        ourLayout.addConstraint("title", AttributeType.TOP, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME,
                        AttributeType.TOP, 10));
        ourLayout.addConstraint("title", AttributeType.HORIZONTAL_CENTER, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME,
                        AttributeType.HORIZONTAL_CENTER));
        // schema label
        JLabel lblSchema = new JLabel(Messages.getString("NewSchemaSelectionDialog.5")); //$NON-NLS-1$
        
        getContentPane().add(lblSchema, "lblSchema"); //$NON-NLS-1$
        ourLayout.addConstraint("lblSchema", AttributeType.TOP, //$NON-NLS-1$
                new AttributeConstraint("title", AttributeType.BOTTOM, 8)); //$NON-NLS-1$
        
        ourLayout.addConstraint("lblSchema", AttributeType.LEFT, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME, AttributeType.LEFT, 20));
        
        
        // schema info label
        JLabel lblInfo = new JLabel(Messages.getString("NewSchemaSelectionDialog.10")); //$NON-NLS-1$
        
        getContentPane().add(lblInfo, "lblInfo"); //$NON-NLS-1$
        
        ourLayout.addConstraint("lblInfo", AttributeType.TOP, //$NON-NLS-1$
                new AttributeConstraint("lblSchema", AttributeType.TOP)); //$NON-NLS-1$
        ourLayout.addConstraint("lblInfo", AttributeType.RIGHT, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME, AttributeType.RIGHT, -20));
        ourLayout.addConstraint("lblInfo", AttributeType.LEFT, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME, AttributeType.LEFT, 225));
        schemaLstSP = new JScrollPane();
        schemaLstSP.setViewportView(schemaList);
        getContentPane().add(schemaLstSP, "schemaLstSP"); //$NON-NLS-1$
        ourLayout.addConstraint("schemaLstSP", AttributeType.LEFT, //$NON-NLS-1$
                new AttributeConstraint("lblSchema", AttributeType.LEFT)); //$NON-NLS-1$
        ourLayout.addConstraint("schemaLstSP", AttributeType.RIGHT, //$NON-NLS-1$
                new AttributeConstraint("lblInfo", AttributeType.LEFT)); //$NON-NLS-1$
        ourLayout.addConstraint("schemaLstSP", AttributeType.TOP, //$NON-NLS-1$
                new AttributeConstraint("lblSchema", AttributeType.BOTTOM, 4)); //$NON-NLS-1$
        ourLayout.addConstraint("schemaLstSP", AttributeType.BOTTOM, //$NON-NLS-1$
                new AttributeConstraint("btnOK", AttributeType.TOP, -4)); //$NON-NLS-1$
        
        schemaInfoTA = new JTextArea(""); //$NON-NLS-1$
        schemaInfoTA.setEditable(false);
        schemaInfoTA.setLineWrap(true);
        schemaInfoTA.setWrapStyleWord(true);
        getContentPane().add(schemaInfoTA, "schemaInfoTA"); //$NON-NLS-1$
        
        ourLayout.addConstraint("schemaInfoTA", AttributeType.LEFT, //$NON-NLS-1$
                new AttributeConstraint("lblInfo", AttributeType.LEFT)); //$NON-NLS-1$
        ourLayout.addConstraint("schemaInfoTA", AttributeType.RIGHT, //$NON-NLS-1$
                new AttributeConstraint("lblInfo", AttributeType.RIGHT)); //$NON-NLS-1$
        ourLayout.addConstraint("schemaInfoTA", AttributeType.TOP, //$NON-NLS-1$
                new AttributeConstraint("lblInfo", AttributeType.BOTTOM, 4)); //$NON-NLS-1$
        ourLayout.addConstraint("schemaInfoTA", AttributeType.BOTTOM, //$NON-NLS-1$
                new AttributeConstraint("btnOK", AttributeType.TOP, -4)); //$NON-NLS-1$
        
        
        // OK Button
        JButton btnOK = new JButton(Messages.getString("NewSchemaSelectionDialog.35")); //$NON-NLS-1$
        btnOK.addActionListener(new OKClick());
        getContentPane().add(btnOK, "btnOK"); //$NON-NLS-1$
        
        
        ourLayout.addConstraint("btnOK", AttributeType.RIGHT, //$NON-NLS-1$
                new AttributeConstraint("lblInfo", AttributeType.LEFT)); //$NON-NLS-1$
        ourLayout.addConstraint("btnOK", AttributeType.BOTTOM, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME, AttributeType.BOTTOM, -10));
        // Cancel Buttton
        JButton btnCancel = new JButton(Messages.getString("NewSchemaSelectionDialog.40")); //$NON-NLS-1$
        btnCancel.addActionListener(new CancelClick());
        getContentPane().add(btnCancel, "btnCancel"); //$NON-NLS-1$
        
        ourLayout.addConstraint("btnCancel", AttributeType.RIGHT, //$NON-NLS-1$
                new AttributeConstraint("lblInfo", AttributeType.RIGHT)); //$NON-NLS-1$
        ourLayout.addConstraint("btnCancel", AttributeType.BOTTOM, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME, AttributeType.BOTTOM, -10));
        
        setLocationRelativeTo(EditorFrame.getInstance());
    }
    
    
    /**
     * Show the dialog
     * @return The user response either OK_OPTION or CANCEL_OPTION
     */
    public File showDialog() {
        show();
        return schemaFName;
    }
    
    
    
    /**
     * OK handler
     */
    private class OKClick extends AbstractAction {
        public void actionPerformed(ActionEvent e) {
            dispose();
        }
    }
    
    /**
     * Cancel handler
     */
    private class CancelClick extends AbstractAction {
        public void actionPerformed(ActionEvent e) {
            schemaFName = null;
            dispose();
        }
    }
    
    /**
     * update the schema selection list
     */
    
    private class listSelListener implements ListSelectionListener {
        public void valueChanged(ListSelectionEvent event) {
            if (!event.getValueIsAdjusting()) {
                schemaLstEl = getPathChild((String)schemaList.getSelectedValue());
                if(schemaLstEl.getChild("schema") == null){
                    System.out.println("\t The schema child element is null");
                    if(schemaLstEl.getChild("schema", Namespace.getNamespace("http://www.bolton.ac.uk/telcert/crt/root")) == null){
                        System.out.println("\t\t It is still null");
                    }else{
                        System.out.println("\t\t It is NOOOOOT null");
                    }
                }
                schemaPath =  (String)schemaList.getSelectedValue() + File.separator  
                + schemaLstEl.getChild("root").getChildText("schema"); //$NON-NLS-1$ //$NON-NLS-2$
                root = schemaLstEl.getChildTextNormalize("root"); //$NON-NLS-1$
                schemaFName = new File(schemaPath);
                schemaInfoTA.setText(Messages.getString("NewSchemaSelectionDialog.48") +  schemaLstEl.getChildTextNormalize("root") + "\n" //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
                        + Messages.getString("NewSchemaSelectionDialog.51") + schemaLstEl.getChild("root").getChildText("schema")+ "\n"  //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
                        + Messages.getString("NewSchemaSelectionDialog.55") + schemaLstEl.getChild("root").getChildText("comment")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
            }
        }
    }
    
    /**
     * load the schema list document from the selected base directory
     * @param schemaDir
     * @throws FileNotFoundException
     */
    
    
    public void setSchemaDir(File schemaDir) throws FileNotFoundException {

        ListFiles ls = new ListFiles("root"); //$NON-NLS-1$
        List files = ls.getFileListing(schemaDir);
        schemaFolder = schemaDir;
        Iterator filesIter = files.iterator();

        Element root = new Element("localSchema"); //$NON-NLS-1$
        root.setText(Messages.getString("NewSchemaSelectionDialog.60")); //$NON-NLS-1$
        localSchemas = new Document(root);
        int indx = 0;
        Element pathEl = null;

        while (filesIter.hasNext()) {
            File rootFile = (File) filesIter.next();
            if (rootFile.getName().equalsIgnoreCase("root.xml")) { //$NON-NLS-1$
                pathEl = new Element("path"); //$NON-NLS-1$
                pathEl.setText(rootFile.getParent());

                Document rootDoc = null;
                try {
                    rootDoc = XMLUtils.readXMLFile(rootFile);
                } catch (IOException ioe) {
                    // TODO Auto-generated catch block
                    //e.printStackTrace();
                    ErrorDialogBox.showWarning(Messages.getString("NewSchemaSelectionDialog.2"), Messages.getString("NewSchemaSelectionDialog.3"), ioe); //$NON-NLS-1$ //$NON-NLS-2$
                } catch (JDOMException jdome) {
                    // TODO Auto-generated catch block
                    //e.printStackTrace();
                    ErrorDialogBox.showWarning(Messages.getString("NewSchemaSelectionDialog.4"), Messages.getString("NewSchemaSelectionDialog.6"), jdome); //$NON-NLS-1$ //$NON-NLS-2$
                }

                //List rootLst = rootDoc.getRootElement().getChildren();
                if ((rootDoc != null) && (validateRootDoc(rootDoc))) {
                    model.add(indx++, rootFile.getParent());
                    pathEl.addContent((Element) rootDoc.getRootElement()
                            .clone());
                    localSchemas.getRootElement().addContent(pathEl);
                }

            }

        }

        loaded = true;
        return;
    }
    
    
    /**
     * Finds matching child element form the loaded jdom document
     * 
     * @param childName
     * @return jdom element
     */
    public Element getPathChild(String childName){
        Element child = null;
        Iterator elItr = localSchemas.getRootElement().getChildren("path").iterator(); //$NON-NLS-1$
        while (elItr.hasNext()) {
            child = (Element) elItr.next();
            if(child.getTextTrim().equalsIgnoreCase(childName))
                return child;
            
        }
        return child;
    }
    /**
     * update the list using loaded document
     *
     */    
    public void updateList(){
        int indx = 0;
        Iterator childItr = localSchemas.getRootElement().getChildren("path").iterator(); //$NON-NLS-1$
        while (childItr.hasNext()) {
            Element pathEl = (Element) childItr.next();
            model.add(indx++, pathEl.getTextNormalize());
            
        }
        
    }
    /**
     * @return Returns the schemaLstEl.
     */
    public Element getSchemaLstEl() {
        return schemaLstEl;
    }
    /**
     * get the root element name of selected schema
     * @return schema root name
     */
    public String getRoot(){
        return root;
    }
    
    /**
     * Check whether the root.xml file is in order
     * format : <root>
		rootElement
		<schema>imscp_v1p1p3_localised.xsd</schema>
		<comment>UFI localised CP 1.1.3</comment>
		<vocabFile></vocabFile>
		<helperFile></helperFile>
		</root>
     * @param rootDoc xml document with schema details
     * @return true or false
     */
    
    public boolean validateRootDoc(Document rootDoc){
        boolean result = true;
        
        if(rootDoc.getRootElement().getTextTrim().equals("")) //$NON-NLS-1$
            return false;
        if((rootDoc.getRootElement().getChild("schema") == null)||  //$NON-NLS-1$
                (rootDoc.getRootElement().getChild("schema").getTextTrim().equals(""))) //$NON-NLS-1$ //$NON-NLS-2$
            return false;
        
        return result;
    }
}
