/**
 *  RELOAD TOOLS
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Phillip Beauvoir
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Phillip Beauvoir
 *  e-mail:   p.beauvoir@bolton.ac.uk
 *
 *  Web:      http://www.reload.ac.uk
 *
 */
package uk.ac.reload.editor.genschema;

import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;

import org.eclipse.xsd.XSDElementDeclaration;

import uk.ac.reload.dweezil.gui.DweezilFileChooser;
import uk.ac.reload.dweezil.gui.DweezilFileFilter;
import uk.ac.reload.dweezil.gui.DweezilFolderChooser;
import uk.ac.reload.editor.EditorFrame;
import uk.ac.reload.editor.Messages;
import uk.ac.reload.moonunit.schema.SchemaException;
import uk.ac.reload.moonunit.schema.SchemaModel;

import com.brunchboy.util.swing.relativelayout.AttributeConstraint;
import com.brunchboy.util.swing.relativelayout.AttributeType;
import com.brunchboy.util.swing.relativelayout.DependencyManager;
import com.brunchboy.util.swing.relativelayout.RelativeLayout;

/**
 * Dialog screen for selecting schema for adding XML fragments 
 * at extension points - used for editing domain profiled schema instances ?
 * Base schema restricts usage of elements from certain namespaces at ext points
 * use this dialog to pick schema matching that namespace and then add child 
 * element to this element
 */
public class GenNewSchemaSelectionDialog extends JDialog {

    /**
     * Selected schema file name 
     */
    /**
     * The File Chooser
     */
    private DweezilFolderChooser _sourceSchemaChooser;

    private File sourceSchema;

    private RelativeLayout layout;

    private JButton schemaFileBtn;

    private JTextField txtSchemaFileName;

    private JComboBox topSchemaElementsCB;

    private String root = null;

    private static DweezilFileFilter filter;
    
    private SchemaModel sm;

    static {
        filter = new DweezilFileFilter(new String[] { "xsd" }, //$NON-NLS-1$
                Messages.getString("GenNewSchemaSelectionDialog.1")); //$NON-NLS-1$
    }

    /**
     * Constructor
     */
    public GenNewSchemaSelectionDialog(String title) throws FileNotFoundException {
        super(EditorFrame.getInstance(),
                title, true); //$NON-NLS-1$
        init(title);
        schemaFileBtn.addActionListener(new AbstractAction() {

            public void actionPerformed(ActionEvent evt) {

                sourceSchema = DweezilFileChooser.askFileNameOpen(
                        GenNewSchemaSelectionDialog.this,
                        "Select the schema file", filter); //$NON-NLS-1$
                if ((sourceSchema != null)&&(sourceSchema.exists() &&(sourceSchema.isFile()))) {
                    txtSchemaFileName.setText(sourceSchema.getName());
                    try {
                        loadRootElement();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    } catch (SchemaException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }
        });

    }

    /**
     * Show the dialog
     * @return The user response either OK_OPTION or CANCEL_OPTION
     */
    public File showDialog() {
        show();
        return sourceSchema;
    }

    /**
     * OK handler
     */
    private class OKClick extends AbstractAction {
        public void actionPerformed(ActionEvent e) {
            root = (String) topSchemaElementsCB.getSelectedItem();
            dispose();
        }
    }

    /**
     * Cancel handler
     */
    private class CancelClick extends AbstractAction {
        public void actionPerformed(ActionEvent e) {
            sourceSchema = null;
            dispose();
        }
    }

    public void loadRootElement() throws IOException, SchemaException {
        sm = new SchemaModel(sourceSchema);
        //Hashtable elMap = sm.getElementDecTbl();
        List elLst = sm.getSchema().getElementDeclarations();
        for (Iterator it = elLst.iterator(); it.hasNext();) {
            XSDElementDeclaration key = (XSDElementDeclaration)it.next();
            topSchemaElementsCB.addItem(key.getName());
        }
    }

    /**
     * get the root element name of selected schema
     * @return schema root name
     */
    public String getRoot() {
        return root;
    }
    
    /**
     * 
     * @return SchemaModel
     */
    public SchemaModel getSm() {
        return sm;
    }
    /**
     * Setup the dialog panel
     */
    protected void init(String mainTitle) {
        setSize(500, 150);
        //setResizable(false);

        layout = new RelativeLayout();
        getContentPane().setLayout(layout);
        _sourceSchemaChooser = new DweezilFolderChooser();

    
        // for selecting source file folder

        JLabel lblContent = new JLabel(Messages.getString("GenNewSchemaSelectionDialog.2")); //$NON-NLS-1$

        getContentPane().add(lblContent, "lblContent"); //$NON-NLS-1$
        layout.addConstraint("lblContent", AttributeType.TOP, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME,
                        AttributeType.TOP, 10));
        layout.addConstraint("lblContent", AttributeType.LEFT, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME,
                        AttributeType.LEFT, 25));

        // add a text field for displaying selected source file
        txtSchemaFileName = new JTextField(""); //$NON-NLS-1$
        getContentPane().add(txtSchemaFileName, "txtContentFolder"); //$NON-NLS-1$

        layout
                .addConstraint("txtContentFolder", AttributeType.TOP, //$NON-NLS-1$
                        new AttributeConstraint("lblContent", //$NON-NLS-1$
                                AttributeType.BOTTOM, 10));
        layout.addConstraint("txtContentFolder", AttributeType.LEFT, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME,
                        AttributeType.LEFT, 25));
        layout.addConstraint("txtContentFolder", AttributeType.RIGHT, //$NON-NLS-1$
                new AttributeConstraint("newCPFolderBtn", AttributeType.LEFT)); //$NON-NLS-1$
        //new AttributeConstraint("txtSource", AttributeType.RIGHT));

        // add a button for open source file

        schemaFileBtn = new JButton();

        schemaFileBtn.setText("..."); //$NON-NLS-1$

        getContentPane().add(schemaFileBtn, "newCPFolderBtn"); //$NON-NLS-1$

        layout.addConstraint("newCPFolderBtn", AttributeType.TOP, //$NON-NLS-1$
                new AttributeConstraint("txtContentFolder", AttributeType.TOP)); //$NON-NLS-1$
        layout.addConstraint("newCPFolderBtn", AttributeType.RIGHT, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME,
                        AttributeType.HORIZONTAL_CENTER, -10));
        layout.addConstraint("newCPFolderBtn", AttributeType.BOTTOM, //$NON-NLS-1$
                new AttributeConstraint("txtContentFolder", //$NON-NLS-1$
                        AttributeType.BOTTOM));

        // for selecting target file/folder

        JLabel lblTargetFile = new JLabel(Messages.getString("GenNewSchemaSelectionDialog.0")); //$NON-NLS-1$

        getContentPane().add(lblTargetFile, "lblTargetFile"); //$NON-NLS-1$
        layout.addConstraint("lblTargetFile", AttributeType.TOP, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME,
                        AttributeType.TOP, 10));
        layout.addConstraint("lblTargetFile", AttributeType.LEFT, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME,
                        AttributeType.HORIZONTAL_CENTER, 10));

        //add a text field for displaying selected target file

        topSchemaElementsCB = new JComboBox();
        getContentPane().add(topSchemaElementsCB, "txtSchemaFolder"); //$NON-NLS-1$

        layout.addConstraint("txtSchemaFolder", AttributeType.TOP, //$NON-NLS-1$
                new AttributeConstraint("lblTargetFile", AttributeType.BOTTOM, //$NON-NLS-1$
                        10));
        layout.addConstraint("txtSchemaFolder", AttributeType.LEFT, //$NON-NLS-1$
                new AttributeConstraint("lblTargetFile", AttributeType.LEFT)); //$NON-NLS-1$
        layout.addConstraint("txtSchemaFolder", AttributeType.RIGHT, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME,
                        AttributeType.RIGHT));

        // Cancel Buttton
        JButton btnCancel = new JButton(Messages.getString("GenNewSchemaSelectionDialog.30")); //$NON-NLS-1$
        btnCancel.addActionListener(new CancelClick());
        getContentPane().add(btnCancel, "btnCancel"); //$NON-NLS-1$

        layout.addConstraint("btnCancel", AttributeType.RIGHT, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME,
                        AttributeType.RIGHT));
        layout.addConstraint("btnCancel", AttributeType.BOTTOM, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME,
                        AttributeType.BOTTOM, -5));

        // OK Button
        JButton btnOK = new JButton(Messages.getString("GenNewSchemaSelectionDialog.34")); //$NON-NLS-1$
        btnOK.addActionListener(new OKClick());
        getContentPane().add(btnOK, "btnOK"); //$NON-NLS-1$

        layout.addConstraint("btnOK", AttributeType.RIGHT, //$NON-NLS-1$
                new AttributeConstraint("btnCancel", AttributeType.LEFT, -5)); //$NON-NLS-1$
        layout.addConstraint("btnOK", AttributeType.BOTTOM, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME,
                        AttributeType.BOTTOM, -5));
        setLocationRelativeTo(EditorFrame.getInstance());

    }
    
   
  
}