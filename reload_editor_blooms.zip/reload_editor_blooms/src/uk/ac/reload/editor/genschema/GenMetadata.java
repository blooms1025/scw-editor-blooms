/**
 *  RELOAD TOOLS
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Phillip Beauvoir
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Phillip Beauvoir
 *  e-mail:   p.beauvoir@bolton.ac.uk
 *
 *  Web:      http://www.reload.ac.uk
 *
 */
package uk.ac.reload.editor.genschema;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Locale;

import org.jdom.Attribute;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.Namespace;

import uk.ac.reload.editor.Messages;
import uk.ac.reload.editor.gencontent.xml.GenMDSchemaController;
import uk.ac.reload.editor.metadata.xml.Metadata;
import uk.ac.reload.editor.properties.EditorProperties;
import uk.ac.reload.jdom.XMLUtils;
import uk.ac.reload.moonunit.SchemaController;
import uk.ac.reload.moonunit.schema.SchemaAttribute;
import uk.ac.reload.moonunit.schema.SchemaElement;
import uk.ac.reload.moonunit.schema.SchemaException;
import uk.ac.reload.moonunit.schema.SchemaModel;

/**
 * A generic class for metadata instances
 */
public class GenMetadata extends Metadata {

    private boolean hasController = true;

    private boolean isembedded = true;

    /**
     * Constructor for blank MD
     */
    public GenMetadata(SchemaController controller) {

        if (controller == null)
            System.err.println(Messages.getString("GenMetadata.0")); //$NON-NLS-1$

        setSchemaController(controller);
        setDocument(new Document());
        // Add our signature
        addCommentsToDocument();

        // Add Root Element according to Schema and children
        if (controller != null) {
            SchemaModel mdSchema = controller.getSchemaModel();
            Element root = addElementBySchema(this, null, mdSchema
                    .getRootElement(), true);
            getDocument().setRootElement(root);
            addRootDeclarations();

        }
        // Clear the dirty flag because adding the root made it dirty
        setDirty(false);
    }

    /**
    * Constructor for blank MD
    */
   public GenMetadata(boolean isStandalone, GenMDSchemaController controller) {
       isembedded = isStandalone;
       
       setSchemaController(controller);

       setDocument(new Document());

       // Add our signature
       if(!isembedded) addCommentsToDocument();

       // Add Root Element according to Schema
       if(controller != null) {
           SchemaModel mdSchema = controller.getSchemaModel();
           Element root = addElementBySchema(this, null, mdSchema.getRootElement(), true);
           getDocument().setRootElement(root);
           if(!isembedded) 
               addRootDeclarations();
       }
       
       // Clear the dirty flag because adding the root made it dirty
       setDirty(false);
   }
    /**
     * Constructor for a schema instance that exists
     * 
     * @throws JDOMException
     * @throws IOException
     * @throws SchemaException
     */
    public GenMetadata(Document doc) throws JDOMException, SchemaException,
            IOException {
        if (doc == null) {
            throw new NullPointerException(Messages.getString("GenMetadata.1")); //$NON-NLS-1$
        }

        // Load the Document
        setDocument(doc);
        isembedded = false;
        // Get the Schema Controller *after* setting the doc
        loadSchemaControllerInstance();
    }

    /**
     * Constructor for a schema instance File that exists - will be Standalone
     * 
     * @throws JDOMException
     * @throws IOException
     * @throws SchemaException
     */
    public GenMetadata(File file) throws JDOMException, SchemaException,
            IOException {
        if (file == null) {
            throw new NullPointerException(Messages.getString("GenMetadata.2")); //$NON-NLS-1$
        }
        setFile(file);

        // Load the Document
        setDocument(XMLUtils.readXMLFile(file));
        isembedded = false;
        // Get the Schema Controller *after* setting the doc
        loadSchemaControllerInstance();
        if (!hasController) {
            throw new NullPointerException(Messages.getString("GenMetadata.3")); //$NON-NLS-1$
        }

    }
    
    /**
     * Constructor for generic schema instances - not Metadata
     * 
     * @throws JDOMException
     * @throws IOException
     * @throws SchemaException
     */
    public GenMetadata(File file, String root) throws JDOMException, SchemaException,
            IOException {
        if (file == null) {
            throw new NullPointerException(Messages.getString("GenMetadata.2")); //$NON-NLS-1$
        }
        setFile(file);

        // Load the Document
        setDocument(XMLUtils.readXMLFile(file));
        isembedded = false;
        // Get the Schema Controller *after* setting the doc
        loadSchemaControllerInstance();
        if (!hasController) {
            throw new NullPointerException(Messages.getString("GenMetadata.3")); //$NON-NLS-1$
        }

    }
    

    /**
     * Constructor for a schema instance that exists and one that might be an
     * embdedded metadata
     * 
     * @throws JDOMException
     * @throws IOException
     * @throws SchemaException
     */
    public GenMetadata(Document doc, String pathToSchema) throws JDOMException,
            SchemaException, IOException {
        if (doc == null) {
            throw new NullPointerException(Messages.getString("GenMetadata.1")); //$NON-NLS-1$
        }

        //FIXME
        // this one is not going to handle http schema locations TODO
        setDocument(doc);
        if (pathToSchema.indexOf("http") == -1) {
        	System.out.println(" path to schema is " + pathToSchema);
            File schemaFile = new File(pathToSchema);
            if (!schemaFile.exists()) {
                throw new IOException(Messages.getString("GenMetadata.2")); //$NON-NLS-1$
                //ErrorDialogBox.showWarning("Unable to locate metadata schema
                // file", "Error in Metadata", new
                // NullPointerException(Messages.getString("GenMetadata.2")));
                //return;
            }
            setSchemaController(new GenMDSchemaController(schemaFile,
                    getDocument().getRootElement().getName()));
            hasController = true;
            isembedded = true;
        } else {
            setSchemaController(new GenSchemaController(new URL(pathToSchema),
                    getDocument().getRootElement().getName()));
            hasController = true;
            isembedded = true;
        }

       
    }

    /**
     * Load the SchemaControllerInstance This attempts to load schema file from
     * the directory of the xml document
     * 
     * @throws JDOMException
     * @throws IOException
     * @throws SchemaException
     */
    protected void loadSchemaControllerInstance() throws JDOMException,
            SchemaException, IOException {

        // The first thing we do is to see if there is a root Namespace in the
        // Document
        Namespace nameSpace = XMLUtils.getDocumentNamespace(getDocument());

        // No Namespace, sorry we don't know what it is!
        if (nameSpace == null || nameSpace.equals(Namespace.NO_NAMESPACE)) {
            hasController = false;
            return;
        }
        String schemalocn = XMLUtils
                .getSchemaLocation(getDocument(), nameSpace);      
        if (!schemalocn.startsWith("http")) { // deal only locally available
                                              // schema files //$NON-NLS-1$
            // this is assuming that schemas are available in the same folder !
            File schemaFile = new File(getFile().getParent() + "/" + schemalocn); //$NON-NLS-1$
            if (!schemaFile.exists()) {
                System.err
                        .println(Messages.getString("GenMetadata.6") + schemalocn + " " + schemaFile.getAbsolutePath()); //$NON-NLS-1$ //$NON-NLS-2$
                hasController = false;
                return;
            }
            String rootName = getDocument().getRootElement().getName();
            if(rootName =="lom") {          //$NON-NLS-1$
                GenMDSchemaController.setSchemaFile(schemaFile);
                setSchemaController(new GenMDSchemaController());
            }else {
                setSchemaController(new GenSchemaController(schemaFile,
                        getDocument().getRootElement().getName()));
            }
            hasController = true;
            return;
        }// this is for http based schema locations
        //System.out.println(" schema location is http " + schemalocn);
        setSchemaController(new GenSchemaController(new URL(schemalocn),
                getDocument().getRootElement().getName()));
        hasController = true;
        return;

    }

    /**
     * Create a non-standalone (embedded) MD that is based on this standalone
     * one. Used when importing MD into CP
     */
    public GenMetadata createEmbeddedMetadata() {
        GenMetadata md = new GenMetadata(true,
                (GenMDSchemaController) getSchemaController());
        Document clone = (Document) getDocument().clone();
        md.setDocument(clone);

        // Get the Root Element
        Element root = clone.getRootElement();

        // Clear any Attributes
        root.setAttributes(null);

        // Add Namespace prefixes to all Elements
        Namespace ns = root.getNamespace();
        if (ns != null) {
            XMLUtils.replaceNamespaces(root, ns, getRootNamespaceEmbedded());
        }

        return md;
    }

    /**
     * If this is a non-standalone embedded MD create a standalone version suitable for exporting or editing as standalone
     */
    public GenMetadata createStandaloneMetadata() {
        GenMetadata md = new GenMetadata((GenMDSchemaController)getSchemaController());
        
        // Clone of root
        Element root = (Element)getDocument().getRootElement().clone();
        
        // Remove Namespace prefixes from all Elements
        Namespace ns = root.getNamespace();
        if(ns != null) {
            XMLUtils.replaceNamespaces(root, ns, Namespace.getNamespace(ns.getURI()));
        }
        
        // Set to root
        md.getDocument().setRootElement(root);
        
        // Add root declarations
        md.addRootDeclarations();
        
        return md;
    }
    
    /**
     * Add namespace and other attribute declarations to the root element
     */
    protected void addRootDeclarations() {
        Element root = getDocument().getRootElement();
        
        // Add XSI Schema Instance Namespace
        root.addNamespaceDeclaration(XMLUtils.XSI_Namespace);

        // Add Schema Location Attribute which is constructed from Target Namespace
        // and file name of Schema
        SchemaModel mdSchema = getSchemaController().getSchemaModel();
        String schemaLocationURI = mdSchema.getTargetNamespaceURI() + " " + mdSchema.getSchemaName();
        root.setAttribute(XMLUtils.XSI_SchemaLocation, schemaLocationURI, XMLUtils.XSI_Namespace);
    }
    /**
     * Over-ride this so we can intercept it to do stuff
     */
    public Element addElementBySchema(Object source, Element parentElement,
            SchemaElement newSchemaElement, boolean doSelect) {
        Element newElement = super.addElementBySchema(source, parentElement,
                newSchemaElement, doSelect);
        if (newElement != null) {
            // We'll add a default lang attribute
            if (newSchemaElement.hasSchemaAttribute(
                    "lang", Namespace.XML_NAMESPACE)) { //$NON-NLS-1$
                Attribute att = newElement.getAttribute(
                        "lang", Namespace.XML_NAMESPACE); //$NON-NLS-1$
                if (att != null) {
                    att.setValue(Locale.getDefault().getLanguage());

                }

            } else if (newSchemaElement.hasSchemaAttributes()) {
                SchemaAttribute[] atts = newSchemaElement.getSchemaAttributes();
                for (int i = 0; i < atts.length; i++) {
                    if (!("required".equals(atts[i].getUse()))) { // as this is
                                                                  // already
                                                                  // done by
                                                                  // super types
                        Attribute att = atts[i].createAttribute();
                        String attValue = getSchemaController()
                                .getDefaultValue(atts[i]);
                        if (attValue == null) {
                            attValue = "";
                        }
                        att.setValue(attValue);
                        newElement.setAttribute(att);
                    }

                }
            }
        }

        return newElement;
    }

   
    /**
     * @return the Comments to add to the XML Document
     */
    public String[] getComments() {
        return gen_comments;
    }

    /**
     * Our unique signature
     */
    static final String[] gen_comments = {
            "This is a Reload CRT version "
                    + EditorProperties.getString("VERSION")
                    + " xml instance document",
            "Spawned from the Reload Metadata Generator - http://www.reload.ac.uk" };

    /**
     * Copy schema file to the folder of intance document
     */

    public void saveDocument() throws IOException {
        // TODO Auto-generated method stub
        super.saveDocument();
    }

    public void destroy() {
        // TODO Auto-generated method stub
        super.destroy();
        
    }
}