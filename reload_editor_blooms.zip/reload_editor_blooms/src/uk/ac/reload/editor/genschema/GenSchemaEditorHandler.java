/**
 *  RELOAD TOOLS
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Phillip Beauvoir
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Phillip Beauvoir
 *  e-mail:   p.beauvoir@bolton.ac.uk
 *
 *  Web:      http://www.reload.ac.uk
 *
 */
package uk.ac.reload.editor.genschema;

import java.io.File;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

import javax.swing.Icon;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.Namespace;

import uk.ac.reload.dweezil.gui.DweezilFolderChooser;
import uk.ac.reload.dweezil.gui.ErrorDialogBox;
import uk.ac.reload.dweezil.util.DweezilUIManager;
import uk.ac.reload.editor.EditorFrame;
import uk.ac.reload.editor.EditorHandler;
import uk.ac.reload.editor.EditorInternalFrame;
import uk.ac.reload.editor.IEditorHandler;
import uk.ac.reload.editor.IIcons;
import uk.ac.reload.editor.Messages;
import uk.ac.reload.jdom.XMLUtils;
import uk.ac.reload.moonunit.SchemaController;
import uk.ac.reload.moonunit.SchemaHelper;
import uk.ac.reload.moonunit.schema.SchemaException;
import uk.ac.reload.moonunit.schema.SchemaModel;
import uk.ac.reload.moonunit.schema.utils.SchemaUtils;
import uk.ac.reload.moonunit.vocab.Vocabulary;

/**
 * Class for creating/editing in a frame non ims schema instances (any schema instnce ?) 
 */
public class GenSchemaEditorHandler implements IEditorHandler, IIcons {
    
    
    /**
     * Schema root Folder
     */
    
    public static final File SCHEMA_FOLDER = new File("localschema"); //$NON-NLS-1$
    
    public static final File HELPER_FOLDER = new File(EditorHandler.HELPERFOLDER, "generic"); //$NON-NLS-1$
    public static final File PROFILE_FOLDER = new File(HELPER_FOLDER, "profile"); //$NON-NLS-1$
    public static final File SCHEMAHELPER_FOLDER = new File(HELPER_FOLDER, "schemahelper"); //$NON-NLS-1$
    public static final File VOCAB_FOLDER = new File(HELPER_FOLDER, "vocab"); //$NON-NLS-1$

    
    
    private String extSchemaLocns;
    
    /**
     * 
     */
    public GenSchemaEditorHandler() {
    }
    
    /**
     * 
     */
    public boolean canCreateDocuments() {
        return true;
    }
    /**
     * 
     */
    public boolean canEditFile(File file) {
        // Try to load the Document
        Document doc;
        
        // this is to stop it from opening non xml files !
        if(!file.getName().endsWith("xml")){
            return false;
        }
        
        try {
            doc = XMLUtils.readXMLFile(file);
        } catch (Exception ex) {
            return false;
        }
        
        // The first thing we do is to see if there is a root Namespace in the Document
        Namespace nameSpace = XMLUtils.getDocumentNamespace(doc);
        
        // No Namespace, sorry we don't know what it is!
        if (nameSpace == null || nameSpace.equals(Namespace.NO_NAMESPACE)) {
            return false;
        }
        String schLocn = XMLUtils.getSchemaLocation(doc, nameSpace);
        
        if(schLocn == null)
            return false;
        
        if(!schLocn.startsWith("http")){  // deal only locally available schema files //$NON-NLS-1$
            
            File schemaFile = new File(file.getParent()+ File.separatorChar +  schLocn); //$NON-NLS-1$
            if(!schemaFile.exists()){
                return false;
            }else {
                return true;
                
            }
        }else{
            //handle http based schema locations
            try {
                    URL url = new URL(schLocn);
                    
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.connect();
                    //System.out.println("The file : " + url.toString() + " not exists and can't be read");
                    return conn.getResponseCode() == HttpURLConnection.HTTP_OK;
               
                } catch (MalformedURLException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                
            
        }
        
        return false;
    }
    
    /**
     * 
     */
    public EditorInternalFrame editFile(File file) throws Exception {
        GenMetadata md = new GenMetadata(file);
        return new GenSchemaEditor(md);
    }
    /**
     * 
     */
    public EditorInternalFrame newDocument() throws JDOMException,
            SchemaException, IOException {

        DweezilFolderChooser schemaFolderChooser = new DweezilFolderChooser(SCHEMA_FOLDER);
        schemaFolderChooser
                .setDialogTitle("Select folder containing schema and root.xml file ");

        //Ask for the File Name
        int returnVal = schemaFolderChooser.showOpenDialog(EditorFrame
                .getInstance());

        // User Cancelled
        if (returnVal != DweezilFolderChooser.APPROVE_OPTION) {
            return null;
        }

        // Get the chosen File
        File file = schemaFolderChooser.getSelectedFileAndStore();

        File rootConfigFile = new File(file, "root.xml"); //$NON-NLS-1$

        if (!rootConfigFile.exists()) {
            ErrorDialogBox.showWarning(Messages.getString("NewSchemaSelectionDialog.2"), Messages.getString("NewSchemaSelectionDialog.3"),
                    new Exception("root.xml file missing")); //$NON-NLS-1$ //$NON-NLS-2$
            return null;
        }

        Document configDoc = XMLUtils.readXMLFile(rootConfigFile);
        if ((configDoc == null) || (!validateRootDoc(configDoc))) {
            throw new JDOMException(Messages
                    .getString("NewSchemaSelectionDialog.4")); //$NON-NLS-1$
        }

        String rootElementName = configDoc.getRootElement().getTextTrim();
        String schemaFileName = configDoc.getRootElement().getChildTextTrim(
                							"schema");
        File schemaFile = new File(file, schemaFileName);

        if (!schemaFile.exists()) {
            return null;
        }

        GenSchemaController controller = new GenSchemaController(schemaFile,
                								rootElementName);

        //==================================
        // if there are sub schemas for extension types
        List extensions = configDoc.getRootElement().getChildren(
                "extensionFile");

        if (extensions.size() > 0) {
            //System.out.println("Found extension types");
            Hashtable uri2SchemaTbl = new Hashtable();
            Hashtable uri2PrefxTbl = new Hashtable();
            Hashtable uri2RootTbl = new Hashtable();
            StringBuffer sb = new StringBuffer("");
            //List elLst = new ArrayList();
            for (Iterator iter = extensions.iterator(); iter.hasNext();) {
                Element element = (Element) iter.next();
                String extFileName = element.getChildTextTrim("filename");
                String nsPrefix = element.getChildTextTrim("prefix");
                String nsURI = element.getChildTextTrim("nsURI");
                String rootElName = element.getChildTextTrim("rootElement");
                //File extSchemaFile = new File(file.getParent(), extFileName);
                File extSchemaFile = new File(file, extFileName);

                if (!("".equals(extFileName)) && !("".equals(nsPrefix))
                        && !("".equals(nsURI)) && !("".equals(rootElName))
                        && (extSchemaFile.exists())) {
                    //System.out.println("Adding extension types schemas " +
                    // extFileName);

                    SchemaModel sm = new SchemaModel(extSchemaFile, rootElName);

                    if (sm != null) {
                        uri2SchemaTbl.put(nsURI, sm.get_xsdSchema());
                        uri2PrefxTbl.put(nsURI, nsPrefix);
                        uri2RootTbl.put(nsURI, rootElName);
                        sb.append(nsURI);
                        sb.append(" ");
                        sb.append(extFileName);
                        sb.append(" ");

                    }
                }
            }
            extSchemaLocns = sb.toString();

            SchemaUtils.getExtURItoSchemaMap().putAll(uri2SchemaTbl);
            SchemaUtils.getExtURItoPrefxMap().putAll(uri2PrefxTbl);
            SchemaUtils.getExtURItoRootMap().putAll(uri2RootTbl);
        }

        //=================================

        GenMetadata md = new GenMetadata(controller);
        // the following to add schema location of extension schemas in advance
        if (extensions.size() > 0) {
            addExtSchemaLocnsToRoot(md.getDocument(), extSchemaLocns);
        }

        return new GenSchemaEditor(md);
    }	
            
         
    
    
    public EditorInternalFrame newDocumentOld() throws JDOMException, SchemaException, IOException {
        
        NewSchemaSelectionDialog dialog = new NewSchemaSelectionDialog(SCHEMA_FOLDER);
        File file = dialog.showDialog();
        //System.out.println(" schema file name is " + file.getAbsolutePath());
        
        if (file == null){
            return null;
        }else{
            String root = dialog.getRoot();
            if((root == null))
                return null;
            else{
                GenSchemaController controller =
                    new GenSchemaController(file,root);
                Element schemaData = dialog.getSchemaLstEl();
                String helperFileName = schemaData.getChild("root").getChildTextTrim("helperFile"); //$NON-NLS-1$ //$NON-NLS-2$
                String vocabFileName = schemaData.getChild("root").getChildTextTrim("vocabFile"); //$NON-NLS-1$ //$NON-NLS-2$
               
                if(((helperFileName != null) && (vocabFileName != null)) 
                        && (!("".equals(helperFileName)) || !("".equals(vocabFileName)))){ //$NON-NLS-1$ //$NON-NLS-2$
                    
                    File vocabFile =  new File(file.getParent(), vocabFileName);
                    if(vocabFile.exists() && vocabFile.isFile()){
                        controller.setVocabulary(Vocabulary.getVocabulary(vocabFile));
                    }
                    File helperFile = new File(file.getParent(), helperFileName);
                    if(helperFile.exists() && helperFile.isFile()){
                        controller.setSchemaHelper(SchemaHelper.getSchemaHelper(helperFile));
                    }
                }
                
               //==================================
                // if there are sub schemas for extension types 
                List extensions = schemaData.getChild("root").getChildren("extensionFile");
                
                if (extensions.size() > 0) {
                    //System.out.println("Found extension types");
                    Hashtable uri2SchemaTbl = new Hashtable();
                    Hashtable uri2PrefxTbl = new Hashtable();
                    Hashtable uri2RootTbl = new Hashtable();
                    StringBuffer sb = new StringBuffer("");
                    //List elLst = new ArrayList();
                    for (Iterator iter = extensions.iterator(); iter.hasNext();) {
                        Element element = (Element) iter.next();
                        String extFileName = element
                                .getChildTextTrim("filename");
                        String nsPrefix = element.getChildTextTrim("prefix");
                        String nsURI = element.getChildTextTrim("nsURI");
                        String rootElName = element.getChildTextTrim("rootElement");
                         File extSchemaFile = new File(file.getParent(), extFileName);
                        
                        if (!("".equals(extFileName)) && !("".equals(nsPrefix)) 
                                && !("".equals(nsURI)) && !("".equals(rootElName)) && (extSchemaFile.exists())) {
                            //System.out.println("Adding extension types schemas " + extFileName);
                           
                            SchemaModel sm = new SchemaModel(extSchemaFile, rootElName);
                          
                            if (sm != null) {
                                uri2SchemaTbl.put(nsURI, sm.get_xsdSchema());
                                uri2PrefxTbl.put(nsURI, nsPrefix);
                                uri2PrefxTbl.put(nsURI, rootElName);
                                sb.append(nsURI);
                                sb.append(" ");
                                sb.append(extFileName);
                                sb.append(" ");
                               
                            }
                        }
                    }
                    extSchemaLocns = sb.toString();
                      
                    SchemaUtils.getExtURItoSchemaMap().putAll(uri2SchemaTbl);
                    SchemaUtils.getExtURItoPrefxMap().putAll(uri2PrefxTbl);
                    SchemaUtils.getExtURItoRootMap().putAll(uri2RootTbl);
                }
                
               //=================================
                
                GenMetadata md = new GenMetadata(controller);
                // the following to add schema location of extension schemas in advance
                if (extensions.size() > 0) {
                    addExtSchemaLocnsToRoot(md.getDocument(), extSchemaLocns);
                }
              
                return new GenSchemaEditor(md);
            }	
            
        } 
    }
    
    /**
     * 
     */
    public String getName() {
        return Messages.getString("GenSchemaEditorHandler.10"); //$NON-NLS-1$
    }
    /**
     * 
     */
    public Icon getIcon() {
        return DweezilUIManager.getIcon(ICON_MD);
    }
    /**
     * 
     */
    public String[] getSupportedVersions() {
        return null;
    }
    
    /**
     * 
     */
    public SchemaController getSchemaControllerInstance(String version) throws Exception {
        return null;
    }
    
    /**
     * This method update the schema location attribute of the document to incorporate
     * the extension schema. at present this is being done in advance even if extension are
     * not used in the document 
     * @param doc document to be amended
     * @param locns schema location
     */
    public void addExtSchemaLocnsToRoot(Document doc, String locns){
        Element root = doc.getRootElement();
        if(root != null){
        String schLocnStr = root.getAttributeValue(XMLUtils.XSI_SchemaLocation, XMLUtils.XSI_Namespace);
        schLocnStr = schLocnStr + " " + locns;        
        root.setAttribute(XMLUtils.XSI_SchemaLocation, schLocnStr, XMLUtils.XSI_Namespace);
        }
    }
 
    /**
     * Check whether the root.xml file is in order
     * format : <root>
		rootElement
		<schema>imscp_v1p1p3_localised.xsd</schema>
		<comment>UFI localised CP 1.1.3</comment>
		<vocabFile></vocabFile>
		<helperFile></helperFile>
		</root>
     * @param rootDoc xml document with schema details
     * @return true or false
     */
    
    public boolean validateRootDoc(Document rootDoc){
        boolean result = true;
        
        if(rootDoc.getRootElement().getTextTrim().equals("")) //$NON-NLS-1$
            return false;
        if((rootDoc.getRootElement().getChild("schema") == null)||  //$NON-NLS-1$
                (rootDoc.getRootElement().getChild("schema").getTextTrim().equals(""))) //$NON-NLS-1$ //$NON-NLS-2$
            return false;        
        return result;
    }
    
}
