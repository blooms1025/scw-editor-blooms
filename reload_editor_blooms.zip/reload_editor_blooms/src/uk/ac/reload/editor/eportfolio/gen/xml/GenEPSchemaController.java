/**
 *  Content Re-Engineerng Tool
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Roy P Cherian
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Roy P Cherian
 *  e-mail:   rc3@bolton.ac.uk
 *
 *
 */
package uk.ac.reload.editor.eportfolio.gen.xml;

import java.io.File;
import java.io.IOException;

import org.jdom.JDOMException;

import uk.ac.reload.editor.eportfolio.EP_EditorHandler;
import uk.ac.reload.editor.genschema.GenSchemaController;
import uk.ac.reload.moonunit.schema.SchemaException;
import uk.ac.reload.moonunit.schema.SchemaModel;

/**
 * @author Roy P Cherian
 *
 * TODO
 */
public class GenEPSchemaController extends GenSchemaController {

    /**
     * Default Profile
     */
    public static String defaultEPProfile = "EP Europass Profile";
    
    String root;
    String version ="";
    File schemaFile;
    String schemaUrl; // for cases when schemalocation is referring to http locations
    /**
     * 
     * @param model
     * @throws JDOMException
     * @throws SchemaException
     * @throws IOException
     */
     
     public GenEPSchemaController(SchemaModel model) throws JDOMException, SchemaException, IOException {
         super(model);
         version=model.getVersion();
         root = model.getRootElementName();
     }

    @Override
    public File getProfileFolder() {
        // TODO Auto-generated method stub
        return EP_EditorHandler.PROFILE_FOLDER;
    }

    @Override
    public String getDefaultProfileName() {
        // TODO Auto-generated method stub
        return defaultEPProfile;
    }

    @Override
    public File getSchemaHelperFolder() {
        // TODO Auto-generated method stub
        return EP_EditorHandler.HELPER_FOLDER;
    }

    @Override
    public File getVocabFolder() {
        // TODO Auto-generated method stub
        return EP_EditorHandler.VOCAB_FOLDER;
    }

    @Override
    public String getVersion() {
        // TODO Auto-generated method stub
        return version;
    }

    @Override
    public String getRootElementName() {
        // TODO Auto-generated method stub
        return root;
    }

    @Override
    public File getSchemaFile() {
        // TODO Auto-generated method stub
        String schemaLocn = getSchemaModel().get_xsdSchema().getSchemaLocation();
        return new File(schemaLocn);
    }

}
