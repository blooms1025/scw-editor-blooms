/**
 *  Content Re-Engineerng Tool
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Roy P Cherian
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Roy P Cherian
 *  e-mail:   rc3@bolton.ac.uk
 *
 *
 */
package uk.ac.reload.editor.eportfolio.editor;

import java.util.Iterator;

import org.jdom.Element;
import org.jdom.Namespace;

import uk.ac.reload.dweezil.gui.tree.DweezilTreeModel;
import uk.ac.reload.editor.eportfolio.editor.xml.EPContentPackage;
import uk.ac.reload.editor.prefs.EditorPrefs;
import uk.ac.reload.moonunit.contentpackaging.CP_Core;
import uk.ac.reload.moonunit.schema.SchemaElement;

/**
 * @author Roy P Cherian
 * 
 * TODO
 */
public class EPManifestTreeModel extends DweezilTreeModel {
    /**
     * The EP Content Package Document
     */
    private EPContentPackage _contentPackage;

    public EPManifestTreeModel() {

    }

    public void setContentPackage(EPContentPackage cp) {
        _contentPackage = cp;
        // Create the root node
        root = new EPManifestTreeNode(_contentPackage);
        // Build the child nodes
        buildChildren((EPManifestTreeNode) root);
        // Reload the Model
        reload();
    }

    /**
     * Build up child nodes
     * 
     * @param node
     *            The Parent Node
     */
    public void buildChildren(EPManifestTreeNode node) {
        Iterator children = node.getElement().getChildren().iterator();
        while (children.hasNext()) {
            Element child = (Element) children.next();
            if (doShowNode(child)) {
                EPManifestTreeNode newNode = new EPManifestTreeNode(child);
                node.add(newNode);
                buildChildren(newNode);
            }
        }
    }

    /**
     * @return Whether to display an Element on the Tree
     */
    protected boolean doShowNode(Element element) {
        return doShowNode(element.getName(), element.getNamespace());
    }

    /**
     * @return Whether to display an Element on the Tree
     */
    protected boolean doShowNode(SchemaElement schemaElement) {
        return doShowNode(schemaElement.getName(), schemaElement.getNamespace());
    }

    /**
     * @return Whether to display an Element on the Tree
     */
    protected boolean doShowNode(String elementName, Namespace ns) {
        // No Metadata LOM Node
        if (_contentPackage.isMetadataRoot(elementName))
            return false;

       // No TITLE Node
        if (elementName.equals(CP_Core.TITLE)
                && ns.equals(_contentPackage.getRootNamespace()))
            return false;

        // RESOURCES Node
        if (elementName.equals(CP_Core.RESOURCES)) {
            boolean hideResources = EditorPrefs.getInstance().getBooleanValue(
                    EditorPrefs.CP_HIDE_RESOURCES);
            return (hideResources == false);
        }
        
        return true;
    }

    /**
     * @return Whether to allow to add an Element on the Tree
     */
    protected boolean canAddNode(Element element) {
        return canAddNode(element.getName(), element.getNamespace());
    }

    /**
     * @return Whether to allow to add an Element on the Tree
     */
    protected boolean canAddNode(SchemaElement schemaElement) {
        return canAddNode(schemaElement.getName(), schemaElement.getNamespace());
    }

    /**
     * @return Whether to allow to add an Element on the Tree
     */
    protected boolean canAddNode(String elementName, Namespace ns) {
        if (elementName.equals(CP_Core.MANIFEST)
                && ns.equals(_contentPackage.getRootNamespace()))
            return false;
        else if (elementName.equals(CP_Core.ORGANIZATIONS)
                && ns.equals(_contentPackage.getRootNamespace()))
            return false;
        else if (elementName.equals(CP_Core.RESOURCES)
                && ns.equals(_contentPackage.getRootNamespace()))
            return false;
        else
            return doShowNode(elementName, ns);
    }
}