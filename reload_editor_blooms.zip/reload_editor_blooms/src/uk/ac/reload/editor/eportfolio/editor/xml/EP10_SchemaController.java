/**
 *  RELOAD TOOLS
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Phillip Beauvoir
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Phillip Beauvoir
 *  e-mail:   p.beauvoir@bolton.ac.uk
 *
 *  Web:      http://www.reload.ac.uk
 *
 */

package uk.ac.reload.editor.eportfolio.editor.xml;

import java.io.File;
import java.io.IOException;

import javax.swing.Icon;

import org.jdom.JDOMException;
import org.jdom.Namespace;

import uk.ac.reload.diva.util.FileUtils;
import uk.ac.reload.dweezil.util.DweezilUIManager;
import uk.ac.reload.editor.EditorHandler;
import uk.ac.reload.editor.IIcons;
import uk.ac.reload.editor.eportfolio.EP_EditorHandler;
import uk.ac.reload.editor.gui.TreeIconInterface;
import uk.ac.reload.editor.metadata.MD_EditorHandler;
import uk.ac.reload.editor.metadata.xml.MD124_SchemaController;
import uk.ac.reload.editor.metadata.xml.MD_SchemaController;
import uk.ac.reload.editor.prefs.EditorPrefs;
import uk.ac.reload.moonunit.ProfiledSchemaController;
import uk.ac.reload.moonunit.contentpackaging.CP_Core;
import uk.ac.reload.moonunit.schema.SchemaException;
import uk.ac.reload.moonunit.schema.SchemaModel;

/**
 * The EP Schema Controller
 *
 */
/**
 * @author Roy P Cherian
 *
 * TODO
 */
public class EP10_SchemaController
extends ProfiledSchemaController
implements TreeIconInterface, IIcons
{
	// Schema file
	public static File fileSchemaEP1_0 = new File(new File(EditorHandler.SCHEMAMODELFOLDER, "imsep_10"), "imsportfoliocp_v1p0.xsd");
	public static File fileSchemaLIP10_1 = new File(new File(EditorHandler.SCHEMAMODELFOLDER, "imsep_10"), "imslip_v1p0.xsd");
	public static File fileSchemaIMSAccess = new File(new File(EditorHandler.SCHEMAMODELFOLDER, "imsep_10"), "AccessForAll_v1p0.xsd");
	public static File fileSchemaIMSASSERT = new File(new File(EditorHandler.SCHEMAMODELFOLDER, "imsep_10"), "imsassert_v1p0.xsd");
	public static File fileSchemaIMSPARTICIPATION = new File(new File(EditorHandler.SCHEMAMODELFOLDER, "imsep_10"), "imsparticipation_v1p0.xsd");
	public static File fileSchemaIMSRDCEO = new File(new File(EditorHandler.SCHEMAMODELFOLDER, "imsep_10"), "imsrdceo_rootv1p0.xsd");
	public static File fileSchemaIMSREFLEX = new File(new File(EditorHandler.SCHEMAMODELFOLDER, "imsep_10"), "imsreflex_v1p0.xsd");
	public static File fileSchemaIMSRUBRIC = new File(new File(EditorHandler.SCHEMAMODELFOLDER, "imsep_10"), "imsrubric_v1p0.xsd");
	
	public static SchemaModel imslipModel;
	public static SchemaModel imsAccessModel;
	public static SchemaModel imsAssertModel;
	public static SchemaModel imsPartcpnModel;
	public static SchemaModel imsRdceoModel;
	public static SchemaModel imsReflexModel;
	public static SchemaModel imsRubricModel;
	
	/**
	 * Default Profile
	 */
	public static String defaultEPProfile = "EP Europass Profile";

	/**
	 * The MetadataSchemaController for MD elements
	 */
	private MD_SchemaController _mdController;
	
	/**
	 * Default Constructor
	 * @throws JDOMException
	 * @throws IOException
	 * @throws SchemaException
	 */
	public EP10_SchemaController() throws JDOMException, SchemaException, IOException {
	    super();
	}
	
	public String getVersion() {
	    return EP_EditorHandler.IMS_EPORTFOLIO_PACKAGING_1_0;
	}

	

    /**
     * @return The default MD_SchemaController for this type of CP
     * @throws JDOMException
     * @throws IOException
     * @throws SchemaException
     */
    public MD_SchemaController getDefaultMD_SchemaController() throws JDOMException, SchemaException, IOException {
        return new MD124_SchemaController();
    }

    /* (non-Javadoc)
     * @see uk.ac.reload.moonunit.handler.SchemaController#getSchemaFile()
     */
    public File getSchemaFile() {
        return fileSchemaEP1_0;
    }
    
    
    
    /**
	 * Set the MD_SchemaController
	 * @param mdController
	 */
	public void setMD_SchemaController(MD_SchemaController mdController) {
        _mdController = mdController;
	}
	


	/**
	 * Copy the Schema Files to the Project Folder
	 */
	public void copySchemaFilesToFolder(File projectFolder) throws IOException {
	    String versionMD = getMetadataVersion();
	    if(versionMD != null) {
		    // MD 121
		    if(MD_EditorHandler.IMS_METADATA_1_2_1.equals(versionMD)) {
				FileUtils.copyFolder(new File(EditorHandler.SCHEMASHIPPEDFOLDER, "imsmd_121"), projectFolder);
			}
			// MD 122
		    else if(MD_EditorHandler.IMS_METADATA_1_2_2.equals(versionMD)) {
				FileUtils.copyFolder(new File(EditorHandler.SCHEMASHIPPEDFOLDER, "imsmd_122"), projectFolder);
			}
		    //		  MD 124
		    else if(MD_EditorHandler.IMS_METADATA_1_2_4.equals(versionMD)) {
				FileUtils.copyFolder(new File(EditorHandler.SCHEMASHIPPEDFOLDER, "imsmd_124"), projectFolder);
			}
			// MD 11
		    else if(MD_EditorHandler.IMS_METADATA_1_1.equals(versionMD)) {
				FileUtils.copyFolder(new File(EditorHandler.SCHEMAMODELFOLDER, "imsmd_11"), projectFolder);
			}else{
			    FileUtils.copyFolder(new File(EditorHandler.SCHEMASHIPPEDFOLDER, "imsmd_124"), projectFolder); 
			}
	    }
	    
	    FileUtils.copyFolder(new File(EditorHandler.SCHEMASHIPPEDFOLDER, "imsep_10"), projectFolder);
		
		
	}

	/**
	 * @return The MD Version used
	 */
	public String getMetadataVersion() {
		return _mdController == null ? null : _mdController.getVersion();
	}

    /**
     * @return Returns the mdController
     */
    public MD_SchemaController getMD_SchemaController() {
        return _mdController;
    }
    
   
    /* (non-Javadoc)
     * @see uk.ac.reload.moonunit.SchemaController#getProfileFolder()
     */
    public File getProfileFolder() {
        return EP_EditorHandler.PROFILE_FOLDER;
    }

    /* (non-Javadoc)
     * @see uk.ac.reload.moonunit.SchemaController#getSchemaHelperFolder()
     */
    public File getSchemaHelperFolder() {
        return EP_EditorHandler.SCHEMAHELPER_FOLDER;
    }

    /* (non-Javadoc)
     * @see uk.ac.reload.moonunit.SchemaController#getVocabFolder()
     */
    public File getVocabFolder() {
        return EP_EditorHandler.VOCAB_FOLDER;
    }

    /* (non-Javadoc)
     * @see uk.ac.reload.moonunit.SchemaController#getDefaultProfilename()
     */
    public String getDefaultProfileName() {
   		// Get from User Prefs
   		//String defProfileName = EditorPrefs.getInstance().getValue(EditorPrefs.CP_DEFAULT_PROFILE);
        //return defProfileName == null ? defaultEPProfile : defProfileName;
        return defaultEPProfile;
    }
    
    
	/**
	 * @return the Root element name
	 */
	public String getRootElementName() {
		return "manifest";
	}
	
	/**
	 * Get The Leaf Icon
	 */
	public Icon getLeafIcon(String name, Namespace ns) {
		// If the element's Namespace is not equal to the root Namespace then
		// we are dealing with an unknown Namespace
		if(!ns.getURI().equals(getSchemaModel().getTargetNamespaceURI())) {
		  return DweezilUIManager.getIcon(ICON_NODE);
		}
		
		// Set some icons - HARD CODED FOR NOW
		if(name.equals(CP_Core.MANIFEST)) {
			return DweezilUIManager.getIcon(ICON_CP);
		}
		else if(name.equals(CP_Core.ORGANIZATIONS)) {
		   	return DweezilUIManager.getIcon(ICON_ORGS);
		}
		else if(name.equals(CP_Core.ORGANIZATION)) {
		   return DweezilUIManager.getIcon(ICON_ORG);
		}
		else if(name.equals(CP_Core.ITEM)) {
		    return DweezilUIManager.getIcon(ICON_ITEM);
		}
		else if(name.equals(CP_Core.FILE)) {
		   return DweezilUIManager.getIcon(ICON_FILE);
		}
		else if(name.equals(CP_Core.METADATA)) {
			return DweezilUIManager.getIcon(ICON_MD);
		}
		else if(name.equals(CP_Core.RESOURCES)) {
			return DweezilUIManager.getIcon(ICON_RESOURCES);
		}
		else if(name.equals(CP_Core.RESOURCE)) {
			return DweezilUIManager.getIcon(ICON_RESOURCE);
		}
		//else if(name.equals(CP_Core.TITLE)) {
		//    return DweezilUIManager.getIcon(ICON_TITLE);
		//}
		else if(name.equals(CP_Core.DEPENDENCY)) {
			return DweezilUIManager.getIcon(ICON_DEPENDENCY);
		}
		else {
			return DweezilUIManager.getIcon(ICON_MDLEAF);
		}
	}
	
	/**
	 * Get The Open Icon
	 */
	public Icon getOpenIcon(String name, Namespace ns) {
		return getLeafIcon(name, ns);
	}
	
	/**
	 * Get The Closed Icon
	 */
	public Icon getClosedIcon(String name, Namespace ns) {
		return getLeafIcon(name, ns);
	}
	
	
    public static SchemaModel getImslipModel() {
        if (imslipModel == null) {
            //return imslipModel;
            
            try {
                imslipModel = new SchemaModel(fileSchemaLIP10_1, "learnerinformation");
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (SchemaException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        return imslipModel;
        
    }
    public static SchemaModel getImsPartcpnModel() {
        if (imsPartcpnModel == null) {
             try {
                imsPartcpnModel = new SchemaModel(fileSchemaIMSPARTICIPATION, "participation");
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (SchemaException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }    
        }
        return imsPartcpnModel;
       
    }
    public static SchemaModel getImsRdceoModel() {
        if (imsRdceoModel == null) {
            try {
                imsRdceoModel = new SchemaModel(fileSchemaIMSRDCEO, "rdceo");
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (SchemaException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        } return imsRdceoModel; 
        
    }
    public static SchemaModel getImsReflexModel() {
        if (imsReflexModel == null) {
            try {
                imsReflexModel = new SchemaModel(fileSchemaIMSREFLEX, "reflexion");
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (SchemaException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } 
        }  
        return imsReflexModel;
       
    }
    public static SchemaModel getImsRubricModel() {
        if (imsRubricModel == null) {
               try {
                imsRubricModel = new SchemaModel(fileSchemaIMSRUBRIC, "rubric");
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (SchemaException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        } 
        return imsRubricModel; 
    }
    
    public static SchemaModel getImsRubricCellModel() {
        if (imsRubricModel == null) {
               try {
                imsRubricModel = new SchemaModel(fileSchemaIMSRUBRIC, "rubricCell");
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (SchemaException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        } 
        return imsRubricModel; 
    }
    
    public static SchemaModel getImsAssertnModel() {
        if (imsRubricModel == null) {
               try {
                imsRubricModel = new SchemaModel(fileSchemaIMSASSERT, "assertion");
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (SchemaException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        } 
        return imsRubricModel; 
    }
    
}