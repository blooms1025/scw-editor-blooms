/**
 *  RELOAD TOOLS
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Phillip Beauvoir
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Phillip Beauvoir
 *  e-mail:   p.beauvoir@bolton.ac.uk
 *
 *  Web:      http://www.reload.ac.uk
 *
 */

package uk.ac.reload.editor.eportfolio.editor;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;

import uk.ac.reload.dweezil.gui.DweezilFileChooser;
import uk.ac.reload.dweezil.gui.DweezilFileFilter;
import uk.ac.reload.dweezil.gui.DweezilToolBar;
import uk.ac.reload.dweezil.gui.ErrorDialogBox;
import uk.ac.reload.editor.EditorFrame;
import uk.ac.reload.editor.Messages;
import uk.ac.reload.editor.eportfolio.editor.xml.EP10_SchemaController;
import uk.ac.reload.editor.eportfolio.editor.xml.EPContentPackage;
import uk.ac.reload.editor.eportfolio.gen.xml.GenEPSchemaController;
import uk.ac.reload.editor.genschema.GenMetadata;
import uk.ac.reload.editor.genschema.GenSchemaEditorPanel;
import uk.ac.reload.editor.menu.Menu_Edit;
import uk.ac.reload.jdom.XMLUtils;
import uk.ac.reload.moonunit.schema.SchemaException;
import uk.ac.reload.moonunit.schema.SchemaModel;

/**
 * XML fragment editor dialog for editing IMS-LIP/EP data from within IMS EP
 * content package interfaces
 * based on Reload MDEditorDialog by Phil
 *  
 */
public class EPFragment_EditorDialog extends JDialog {

    /**
     * The Metadata Editor Panel
     */
    private GenSchemaEditorPanel _mdEditorPanel;

    /**
     * The EP Content Package to which this Element belongs
     */
    private EPContentPackage _contentPackage;

    /**
     * The parent element containing lom
     */
    private Element _mdElement;

    private GenMetadata instance;

    
    private String epFileName =""; //$NON-NLS-1$

    private  File epFileHandle;
    /**
     * Constructor
     * 
     * @param contentPackage
     *            The Content Package that is the parent Document
     * @param epReourceElement
     *            The "metadata" Element in the Content Package
     * @throws JDOMException
     * @throws IOException
     * @throws SchemaException
     */
    public EPFragment_EditorDialog(EPContentPackage contentPackage,
            Element epReourceElement) throws JDOMException, IOException,
            SchemaException {
        super(EditorFrame.getInstance(),
                Messages.getString("EPFragment_EditorDialog.1") //$NON-NLS-1$
                        + " - " + contentPackage.getProjectName(), //$NON-NLS-1$
                true);

        _contentPackage = contentPackage;
        _mdElement = epReourceElement;

        // Trap window closing event for our Window listener
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

        // Add a listener to Close our window down on exit
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });

        // Menu Bar
        JMenuBar menuBar = new JMenuBar();
        setJMenuBar(menuBar);
        Menu_Edit editMenu = new Menu_Edit();
        menuBar.add(editMenu);

        // ToolBar
        DweezilToolBar toolBar = createToolBar(editMenu);
        getContentPane().add(toolBar, BorderLayout.NORTH);

        // Add MD Editor
        _mdEditorPanel = new GenSchemaEditorPanel(editMenu);
        getContentPane().add(_mdEditorPanel, BorderLayout.CENTER);

        // We'll put the Prefs Panel here, actually!
        //toolBar.add(_mdEditorPanel.getPrefsPanel());

        // Button Panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));

        // OK Button
        JButton btnOK = new JButton(Messages.getString("EPFragment_EditorDialog.2"));  //$NON-NLS-1$
        btnOK.addActionListener(new OKClick());
        getRootPane().setDefaultButton(btnOK);
        buttonPanel.add(btnOK);

        // Cancel Buttton
        JButton btnCancel = new JButton(Messages.getString("EPFragment_EditorDialog.3")); //$NON-NLS-1$
        btnCancel.addActionListener(new CancelClick());
        buttonPanel.add(btnCancel);

        // Left Panel
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new FlowLayout(FlowLayout.LEFT));


        // Export Button
        JButton btnSaveAs = new JButton(Messages.getString("EPFragment_EditorDialog.4"));  //$NON-NLS-1$
        btnSaveAs.setToolTipText(Messages.getString("EPFragment_EditorDialog.5")); //$NON-NLS-1$
        btnSaveAs.addActionListener(new SaveAsEPFragment());
        leftPanel.add(btnSaveAs);

        // Add bottom Panel
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.add(leftPanel, BorderLayout.WEST);
        bottomPanel.add(buttonPanel, BorderLayout.EAST);
        getContentPane().add(bottomPanel, BorderLayout.SOUTH);

        // Dialog Size
        setSize(EditorFrame.getInstance().getWidth() * 3 / 4, EditorFrame
                .getInstance().getHeight() * 3 / 4);
        setLocationRelativeTo(EditorFrame.getInstance());

        // create the necessary jdom document for editing
        createMetadataDocument(contentPackage, epReourceElement);
    }

    /**
     * Create a eportfolio fragment Document for Editing
     * 
     * @throws JDOMException
     * @throws IOException
     * @throws SchemaException
     */
    protected void createMetadataDocument(EPContentPackage cp,
            Element epResourceElement) throws JDOMException, IOException,
            SchemaException {
        // Firstly, we have to find what sort of lip/ep file resource this is..

        String epFragmentType = epResourceElement.getAttribute("type") //$NON-NLS-1$
                .getValue();
        Element fileElement = epResourceElement.getChild("file", //$NON-NLS-1$
                epResourceElement.getNamespace());
            if ((fileElement != null)&& (fileElement.getAttribute("href") != null)) {
             epFileName = fileElement.getAttribute("href").getValue(); //$NON-NLS-1$

            // check if it is not null
            if (!("".equals(epFileName))) { //$NON-NLS-1$
                File epFile = new File(cp.getProjectFolder(), epFileName);
                if (epFile.exists()) {
                    epFileHandle = epFile;
                    // read the file and open in metadata view
                    Document epDoc = XMLUtils.readXMLFile(epFile);
                    
                    String schemaLocn = XMLUtils.getSchemaLocation(epDoc,
                            XMLUtils.getDocumentNamespace(epDoc));

                    
                    if (schemaLocn.indexOf("http") == -1) { //$NON-NLS-1$
                        schemaLocn = cp.getFile().getParent() + File.separator
                                + schemaLocn;
                    }

                       instance = new GenMetadata(epDoc, schemaLocn);

                    _mdEditorPanel.setDocument(instance);
                    _mdEditorPanel.getUndoManager().setFocusGained();

                    //FIXME
                } else {
                  
                    createNewFragment(epFragmentType);

                }
                    
                }else {
                
                    createNewFragment(epFragmentType);

            }

        } else {
            // we need to create a new LIP or EP fragment
            createNewFragment(epFragmentType);
        }

    }

    /**
     * @param epFragmentType
     * @throws JDOMException
     * @throws SchemaException
     * @throws IOException
     */
    private void createNewFragment(String epFragmentType) throws JDOMException, SchemaException, IOException {
        if (epFragmentType.indexOf("imslip") != -1) { //$NON-NLS-1$
            //load IMS LIP schema
            SchemaModel lipModel = EP10_SchemaController.getImslipModel();
            GenEPSchemaController controller = new GenEPSchemaController(
                    lipModel);
            
            instance = new GenMetadata(controller);
            // now identify the type underneath this element and add a child
            // element
            // new document
            if (epFragmentType.equals("imslip-Accessibility")) { //$NON-NLS-1$
                instance
                        .addElementBySchema(null,
                                instance.getRootElement(), lipModel
                                        .getRootElement().getChild(
                                                "accessibility"), false); //$NON-NLS-1$
                
            } else if (epFragmentType.equals("imslip-Activity")) { //$NON-NLS-1$
                instance.addElementBySchema(null,
                        instance.getRootElement(), lipModel
                                .getRootElement().getChild("activity"), //$NON-NLS-1$
                        false);
            } else if (epFragmentType.equals("imslip-Affiliation")) { //$NON-NLS-1$
                instance.addElementBySchema(null,
                        instance.getRootElement(), lipModel
                                .getRootElement().getChild("affiliation"), //$NON-NLS-1$
                        false);
            } else if (epFragmentType.equals("imslip-Competency")) { //$NON-NLS-1$
                instance.addElementBySchema(null,
                        instance.getRootElement(), lipModel
                                .getRootElement().getChild("competency"), //$NON-NLS-1$
                        false);

            } else if (epFragmentType.equals("imslip-Goal")) { //$NON-NLS-1$
                instance.addElementBySchema(null,
                        instance.getRootElement(), lipModel
                                .getRootElement().getChild("goal"), false); //$NON-NLS-1$
            }

            else if (epFragmentType.equals("imslip-Identification")) { //$NON-NLS-1$
                instance.addElementBySchema(null,
                        instance.getRootElement(), lipModel
                                .getRootElement()
                                .getChild("identification"), false); //$NON-NLS-1$
            } else if (epFragmentType.equals("imslip-Interests")) { //$NON-NLS-1$
                instance.addElementBySchema(null,
                        instance.getRootElement(), lipModel
                                .getRootElement().getChild("interest"), //$NON-NLS-1$
                        false);

            } else if (epFragmentType.equals("imslip-Product")) { //$NON-NLS-1$
                instance.addElementBySchema(null,
                        instance.getRootElement(), lipModel
                                .getRootElement().getChild("activity"), //$NON-NLS-1$
                        false);
                instance.addElementBySchema(null,
                        instance.getRootElement(), lipModel
                                .getRootElement().getChild("product"), //$NON-NLS-1$
                        false);
            } else if (epFragmentType.equals("imslip-QCL")) { //$NON-NLS-1$
                instance.addElementBySchema(null,
                        instance.getRootElement(), lipModel
                                .getRootElement().getChild("qcl"), false); //$NON-NLS-1$

            } else if (epFragmentType.equals("imslip-Relationship")) { //$NON-NLS-1$
                instance.addElementBySchema(null,
                        instance.getRootElement(), lipModel
                                .getRootElement().getChild("relationship"), //$NON-NLS-1$
                        false);
            } else if (epFragmentType.equals("imslip-SecurityKey")) { //$NON-NLS-1$
                instance.addElementBySchema(null,
                        instance.getRootElement(), lipModel
                                .getRootElement().getChild("securitykey"), //$NON-NLS-1$
                        false);
            } else if (epFragmentType.equals("imslip-Transcript")) { //$NON-NLS-1$
                instance.addElementBySchema(null,
                        instance.getRootElement(), lipModel
                                .getRootElement().getChild("transcript"), //$NON-NLS-1$
                        false);
            }

        } else if (epFragmentType.indexOf("imsep") != -1) { //$NON-NLS-1$
            //load ePortfolio schema
            SchemaModel epModel = null;
            if (epFragmentType.equals("imsep-Assertion")) { //$NON-NLS-1$
                epModel = EP10_SchemaController.getImsAssertnModel();
            } else if (epFragmentType.equals("imsep-Reflexion")) { //$NON-NLS-1$
                epModel = EP10_SchemaController.getImsReflexModel();
            } else if (epFragmentType.equals("imsep-RubricCell")) { //$NON-NLS-1$
                epModel = EP10_SchemaController.getImsRubricCellModel();
            } else if (epFragmentType.equals("imsep-Rubric")) { //$NON-NLS-1$
                epModel = EP10_SchemaController.getImsRubricModel();
            } /*else if (epFragmentType.equals("imsep-PortfolioPackage")) {
                //what to do here ? is it needed ??
                //FIXME
            }*/

            if(epModel != null) {
            GenEPSchemaController controller = new GenEPSchemaController(
                    epModel);
            instance = new GenMetadata(controller);
            }
            
        } else if (epFragmentType.indexOf("imses") != -1) { //$NON-NLS-1$
            //load enterprise specification schema
            if (epFragmentType.equals("imses-Participation")) { //$NON-NLS-1$
                SchemaModel epPartcpnModel = EP10_SchemaController
                        .getImsPartcpnModel();
                GenEPSchemaController controller = new GenEPSchemaController(
                        epPartcpnModel);
                instance = new GenMetadata(controller);
            }
        }

        // Edit a new document
        //FIXME
        
        if (instance != null) {
            _mdEditorPanel.setDocument(instance);
            _mdEditorPanel.getUndoManager().setFocusGained();
        }
        
    }

    

    /**
     * Export a standalone MD File
     */
    protected void saveAsEPFragment() {
        try {
            // Ask for the File Name
            DweezilFileFilter filter = new DweezilFileFilter(
                    new String[] { "xml" }, "xml files"); //$NON-NLS-1$ //$NON-NLS-2$
            File file = DweezilFileChooser
                    .askFileNameSave(
                            this,
                            Messages.getString("EPFragment_EditorDialog.44"), filter, "xml");  //$NON-NLS-1$ //$NON-NLS-2$
            if (file != null) {
                GenMetadata md = _mdEditorPanel.getMetadata();
                        
                md.saveAsDocument(file);
            }
        } catch (IOException ex) {
            ErrorDialogBox
                    .showWarning(
                            Messages.getString("EPFragment_EditorDialog.46"), //$NON-NLS-1$
                            Messages.getString("EPFragment_EditorDialog.47"), //$NON-NLS-1$
                            ex);
        }
    }

    /**
     * Show the Dialog
     */
    public void showDialog() {
        // Do this later because a modal dialog will block
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                _mdEditorPanel.initView();
            }
        });

        super.setVisible(true);
    }

    /**
     * User pressed OK
     */
    protected void finish() {
        // Get the Metadata from the Editor
        GenMetadata md = _mdEditorPanel.getMetadata();

        // If user edited the MD
        if (md.isDirty()) {
            // first get file name 
            //if null ask for file name else save to the existig file handle
            try {
            if(epFileHandle == null){
                DweezilFileFilter filter = new DweezilFileFilter(
                        new String[] { "xml" }, "xml files"); //$NON-NLS-1$ //$NON-NLS-2$
                File file = DweezilFileChooser
                        .askFileNameSave(
                                this,
                                "Save this EP fragment as ", filter, "xml"); //$NON-NLS-1$ //$NON-NLS-2$
                if (file != null) {
                   
                        md.saveAsDocument(file);
                    
                }
            }else{
                md.saveAsDocument(epFileHandle);
            }
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            // Tell listeners
            _contentPackage.changedElement(this, _mdElement);
            
        }

        // Finished
        dispose();
    }

    /**
     * Dispose and Clean up
     */
    public void dispose() {
        cleanup();
        super.dispose();
    }

    /**
     * Clean up
     */
    public void cleanup() {
        _mdEditorPanel.destroy();
    }

    /**
     * Create the Toolbar.
     * 
     * @return The Toolbar
     */
    private DweezilToolBar createToolBar(Menu_Edit editMenu) {
        DweezilToolBar tBar = new DweezilToolBar();

        // Undo
        tBar.add(editMenu.actionUndo);

        // Redo
        tBar.add(editMenu.actionRedo);

        // Add a separator
        tBar.addSeparator();

        // Cut
        tBar.add(editMenu.actionCut);

        // Copy
        tBar.add(editMenu.actionCopy);

        // Paste
        tBar.add(editMenu.actionPaste);

        // Delete
        tBar.add(editMenu.actionDelete);

        // Add a separator
        tBar.addSeparator();

        // Move Up
        tBar.add(editMenu.actionMoveUp);

        // Move Down
        tBar.add(editMenu.actionMoveDown);

        // Add a separator
        tBar.addSeparator();

        return tBar;
    }

    /**
     * Export a Metadata file
     */
    private class SaveAsEPFragment extends AbstractAction {
        public void actionPerformed(ActionEvent e) {
            saveAsEPFragment();
        }
    }

  

    /**
     * OK handler
     */
    private class OKClick extends AbstractAction {
        public void actionPerformed(ActionEvent e) {
            finish();
        }
    }

    /**
     * Cancel handler
     */
    private class CancelClick extends AbstractAction {
        public void actionPerformed(ActionEvent e) {
            dispose();
        }
    }

}