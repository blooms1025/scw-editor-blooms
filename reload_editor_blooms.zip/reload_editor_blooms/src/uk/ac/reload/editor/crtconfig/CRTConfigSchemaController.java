/**
 *  Content Re-Engineerng Tool
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Roy P Cherian
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Roy P Cherian
 *  e-mail:   rc3@bolton.ac.uk
 *
 *
 */
package uk.ac.reload.editor.crtconfig;

import java.io.File;
import java.io.IOException;

import org.jdom.JDOMException;

import uk.ac.reload.editor.genschema.GenSchemaController;
import uk.ac.reload.moonunit.schema.SchemaException;

/**
 * @author Roy P Cherian
 *
 * TODO
 */
public class CRTConfigSchemaController extends GenSchemaController {

    
    /**
     * @param file
     * @param root
     * @throws JDOMException
     * @throws SchemaException
     * @throws IOException
     */
    public CRTConfigSchemaController(String version, File file, String root) throws JDOMException, SchemaException, IOException {
        super(version, file, root);
        //defaultProfile = "CRT Config Profile";
        // TODO Auto-generated constructor stub
    }

    public String getDefaultProfileName() {
        // TODO Auto-generated method stub
        return "CRT Config Profile";
    }
    public File getProfileFolder() {
        // TODO Auto-generated method stub
        return CRTConfigEditorHandler.PROFILE_FOLDER;
    }
    public File getSchemaHelperFolder() {
        // TODO Auto-generated method stub
        return CRTConfigEditorHandler.SCHEMAHELPER_FOLDER;
    }
    public File getVocabFolder() {
        // TODO Auto-generated method stub
        return CRTConfigEditorHandler.VOCAB_FOLDER;
    }
}
