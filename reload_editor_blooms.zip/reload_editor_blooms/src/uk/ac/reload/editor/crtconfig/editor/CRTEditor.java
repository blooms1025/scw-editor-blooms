/**
 *  Content Re-Engineerng Tool
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Roy P Cherian
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Roy P Cherian
 *  e-mail:   rc3@bolton.ac.uk
 *
 *
 */
package uk.ac.reload.editor.crtconfig.editor;

import java.io.File;
import java.io.IOException;

import javax.swing.JFileChooser;

import uk.ac.reload.dweezil.gui.DweezilFileFilter;
import uk.ac.reload.dweezil.gui.ErrorDialogBox;
import uk.ac.reload.editor.EditorHandler;
import uk.ac.reload.editor.Messages;
import uk.ac.reload.editor.metadata.editor.MD_Editor;
import uk.ac.reload.editor.metadata.xml.Metadata;

public class CRTEditor extends MD_Editor {

    public CRTEditor() {
        super();
        // TODO Auto-generated constructor stub
    }

    public CRTEditor(Metadata md) {
        super(md);
        setTitle("CRT configuration file");
        // TODO Auto-generated constructor stub
    }

    @Override
    protected boolean saveDocument() {
        // TODO Auto-generated method stub
        //return super.saveDocument();
        // If we don't have a file name, ask for one
        if(_mdEditorPanel.getMetadata().getFile() == null) {
            return saveAsDocument();
        }else {
            return super.saveDocument();
        }
        
    }

    @Override
    protected boolean saveAsDocument() {
        // TODO Auto-generated method stub
        //      Ask for name
        DweezilFileFilter filter = new DweezilFileFilter(new String[] {"xml"}, "xml files"); //$NON-NLS-1$ //$NON-NLS-2$
        //File file = DweezilFileChooser.askFileNameSave(this, Messages.getString("uk.ac.reload.editor.metadata.MD_Editor.5"), filter, "xml"); //$NON-NLS-1$ //$NON-NLS-2$
        
        String fname = "root.xml";
        if(_mdEditorPanel.getMetadata().getRootElement().getName().equals("root")) {
            ;
        }else if(_mdEditorPanel.getMetadata().getRootElement().getName().equals("config")) {
            fname = "config.xml";
            
        }else if(_mdEditorPanel.getMetadata().getRootElement().getName().equals("iotransform")) {
            fname = "iotransform.xml";
            
        }
        
        JFileChooser fc = new JFileChooser();
        fc.addChoosableFileFilter(filter);
        fc.setSelectedFile(new File(fname));
        fc.showSaveDialog(this);
        File file = fc.getSelectedFile();
        
        // User cancelled
        if(file == null)  return false;

        try {
            _mdEditorPanel.getMetadata().saveAsDocument(file);
        }
        catch(IOException ex) {
            ErrorDialogBox.showWarning(this,
                    Messages.getString("uk.ac.reload.editor.metadata.MD_Editor.6"), //$NON-NLS-1$
                    Messages.getString("uk.ac.reload.editor.metadata.MD_Editor.5"), //$NON-NLS-1$
                    ex);
            return false;
        }

        // Set Title bar
        setTitle(Messages.getString("uk.ac.reload.editor.metadata.MD_Editor.0") + " - " + file.getPath()); //$NON-NLS-1$ //$NON-NLS-2$

        // Put it in the opened list
        EditorHandler.getSharedInstance().registerOpenedFile(file, this);

        return true;
        
    }

}
