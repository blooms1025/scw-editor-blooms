/**
 *  Content Re-Engineerng Tool
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Roy P Cherian
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Roy P Cherian
 *  e-mail:   rc3@bolton.ac.uk
 *
 *
 */
package uk.ac.reload.editor.crtconfig;

import java.io.File;
import java.io.IOException;
import java.util.Hashtable;

import javax.swing.Icon;

import org.jdom.Document;
import org.jdom.JDOMException;
import org.jdom.Namespace;

import uk.ac.reload.dweezil.util.DweezilUIManager;
import uk.ac.reload.editor.EditorHandler;
import uk.ac.reload.editor.EditorInternalFrame;
import uk.ac.reload.editor.IEditorHandler;
import uk.ac.reload.editor.IIcons;
import uk.ac.reload.editor.crtconfig.editor.CRTConfig_NewDialog;
import uk.ac.reload.editor.crtconfig.editor.CRTEditor;
import uk.ac.reload.editor.metadata.editor.MD_Editor;
import uk.ac.reload.jdom.XMLUtils;
import uk.ac.reload.moonunit.SchemaController;
import uk.ac.reload.moonunit.schema.SchemaException;

/**
 * @author Roy P Cherian
 *
 * TODO
 */
public class CRTConfigEditorHandler implements IEditorHandler, IIcons
{
    // ==========================================================================================
    
    public static final String CRT_CP_CONFIG = "Content Package configuration"; //$NON-NLS-1$
    public static final String CRT_ROOT_CONFIG = "Schema Root Configuration"; //$NON-NLS-1$
    public static final String CRT_XSL_CONFIG = "XSL transform configuration"; //$NON-NLS-1$
   
    
    
    public static Namespace CP_CONFIG_NAMESPACE = Namespace.getNamespace("http://www.bolton.ac.uk/telcert/crt/cpconfig"); //$NON-NLS-1$
    public static Namespace ROOT_CONFIG_NAMESPACE = Namespace.getNamespace("http://www.bolton.ac.uk/telcert/crt/root"); //$NON-NLS-1$
    public static Namespace XSL_CONFIG_NAMESPACE = Namespace.getNamespace("http://www.bolton.ac.uk/telcert/crt/iotransform"); //$NON-NLS-1$
   

    // ==========================================================================================
    
    //Schema file
    public static File fileSchemaCPConfig = new File(new File(EditorHandler.SCHEMAMODELFOLDER,
            											"crtconfig"), "config.xsd");
    public static File fileSchemaRootConfig = new File(new File(EditorHandler.SCHEMAMODELFOLDER,
    													"crtconfig"), "root.xsd");
    public static File fileSchemaXSLConfig = new File(new File(EditorHandler.SCHEMAMODELFOLDER,
    													"crtconfig"), "iotransform.xsd");
    
    // ==========================================================================================
    
    
    static Hashtable SUPPORTED_NAMESPACES = new Hashtable();
    
    static {
		// Add to table of Supported Namespaces mapped to Version names
		SUPPORTED_NAMESPACES.put(CP_CONFIG_NAMESPACE, CRT_CP_CONFIG);
		SUPPORTED_NAMESPACES.put(ROOT_CONFIG_NAMESPACE, CRT_ROOT_CONFIG);
		SUPPORTED_NAMESPACES.put(XSL_CONFIG_NAMESPACE, CRT_XSL_CONFIG);		
    }
    
    public static final File HELPER_FOLDER = new File(EditorHandler.HELPERFOLDER, "crtconfig"); //$NON-NLS-1$
    public static final File PROFILE_FOLDER = new File(HELPER_FOLDER, "profile"); //$NON-NLS-1$
    public static final File SCHEMAHELPER_FOLDER = new File(HELPER_FOLDER, "schemahelper"); //$NON-NLS-1$
    public static final File VOCAB_FOLDER = new File(HELPER_FOLDER, "vocab"); //$NON-NLS-1$
    
    // ==========================================================================================

    /**
	 * Constructor
	 */
	public CRTConfigEditorHandler() {

	}
	
    /* (non-Javadoc)
     * @see uk.ac.reload.editor.IEditorHandler#canCreateDocuments()
     */
    public boolean canCreateDocuments() {
        return true;
    }

    /* (non-Javadoc)
     * @see uk.ac.reload.editor.IEditorHandler#canEditFile(java.io.File)
     */
    public boolean canEditFile(File file) {
		// Try to load the Document
		Document doc;
        try {
            doc = XMLUtils.readXMLFile(file);
        }
        catch(Exception ex) {
            return false;
        } 
        
        // The first thing we do is to see if there is a root Namespace in the Document
		Namespace nameSpace = XMLUtils.getDocumentNamespace(doc);
		
		// No Namespace, sorry we don't know what it is!
		if(nameSpace == null || nameSpace.equals(Namespace.NO_NAMESPACE)) {
		    return false;
		}
		
		
		// And simply check against our list of supported Namespaces
		return SUPPORTED_NAMESPACES.containsKey(nameSpace);
	}

	
    /* (non-Javadoc)
     * @see uk.ac.reload.editor.IEditorHandler#editFile(java.io.File)
     */
    public EditorInternalFrame editFile(File file) throws JDOMException, SchemaException, IOException {
        ConfigSchemaDocument md = new ConfigSchemaDocument(file);
    	//return new MD_Editor(md);
        return new CRTEditor(md);
    }
    

	/* (non-Javadoc)
	 * @see uk.ac.reload.editor.IEditorHandler#newDocument()
	 */
	public EditorInternalFrame newDocument() throws JDOMException, SchemaException, IOException {
		String version = CRT_ROOT_CONFIG;

        String[] versionsCRT = getSupportedVersions();
        CRTConfig_NewDialog dialog = new CRTConfig_NewDialog(versionsCRT,
                version);
        int response = dialog.showDialog();
        if (response == CRTConfig_NewDialog.OK_OPTION) {
            // Get chosen version
            version = dialog.getVersion();
        } else {
            return null;
        }

        CRTConfigSchemaController controller = (CRTConfigSchemaController) getSchemaControllerInstance(version);
        ConfigSchemaDocument md = new ConfigSchemaDocument(controller);
        //return new MD_Editor(md);
        return new CRTEditor(md);
        
	}
	
	
	/* (non-Javadoc)
	 * @see uk.ac.reload.editor.IEditorHandler#getName()
	 */
	public String getName() {
	    //return Messages.getString("uk.ac.reload.editor.metadata.MD_EditorHandler.0"); //$NON-NLS-1$
	    return "CRT Configuration File"; //$NON-NLS-1$
	}
	
	/* (non-Javadoc)
	 * @see uk.ac.reload.editor.IEditorHandler#getIcon()
	 */
	public Icon getIcon() {
	    return DweezilUIManager.getIcon(ICON_MD);
	}

	/* (non-Javadoc)
	 * @see uk.ac.reload.editor.IEditorHandler#getSupportedVersions()
	 */
	public String[] getSupportedVersions() {
	    return new String[] {
	            CRT_ROOT_CONFIG,
	            CRT_CP_CONFIG,
	            CRT_XSL_CONFIG
	    };
	}

	/**
	 * @return The default Version to use in new documents
	 */
	public String getDefaultVersion() {
	    return CRT_ROOT_CONFIG;
	}
	
	/**
	 * @param ns Namespace
	 * @return A version depending on Namespace
	 */
	public String getVersion(Namespace ns) {
	    return ns == null ? null : (String)SUPPORTED_NAMESPACES.get(ns);
	}

	/* (non-Javadoc)
	 * @see uk.ac.reload.editor.IEditorHandler#getSchemaControllerInstance(java.lang.String)
	 */
    public SchemaController getSchemaControllerInstance(String version) throws JDOMException, SchemaException, IOException {
        SchemaController schemaController = null;
        if(CRT_CP_CONFIG.equals(version)) {
            schemaController = new CRTConfigSchemaController("CRT CP Config 1.0", fileSchemaCPConfig, "config");
        }
        else if(CRT_ROOT_CONFIG.equals(version)) {
            schemaController = new CRTConfigSchemaController("CRT Schema Root Config 1.0", fileSchemaRootConfig, "root");
        } else if(CRT_XSL_CONFIG.equals(version)) {            
            schemaController =  new CRTConfigSchemaController("CRT XSL Config 1.0", fileSchemaXSLConfig, "iotransform");
        }
        return schemaController;
    }

    
    /**
     * return a hashtable of supported IMS MD namespaces
     */
    public static Hashtable getSUPPORTED_NAMESPACES() {
        return SUPPORTED_NAMESPACES;
    }
}
