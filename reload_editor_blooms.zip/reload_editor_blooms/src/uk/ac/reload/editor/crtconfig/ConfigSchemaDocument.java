/**
 *  Content Re-Engineerng Tool
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Roy P Cherian
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Roy P Cherian
 *  e-mail:   rc3@bolton.ac.uk
 *
 *
 */
package uk.ac.reload.editor.crtconfig;

import java.io.File;
import java.io.IOException;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.Namespace;

import uk.ac.reload.editor.EditorHandler;
import uk.ac.reload.editor.Messages;
import uk.ac.reload.editor.metadata.xml.Metadata;
import uk.ac.reload.editor.properties.EditorProperties;
import uk.ac.reload.jdom.XMLUtils;
import uk.ac.reload.moonunit.schema.SchemaException;
import uk.ac.reload.moonunit.schema.SchemaModel;

/**
 * @author Roy P Cherian
 *
 * TODO
 */
public class ConfigSchemaDocument extends Metadata {
   
    /**
     * Constructor for blank MD
     */
    public ConfigSchemaDocument(CRTConfigSchemaController controller) {

        if (controller == null)
            System.err.println(Messages.getString("GenMetadata.0")); //$NON-NLS-1$

        setSchemaController(controller);
        setDocument(new Document());
        // Add our signature
        addCommentsToDocument();

        // Add Root Element according to Schema and children
        if (controller != null) {
            SchemaModel mdSchema = controller.getSchemaModel();
            Element root = addElementBySchema(this, null, mdSchema
                    .getRootElement(), true);
            getDocument().setRootElement(root);
            addRootDeclarations();

        }
        // Clear the dirty flag because adding the root made it dirty
        setDirty(false);
    }

    /**
     * Constructor for a schema instance that exists
     * 
     * @throws JDOMException
     * @throws IOException
     * @throws SchemaException
     */
    public ConfigSchemaDocument(Document doc) throws JDOMException, SchemaException,
            IOException {
        if (doc == null) {
            throw new NullPointerException(Messages.getString("GenMetadata.1")); //$NON-NLS-1$
        }

        // Load the Document
        setDocument(doc);
        // Get the Schema Controller *after* setting the doc
        loadSchemaControllerInstance();
    }

    /**
     * Constructor for a schema instance File that exists - will be Standalone
     * 
     * @throws JDOMException
     * @throws IOException
     * @throws SchemaException
     */
    public ConfigSchemaDocument(File file) throws JDOMException, SchemaException,
            IOException {
        if (file == null) {
            throw new NullPointerException(Messages.getString("GenMetadata.2")); //$NON-NLS-1$
        }
        setFile(file);

        // Load the Document
        setDocument(XMLUtils.readXMLFile(file));
        // Get the Schema Controller *after* setting the doc
        loadSchemaControllerInstance();
        

    }

  

    /**
     * Load the SchemaControllerInstance This attempts to load schema file from
     * the directory of the xml document
     * 
     * @throws JDOMException
     * @throws IOException
     * @throws SchemaException
     */
    /**
     * Load the SchemaControllerInstance  
     * @throws JDOMException
     * @throws IOException
     * @throws SchemaException
     */
    protected void loadSchemaControllerInstance() throws JDOMException, SchemaException, IOException {
    	// Get version from Namespace
    	Namespace nameSpace = XMLUtils.getDocumentNamespace(getDocument());
    	String version = EditorHandler.CRTConfig_EDITORHANDLER.getVersion(nameSpace);
    	// No, use default
    	if(version == null) {
    	    version = EditorHandler.CRTConfig_EDITORHANDLER.getDefaultVersion();
    	}

    	setSchemaController(EditorHandler.CRTConfig_EDITORHANDLER.getSchemaControllerInstance(version));
    }

 
   
    /**
     * @return the Comments to add to the XML Document
     */
    public String[] getComments() {
        return gen_comments;
    }

    /**
     * Our unique signature
     */
    static final String[] gen_comments = {
            "This is a Reload CRT version "
                    + EditorProperties.getString("VERSION")
                    + " editor cofiguration document",
            "Spawned from the Reload Metadata Generator - http://www.reload.ac.uk" };

    /**
     * Copy schema file to the folder of intance document
     */

    public void saveDocument() throws IOException {
        // TODO Auto-generated method stub
        super.saveDocument();  
    }

    public void destroy() {
        // TODO Auto-generated method stub
        super.destroy();
        
    }
}
