/**
 *  RELOAD TOOLS
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Phillip Beauvoir
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Phillip Beauvoir
 *  e-mail:   p.beauvoir@bolton.ac.uk
 *
 *  Web:      http://www.reload.ac.uk
 *
 */

package uk.ac.reload.editor.learningdesign.editor.activities;

import uk.ac.reload.dweezil.util.DweezilUIManager;
import uk.ac.reload.editor.learningdesign.datamodel.LD_Component;
import uk.ac.reload.editor.learningdesign.datamodel.components.activities.ActivityStructure;


/**
 * A List View to display Activity Structure contents
 * 
 * @author Phillip Beauvoir
 * @version $Id: ActivityStructureListPanel.java,v 1.1 2007/02/13 16:03:42 rp_cherian Exp $
 */
public class ActivityStructureListPanel
extends ActivityListPanel
{
    /**
     * Activity Selector Dialog
     */
    private ActivitySelectorDialog _dialog;
    
    /**
     * Default Constructor
     */
    public ActivityStructureListPanel() {
		super("Activities", DweezilUIManager.getIcon(ICON_ACTIVITYSTRUCTURES), 200);
    }
    
    /**
     * Update the Model
     */
    protected void updateListModel() {
        LD_Component[] components = ((ActivityStructure)_activity).getReferencedComponents();
        // Model
        getList().setModel(new ComponentListModel(components));
    }

    /* (non-Javadoc)
     * @see uk.ac.reload.editor.learningdesign.editor.shared.ComponentListPanel#showSelectorDialog()
     */
    protected void showSelectorDialog() {
	    if(_dialog == null) {
	        _dialog = new ActivitySelectorDialog();
	    }
	    
	    _dialog.setActivityStructure((ActivityStructure)_activity);
	    _dialog.setVisible(true);
    }
    
    /* (non-Javadoc)
     * @see uk.ac.reload.editor.learningdesign.editor.shared.ComponentListPanel#cleanup()
     */
    public void cleanup() {
        super.cleanup();
        
        if(_dialog != null) {
            _dialog.cleanup();
        }
    }
}
