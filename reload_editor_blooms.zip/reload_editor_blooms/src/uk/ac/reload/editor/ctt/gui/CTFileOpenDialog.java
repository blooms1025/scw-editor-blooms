/**
 *  RELOAD TOOLS
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Phillip Beauvoir
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Phillip Beauvoir
 *  e-mail:   p.beauvoir@bolton.ac.uk
 *
 *  Web:      http://www.reload.ac.uk
 *
 */
package uk.ac.reload.editor.ctt.gui;

import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.io.File;
import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import com.brunchboy.util.swing.relativelayout.AttributeConstraint;
import com.brunchboy.util.swing.relativelayout.AttributeType;
import com.brunchboy.util.swing.relativelayout.DependencyManager;
import com.brunchboy.util.swing.relativelayout.RelativeLayout;
import uk.ac.reload.dweezil.gui.DweezilFileChooser;
import uk.ac.reload.dweezil.gui.DweezilFileFilter;
import uk.ac.reload.dweezil.gui.DweezilFolderChooser;
import uk.ac.reload.editor.EditorFrame;
import uk.ac.reload.editor.Messages;

/**
 *For selecting the source and target schema names for doing transform 
 *  
 */
public class CTFileOpenDialog extends JDialog {
    
    /**
     * The File Chooser
     */
    private DweezilFileChooser _sourceChooser;
    
    private File sourceFile;
    
    private DweezilFolderChooser _targetChooser;
    
    private File targetFile;
    
    private RelativeLayout layout;
    
    private DweezilFileFilter filter;
    private JButton targetOpenBtn;
    private JButton srcOpenBtn;
    private JTextField txtSourceFile;
    private JTextField txtTargetFile;
    
    /**
     * c'str
     * @param sName
     * @param tName
     * @param parent
     * @throws HeadlessException
     */
    public CTFileOpenDialog(String sName, String tName, JFrame parent)
    throws HeadlessException {
        super(parent, Messages.getString("CTFileOpenDialog.0"), true); //$NON-NLS-1$
        init(sName, tName);		
        srcOpenBtn.addActionListener(new AbstractAction() {
            
            public void actionPerformed(ActionEvent evt) {
                // Show dialog; and get selected file
                sourceFile = DweezilFileChooser.askFileNameOpen(
                        CTFileOpenDialog.this, Messages.getString("CTFileOpenDialog.1"), filter); //$NON-NLS-1$
                if(sourceFile!= null)
                    txtSourceFile.setText(sourceFile.getName());
            }
        });
        
        
    }
    
    /**
     * c'str
     * @param sName
     * @param tName
     * @param manifest
     * @param parent
     * @throws HeadlessException
     */
    public CTFileOpenDialog(String sName, String tName, String manifest, JFrame parent)
    throws HeadlessException {
        super(parent, Messages.getString("CTFileOpenDialog.2"), true); //$NON-NLS-1$
        init(sName, tName);		
        txtSourceFile.setText(manifest);
        txtSourceFile.setEditable(false);
        srcOpenBtn.setEnabled(false);
        
    }
    
    
    /**
     * c'str for capturing source and target folders for XSLTing content
     * @param sName source file names
     * @param tName target file name
     * @param batch flag to indicate batch mode (recursive) or single 
     * @param parent parent frame
     * @throws HeadlessException
     */
    public CTFileOpenDialog(String sName, String tName, boolean batch, JFrame parent)
    throws HeadlessException {
        super(parent, Messages.getString("CTFileOpenDialog.4"), true); //$NON-NLS-1$
        init(sName, tName);
        _sourceChooser = new DweezilFolderChooser();
        
        srcOpenBtn.addActionListener(new AbstractAction() {
            public void actionPerformed(ActionEvent evt) {
                // Show dialog; and get selected file
                int rtn = _sourceChooser.showDialog(CTFileOpenDialog.this, Messages.getString("CTFileOpenDialog.70")); //$NON-NLS-1$
                // User Cancelled
                if(rtn != DweezilFolderChooser.APPROVE_OPTION) {
                    return;
                }
                // Get the chosen folder
                sourceFile = _sourceChooser.getSelectedFile();
                
                if(sourceFile!= null)
                    txtSourceFile.setText(sourceFile.getName());
            }
        });
        
        
    }
    
    /**
     * OK handler
     */
    private class OKClick extends AbstractAction {
        public void actionPerformed(ActionEvent e) {
            dispose();
        }
    }
    
    /**
     * Cancel handler
     */
    private class CancelClick extends AbstractAction {
        public void actionPerformed(ActionEvent e) {
            sourceFile = null;
            dispose();
        }
    }
    
    
    /**
     * @return The DweezilFileChooser
     */
    public DweezilFileChooser getSourceFileChooser() {
        return _sourceChooser;
    }
    
    /**
     * @return The DweezilFolderChooser
     */
    public DweezilFolderChooser getTargetFolderChooser() {
        return _targetChooser;
    }
    
    /*
     * 
     */
    public void showDialog() {
        show();
    }
    /**
     * @return Returns the sourceFile.
     */
    public File getSourceFile() {
        return sourceFile;
    }
    /**
     * @return Returns the targetFile.
     */
    public File getTargetFile() {
        return targetFile;
    }
    
    /**
     * Setup the dialog panel
     */
    protected void init(String sName, String tName) {
        setSize(500, 200);
        //setResizable(false);
        
        layout = new RelativeLayout();
        getContentPane().setLayout(layout);
        _sourceChooser = new DweezilFileChooser();
        _targetChooser = new DweezilFolderChooser();
        filter = new DweezilFileFilter(new String[] { "xml", "zip" }, //$NON-NLS-1$ //$NON-NLS-2$
                Messages.getString("uk.ac.reload.editor.EditorHandler.1")); //$NON-NLS-1$
        
        JLabel title = new JLabel(Messages.getString("CTFileOpenDialog.6")); //$NON-NLS-1$
        title.setFont(title.getFont().deriveFont(14.0f));
        getContentPane().add(title, "title"); //$NON-NLS-1$
        layout.addConstraint("title", AttributeType.TOP, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME,
                        AttributeType.TOP, 10));
        layout.addConstraint("title", AttributeType.HORIZONTAL_CENTER, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME,
                        AttributeType.HORIZONTAL_CENTER));
        
        // source schema label
        JLabel lblSchema = new JLabel(Messages.getString("CTFileOpenDialog.10")); //$NON-NLS-1$
        
        getContentPane().add(lblSchema, "lblSchema"); //$NON-NLS-1$
        layout.addConstraint("lblSchema", AttributeType.TOP, //$NON-NLS-1$
                new AttributeConstraint("title", AttributeType.BOTTOM, 5)); //$NON-NLS-1$
        
        layout.addConstraint("lblSchema", AttributeType.LEFT, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME,
                        AttributeType.LEFT, 20));
        
        // target schema label
        JLabel lbltchema = new JLabel(Messages.getString("CTFileOpenDialog.15")); //$NON-NLS-1$
        
        getContentPane().add(lbltchema, "lbltchema"); //$NON-NLS-1$
        
        layout.addConstraint("lbltchema", AttributeType.TOP, //$NON-NLS-1$
                new AttributeConstraint("lblSchema", AttributeType.TOP)); //$NON-NLS-1$
        layout.addConstraint("lbltchema", AttributeType.LEFT, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME,
                        AttributeType.LEFT, 250));
        
        // Source type text field
        JTextField txtSource = new JTextField(sName);
        txtSource.setEditable(false);
        getContentPane().add(txtSource, "txtSource"); //$NON-NLS-1$
        
        layout.addConstraint("txtSource", AttributeType.TOP, //$NON-NLS-1$
                new AttributeConstraint("lblSchema", AttributeType.BOTTOM, 5)); //$NON-NLS-1$
        
        layout.addConstraint("txtSource", AttributeType.LEFT, //$NON-NLS-1$
                new AttributeConstraint("lblSchema", AttributeType.LEFT)); //$NON-NLS-1$
        /*new AttributeConstraint(DependencyManager.ROOT_NAME,
         AttributeType.LEFT, 20));*/
        layout.addConstraint("txtSource", AttributeType.RIGHT, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME,
                        AttributeType.LEFT, 180));
        //new AttributeConstraint("lblSchema", AttributeType.RIGHT));
        
        // target type text field
        JTextField txtTarget = new JTextField(tName);
        txtTarget.setEditable(false);
        getContentPane().add(txtTarget, "txtTarget"); //$NON-NLS-1$
        
        layout.addConstraint("txtTarget", AttributeType.TOP, //$NON-NLS-1$
                new AttributeConstraint("lbltchema", AttributeType.BOTTOM, 5)); //$NON-NLS-1$
        layout.addConstraint("txtTarget", AttributeType.LEFT, //$NON-NLS-1$
                new AttributeConstraint("lbltchema", AttributeType.LEFT)); //$NON-NLS-1$
        layout.addConstraint("txtTarget", AttributeType.RIGHT, //$NON-NLS-1$
                new AttributeConstraint("lbltchema", //$NON-NLS-1$
                        AttributeType.LEFT, 180));
        //new AttributeConstraint("lbltchema", AttributeType.RIGHT));
        
        // for selecting source file folder
        
        JLabel lblSourceFile = new JLabel(Messages.getString("CTFileOpenDialog.33")); //$NON-NLS-1$
        
        getContentPane().add(lblSourceFile, "lblSourceFile"); //$NON-NLS-1$
        layout.addConstraint("lblSourceFile", AttributeType.TOP, //$NON-NLS-1$
                new AttributeConstraint("txtSource", AttributeType.BOTTOM, 10)); //$NON-NLS-1$
        layout.addConstraint("lblSourceFile", AttributeType.LEFT, //$NON-NLS-1$
                new AttributeConstraint("txtSource", AttributeType.LEFT)); //$NON-NLS-1$
        
        
        //		 add a text field for displaying selected source file
        //final JTextField txtSourceFile = new JTextField("");
        txtSourceFile = new JTextField(""); //$NON-NLS-1$
        
        txtSourceFile.setEditable(false);
        
        getContentPane().add(txtSourceFile, "txtSourceFile"); //$NON-NLS-1$
        
        layout.addConstraint("txtSourceFile", AttributeType.TOP, //$NON-NLS-1$
                new AttributeConstraint("lblSourceFile", AttributeType.BOTTOM, 5)); //$NON-NLS-1$
        layout.addConstraint("txtSourceFile", AttributeType.LEFT, //$NON-NLS-1$
                new AttributeConstraint("lblSourceFile", AttributeType.LEFT)); //$NON-NLS-1$
        layout.addConstraint("txtSourceFile", AttributeType.RIGHT, //$NON-NLS-1$
                new AttributeConstraint("txtSource", AttributeType.RIGHT)); //$NON-NLS-1$
        
        // add a button for open source file
        
        srcOpenBtn = new JButton();
        
        srcOpenBtn.setText("..."); //$NON-NLS-1$
        
        getContentPane().add(srcOpenBtn, "srcOpenBtn"); //$NON-NLS-1$
        
        layout.addConstraint("srcOpenBtn", AttributeType.TOP, //$NON-NLS-1$
                new AttributeConstraint("lblSourceFile", AttributeType.BOTTOM, 5)); //$NON-NLS-1$
        layout.addConstraint("srcOpenBtn", AttributeType.LEFT, //$NON-NLS-1$
                new AttributeConstraint("txtSourceFile", AttributeType.RIGHT)); //$NON-NLS-1$
        layout.addConstraint("srcOpenBtn", AttributeType.BOTTOM, //$NON-NLS-1$
                new AttributeConstraint("txtSourceFile", AttributeType.BOTTOM)); //$NON-NLS-1$
        
        // for selecting target file/folder
        
        JLabel lblTargetFile = new JLabel(Messages.getString("CTFileOpenDialog.55")); //$NON-NLS-1$
        
        getContentPane().add(lblTargetFile, "lblTargetFile"); //$NON-NLS-1$
        layout.addConstraint("lblTargetFile", AttributeType.TOP, //$NON-NLS-1$
                new AttributeConstraint("txtTarget", AttributeType.BOTTOM, 5)); //$NON-NLS-1$
        layout.addConstraint("lblTargetFile", AttributeType.LEFT, //$NON-NLS-1$
                new AttributeConstraint("txtTarget", AttributeType.LEFT)); //$NON-NLS-1$
        
        //		 add a text field for displaying selected target file
        //final JTextField txtTargetFile = new JTextField("");
        txtTargetFile = new JTextField(""); //$NON-NLS-1$
        
        txtTargetFile.setEditable(false);
        
        getContentPane().add(txtTargetFile, "txtTargetFile"); //$NON-NLS-1$
        
        layout.addConstraint("txtTargetFile", AttributeType.TOP, //$NON-NLS-1$
                new AttributeConstraint("lblTargetFile", AttributeType.BOTTOM, 5)); //$NON-NLS-1$
        layout.addConstraint("txtTargetFile", AttributeType.LEFT, //$NON-NLS-1$
                new AttributeConstraint("lblTargetFile", AttributeType.LEFT)); //$NON-NLS-1$
        layout.addConstraint("txtTargetFile", AttributeType.RIGHT, //$NON-NLS-1$
                new AttributeConstraint("txtTarget", AttributeType.RIGHT)); //$NON-NLS-1$
        //new AttributeConstraint("lblTargetFile", AttributeType.RIGHT, -20));
        
        //	 add a button for open target file
        
        targetOpenBtn = new JButton();
        targetOpenBtn.setText("..."); //$NON-NLS-1$
        targetOpenBtn.addActionListener(new AbstractAction() {
            public void actionPerformed(ActionEvent evt) {
                // Show dialog; and get selected file
                int rtn = getTargetFolderChooser().showDialog(CTFileOpenDialog.this, Messages.getString("CTFileOpenDialog.70")); //$NON-NLS-1$
                // User Cancelled
                if(rtn != DweezilFolderChooser.APPROVE_OPTION) {
                    return;
                }
                // Get the chosen folder
                targetFile = getTargetFolderChooser().getSelectedFileAndStore();
                
                if(targetFile!= null)
                    txtTargetFile.setText(targetFile.getName());
            }
        });
        
        
        getContentPane().add(targetOpenBtn, "targetOpenBtn"); //$NON-NLS-1$
        
        layout.addConstraint("targetOpenBtn", AttributeType.TOP, //$NON-NLS-1$
                new AttributeConstraint("lblTargetFile", AttributeType.BOTTOM, 5)); //$NON-NLS-1$
        layout.addConstraint("targetOpenBtn", AttributeType.LEFT, //$NON-NLS-1$
                new AttributeConstraint("txtTargetFile", AttributeType.RIGHT)); //$NON-NLS-1$
        layout.addConstraint("targetOpenBtn", AttributeType.BOTTOM, //$NON-NLS-1$
                new AttributeConstraint("txtTargetFile", AttributeType.BOTTOM)); //$NON-NLS-1$
        
        // Cancel Buttton
        JButton btnCancel = new JButton(Messages.getString("CTFileOpenDialog.3")); //$NON-NLS-1$
        btnCancel.addActionListener(new CancelClick());
        getContentPane().add(btnCancel, "btnCancel"); //$NON-NLS-1$
        
        layout.addConstraint("btnCancel", AttributeType.RIGHT, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME,
                        AttributeType.RIGHT));
        layout.addConstraint("btnCancel", AttributeType.BOTTOM, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME,
                        AttributeType.BOTTOM, -5));
        
        // OK Button
        JButton btnOK = new JButton(Messages.getString("CTFileOpenDialog.82")); //$NON-NLS-1$
        btnOK.addActionListener(new OKClick());
        getContentPane().add(btnOK, "btnOK"); //$NON-NLS-1$
        
        layout.addConstraint("btnOK", AttributeType.RIGHT, //$NON-NLS-1$
                new AttributeConstraint("btnCancel", AttributeType.LEFT, -5)); //$NON-NLS-1$
        layout.addConstraint("btnOK", AttributeType.BOTTOM, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME,
                        AttributeType.BOTTOM, -5));
        setLocationRelativeTo(EditorFrame.getInstance());
        
    }
    
}