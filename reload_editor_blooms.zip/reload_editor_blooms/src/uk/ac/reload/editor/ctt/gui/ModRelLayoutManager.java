/**
 *  Content Re-Engineerng Tool
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Roy P Cherian
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Roy P Cherian
 *  e-mail:   rc3@bolton.ac.uk
 *
 *
 */
package uk.ac.reload.editor.ctt.gui;

import java.awt.Container;

import javax.swing.JComponent;

import com.brunchboy.util.swing.relativelayout.AttributeConstraint;
import com.brunchboy.util.swing.relativelayout.AttributeType;

import uk.ac.reload.dweezil.gui.layout.RelativeLayoutManager;

/**
 * @author Roy P Cherian
 *
 * TODO
 */
public class ModRelLayoutManager extends RelativeLayoutManager {

    /**
     * @param container
     */
    public ModRelLayoutManager(Container container) {
        super(container);
        // TODO Auto-generated constructor stub
    }
    
    /**
	 * Add a component relative to another component's right edge.
	 * The size of the component will depend on its preferredSize.
	 * @param component the component to add
	 * @param componentName the unique name of the component
	 * @param anchorName the name of the component to anchor to relatively.
	 * @param verticalConstraint can be either RelativeLayoutManager.TOP or RelativeLayoutManager.BOTTOM
	 * for relative positioning from the anchorName component
	 * @param topOffset the offset in pixels from the top relative to topAnchor component
	 * @param leftOffset the offset in pixels from the left edge of the parent Container
	 */
	public void addFromLeftEdgeComponent(JComponent component, String componentName, String anchorName, String nextComp,
			int verticalConstraint, int topOffset, int leftOffset) {
		
		get_container().add(component, componentName);
		
		AttributeType attType = getAttributeType(verticalConstraint);
		
		getLayout().addConstraint(componentName, AttributeType.TOP,
				new AttributeConstraint(anchorName, attType, topOffset));
		
		getLayout().addConstraint(componentName, AttributeType.RIGHT,
				new AttributeConstraint(nextComp, AttributeType.LEFT, leftOffset));
	}

	public void addFromLeftEdgeComponentToRightofContainer(JComponent component, String componentName, String anchorName, 
			int verticalConstraint, int topOffset, int leftOffset, String rightLimitingContainer) {
		
		get_container().add(component, componentName);
		
		AttributeType attType = getAttributeType(verticalConstraint);
		
		getLayout().addConstraint(componentName, AttributeType.TOP,
				new AttributeConstraint(anchorName, attType, topOffset));
		
		getLayout().addConstraint(componentName, AttributeType.LEFT,
				new AttributeConstraint(anchorName, AttributeType.RIGHT, leftOffset));
		
		getLayout().addConstraint(componentName, AttributeType.RIGHT,
				new AttributeConstraint(rightLimitingContainer, AttributeType.RIGHT, 0));
	}
}
