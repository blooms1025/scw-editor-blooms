/**
 *  RELOAD TOOLS
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Phillip Beauvoir
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Phillip Beauvoir
 *  e-mail:   p.beauvoir@bolton.ac.uk
 *
 *  Web:      http://www.reload.ac.uk
 *
 */
package uk.ac.reload.editor.ctt.helper;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import uk.ac.reload.editor.Messages;
/**
 * Class for loading xml files recursively from a root directory -
 * used in loading iotransform.xml files from transform directory  
 */
public class ListFiles {
    
    private String suff = ".xml"; //$NON-NLS-1$
    /**
     * 
     */
    public ListFiles(String prefix) {
        
        suff = prefix + suff;       
    }
    
    /**
     * creates a list of files by recursing into subdirectories
     * @param startingDir
     * @return list of files 
     * @throws FileNotFoundException
     */
    
    public List getFileListing(String startingDir)
    throws FileNotFoundException {
        return getFileListing(new File(startingDir));
        
    }
    /**
     * Recursively walk a directory tree and return a List of all
     * Files found; the List is sorted using File.compareTo.
     *
     * @param aStartingDir is a valid directory, which can be read.
     */
    public List getFileListing(File aStartingDir)
    throws FileNotFoundException {
        validateDirectory(aStartingDir);
        List result = new ArrayList();
        
        File[] filesAndDirs = aStartingDir.listFiles();
        // no we need to filter for xslt - roy
        //File[] filesAndDirs = aStartingDir.listFiles(filter);
        List filesDirs = Arrays.asList(filesAndDirs);
        Iterator filesIter = filesDirs.iterator();
        File file = null;
        while (filesIter.hasNext()) {
            file = (File) filesIter.next();
            //if (file.isFile() && file.getName().endsWith(suff))
            if (file.isFile() && file.getName().equalsIgnoreCase(suff)){
                result.add(file); //always add                
            }
            else if (!file.isFile()) {
                //must be a directory
                //recursive call!
                List deeperList = getFileListing(file);
                result.addAll(deeperList);
            }
            
        }
        Collections.sort(result);
        return result;
    }
    
    /**
     * Directory is valid if it exists, does not represent a file, and can be read.
     * @param aDirectory
     * @throws FileNotFoundException
     */
    static private void validateDirectory(File aDirectory)
    throws FileNotFoundException {
        if (aDirectory == null) {
            throw new IllegalArgumentException(Messages.getString("ListFiles.1")); //$NON-NLS-1$
        }
        if (!aDirectory.exists()) {
            throw new FileNotFoundException(
                    Messages.getString("ListFiles.2") + aDirectory); //$NON-NLS-1$
        }
        if (!aDirectory.isDirectory()) {
            throw new IllegalArgumentException(
                    Messages.getString("ListFiles.3") + aDirectory); //$NON-NLS-1$
        }
        if (!aDirectory.canRead()) {
            throw new IllegalArgumentException(
                    Messages.getString("ListFiles.4") + aDirectory); //$NON-NLS-1$
        }
    }
    
} // end class 
