/**
 *  RELOAD TOOLS
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Phillip Beauvoir
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Phillip Beauvoir
 *  e-mail:   p.beauvoir@bolton.ac.uk
 *
 *  Web:      http://www.reload.ac.uk
 *
 */

package uk.ac.reload.editor.ctt.xformer;
import java.util.List;
import java.util.Iterator;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.File;
import org.jdom.Document;
import org.jdom.JDOMException;
import org.jdom.Element;

import uk.ac.reload.dweezil.gui.ErrorDialogBox;
import uk.ac.reload.editor.Messages;
import uk.ac.reload.editor.ctt.helper.ListFiles;
import uk.ac.reload.jdom.XMLUtils;

/**
 * This class loads the iotransform.xml file and collate
 * contained information onto a jdom document
 */
public class ScriptLoader {
    
    private List ioList;
    private static Document ctXRef = null;
    
    /**
     * c'str
     * @param rootDir
     * @throws FileNotFoundException
     * @throws JDOMException
     * @throws IOException
     */
    public ScriptLoader(String rootDir) throws FileNotFoundException, JDOMException, IOException {
        if(ctXRef == null){
            ListFiles ls = new ListFiles("xml"); //$NON-NLS-1$
            setIoList(ls.getFileListing(rootDir));
            setCtXRef();
        }
    }
    
    /**
     * c'str
     * @param rootDir
     * @throws FileNotFoundException
     * @throws JDOMException
     * @throws IOException
     */
    public ScriptLoader(File rootDir) throws FileNotFoundException, JDOMException, IOException {
        if(ctXRef == null){
            ListFiles ls = new ListFiles("iotransform"); //$NON-NLS-1$
            setIoList(ls.getFileListing(rootDir));
            setCtXRef();
        }
    }
    /**
     * @return the list of configuration files in the transform directorys
     */
    public List getIoList() {
        return ioList;
    }
    
    /**
     * @param list
     */
    public void setIoList(List list) {
        ioList = list;
    }
    
    /**
     * 
     * @return jdom document containing schema version and xslt file table 
     */
    public Document getCtXRef() {
        return ctXRef;
    }
    
    /**
     * create a jdom document containing cross reference of source/target schema
     * and the associated xslt file location 
     * @throws JDOMException
     * @throws IOException
     */
    //public void setCtXRef() throws JDOMException, IOException {
    public void setCtXRef() {
        Element rootSSchema;
        Element root = new Element("iotransforms"); //$NON-NLS-1$
        root.setText("Available xsl transforms"); //$NON-NLS-1$
        Iterator iter = ioList.iterator();
        while (iter.hasNext()) {
            File file = (File)iter.next();
            Document ioDoc = null;
            try {
                ioDoc = XMLUtils.readXMLFile(file);
            } catch (IOException e) {
                // TODO Auto-generated catch block
                //e.printStackTrace();
                ErrorDialogBox.showWarning(Messages.getString("ScriptLoader.4"), Messages.getString("ScriptLoader.5") ,e); //$NON-NLS-1$ //$NON-NLS-2$
                
            } catch (JDOMException e) {
                // TODO Auto-generated catch block
                //e.printStackTrace();
                ErrorDialogBox.showWarning(Messages.getString("ScriptLoader.6"), Messages.getString("ScriptLoader.7") ,e); //$NON-NLS-1$ //$NON-NLS-2$
            }
            if ((ioDoc != null) && (validateIODoc(ioDoc))) {
                Element sSchema = (Element) ioDoc.getRootElement().getChild(
                        "sourceSchema").clone(); //$NON-NLS-1$
                rootSSchema = findElementwithContent(root, sSchema);
                Element sLabel = (Element) ioDoc.getRootElement().getChild(
                        "sourceSchemaLabel").clone(); //$NON-NLS-1$
                Element tSchema = (Element) ioDoc.getRootElement().getChild(
                        "targetSchema").clone(); //$NON-NLS-1$
                Element tLabel = (Element) ioDoc.getRootElement().getChild(
                        "targetSchemaLabel").clone(); //$NON-NLS-1$
                Element xslLocn = (Element) ioDoc.getRootElement().getChild(
                        "XSLTfileLocation").clone(); //$NON-NLS-1$
                tSchema.addContent(tLabel);
                tSchema.addContent(xslLocn);
                
                
                // this is for storing the folder containing schema etc if they are specified 
                // in this xml file
                Element folderToCopy = (Element) ioDoc.getRootElement().getChild("folderToCopy"); //$NON-NLS-1$
                if(folderToCopy != null){
                    tSchema.addContent((Element)folderToCopy.clone());
                }
                //
                
                if (rootSSchema != null) {
                    rootSSchema.addContent(tSchema);
                } else {
                    sSchema.addContent(sLabel);
                    sSchema.addContent(tSchema);
                    root.addContent(sSchema);
                }

            }
        }
        ctXRef = new Document(root);
    }
    
   /**
    * find a child element in a jdom tree with matching content as the input element 
    * @param root
    * @param sSchema
    * @return element
    */
    
    private Element findElementwithContent(Element root, Element sSchema){
        Iterator childIter = root.getChildren("sourceSchema").iterator(); //$NON-NLS-1$
        while(childIter.hasNext()){
            Element child = (Element)childIter.next();
            if(child.getTextTrim().equalsIgnoreCase(sSchema.getTextTrim())){
                return child;
            }
        }
        
        return null;
    }
    /**
     * Return the xslt file location for doing xslt from given
     * source to target
     * @param sourceSchema
     * @param targetSchema
     * @return xslt file location
     */
    
    public String getXSLT(String sourceSchema, String targetSchema){
        Iterator childIter = ctXRef.getRootElement().getChildren("sourceSchema").iterator(); //$NON-NLS-1$
        while(childIter.hasNext()){
            Element child = (Element)childIter.next();
            String schemaLbl = child.getChild("sourceSchemaLabel").getText().trim(); //$NON-NLS-1$
            if(schemaLbl.equalsIgnoreCase(sourceSchema.trim())){
                Iterator tIter =  child.getChildren("targetSchema").iterator(); //$NON-NLS-1$
                while (tIter.hasNext()) {
                    Element tSchema = (Element)tIter.next();
                    String tschemaLbl = tSchema.getChild("targetSchemaLabel").getText().trim(); //$NON-NLS-1$
                    
                    if(tschemaLbl.equalsIgnoreCase(targetSchema.trim())){
                        return tSchema.getChild("XSLTfileLocation").getText(); //$NON-NLS-1$
                    }
                }
            }
        }		
        return ""; //$NON-NLS-1$
    }
    
    /**
     * Return the folder location containing files to be copied if specified
     * @param sourceSchema
     * @param targetSchema
     * @return xslt file location
     */
    
    public String getFolderToCopy(String sourceSchema, String targetSchema){
        if (ctXRef.getRootElement().getChildren("sourceSchema") != null) { //$NON-NLS-1$
            Iterator childIter = ctXRef.getRootElement().getChildren(
                    "sourceSchema").iterator(); //$NON-NLS-1$
            while (childIter.hasNext()) {
                Element child = (Element) childIter.next();
                String schemaLbl = child.getChild("sourceSchemaLabel") //$NON-NLS-1$
                        .getText().trim();
                if (schemaLbl.equalsIgnoreCase(sourceSchema.trim())) {
                    Iterator tIter = child.getChildren("targetSchema") //$NON-NLS-1$
                            .iterator();
                    while (tIter.hasNext()) {
                        Element tSchema = (Element) tIter.next();
                        String tschemaLbl = tSchema.getChild(
                                "targetSchemaLabel").getText().trim(); //$NON-NLS-1$

                        if (tschemaLbl.equalsIgnoreCase(targetSchema.trim())) {
                            Element folderLocn = tSchema
                                    .getChild("folderToCopy"); //$NON-NLS-1$
                            if (folderLocn != null) {
                                return folderLocn.getText();
                            }
                        }
                    }
                }
            }
        }
        return ""; //$NON-NLS-1$
    }
    
    /**
     * Check whether the iotransform.xml file is in order
     * format : <iotransform>
	  <sourceSchema>ims_cp_rootv1p2</sourceSchema>
	  <sourceSchemaLabel>IMS Content Packaging 1.1.3</sourceSchemaLabel>
	  <targetSchema>ims_cp_rootv1p2</targetSchema>
	  <targetSchemaLabel>IMS Content Packaging 1.1.3</targetSchemaLabel> 
	  <XSLTfileLocation>xform1\xsl113to113.xslt</XSLTfileLocation>
	  <folderToCopy>xyz</folderToCopy> <!-- optional -->
	</iotransform>

     * @param ioDoc xml document with details of xslt files
     * @return true or false
     */
    
    public boolean validateIODoc(Document ioDoc){
        boolean result = true;
        if((ioDoc.getRootElement().getChild("sourceSchema") == null)|| //$NON-NLS-1$
                (ioDoc.getRootElement().getChild("sourceSchema").getTextTrim() == null) || //$NON-NLS-1$
                (ioDoc.getRootElement().getChild("sourceSchema").getTextTrim().equals(""))) //$NON-NLS-1$ //$NON-NLS-2$
            return false;
        if((ioDoc.getRootElement().getChild("sourceSchemaLabel") == null)|| //$NON-NLS-1$
                (ioDoc.getRootElement().getChild("sourceSchemaLabel").getTextTrim() == null)|| //$NON-NLS-1$
                (ioDoc.getRootElement().getChild("sourceSchemaLabel").getTextTrim().equals(""))) //$NON-NLS-1$ //$NON-NLS-2$
            return false;
        if((ioDoc.getRootElement().getChild("targetSchema") == null)|| //$NON-NLS-1$
                (ioDoc.getRootElement().getChild("targetSchema").getTextTrim() == null)|| //$NON-NLS-1$
                (ioDoc.getRootElement().getChild("targetSchema").getTextTrim().equals(""))) //$NON-NLS-1$ //$NON-NLS-2$
            return false;
        if((ioDoc.getRootElement().getChild("targetSchemaLabel") == null)|| //$NON-NLS-1$
                (ioDoc.getRootElement().getChild("targetSchemaLabel").getTextTrim() == null) || //$NON-NLS-1$
                (ioDoc.getRootElement().getChild("targetSchemaLabel").getTextTrim().equals(""))) //$NON-NLS-1$ //$NON-NLS-2$
            return false;
        if((ioDoc.getRootElement().getChild("XSLTfileLocation") == null)|| //$NON-NLS-1$
                (ioDoc.getRootElement().getChild("XSLTfileLocation").getTextTrim() == null)||  //$NON-NLS-1$
                (ioDoc.getRootElement().getChild("XSLTfileLocation").getTextTrim().equals(""))) //$NON-NLS-1$ //$NON-NLS-2$
            return false;
        return result;
    }
}
