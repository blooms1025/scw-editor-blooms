/**
 *  Content Re-Engineerng Tool
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Roy P Cherian
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Roy P Cherian
 *  e-mail:   rc3@bolton.ac.uk
 *
 *
 */
package uk.ac.reload.editor.ctt.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;

import javax.swing.DefaultListSelectionModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.EtchedBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import uk.ac.reload.dweezil.gui.layout.RelativeLayoutManager;
import uk.ac.reload.editor.EditorFrame;
import uk.ac.reload.editor.Messages;
import uk.ac.reload.editor.ctt.helper.ListFilePatterns;

/**
 * @author Roy P Cherian
 * 
 * TODO
 */
public class FileFilterDialog extends JDialog {

    int width = 430;

    int heightMin = 100;

    int heightMax = 280;

    private JPanel bottomOKPanel;

    private JButton cancelButton;

    private JPanel centPanel;

    private JPanel fileLstPanel;

    private JList filesList;

    private JScrollPane filesScrollPane;

    private JTextField filterTextField;

    private JLabel foundLabel;

    private JPanel mainPanel;

    private JButton okButton;

    private JLabel selectLabel;

    private JPanel topPanel;

    private JButton xformButton;

    private JButton xformCancelButton;

    private File sourceDir = null;
    
    private ArrayList fileLst;

    public FileFilterDialog() {
        initComponents();
        centPanel.setVisible(false);
        this.setSize(new Dimension(width, heightMin));
        this.repaint();
        this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

    }

    public FileFilterDialog(File sourceDir) {
        super(EditorFrame.getInstance(), "Select Files for transformation", true); //$NON-NLS-1$
        initComponents();
        this.sourceDir = sourceDir;
        centPanel.setVisible(false);
        this.setSize(new Dimension(width, heightMin));
        this.repaint();
        this.setLocationRelativeTo(EditorFrame.getInstance());
        this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

    }

    private void initComponents() {
        mainPanel = new JPanel();
        topPanel = new JPanel();
        okButton = new JButton();
        cancelButton = new JButton();
        filterTextField = new JTextField();
        selectLabel = new JLabel();
        centPanel = new JPanel();
        bottomOKPanel = new JPanel();
        xformButton = new JButton();
        xformCancelButton = new JButton();
        fileLstPanel = new JPanel();
        fileLstPanel.setBorder(new EtchedBorder());
        foundLabel = new JLabel();
        filesScrollPane = new JScrollPane();
        filesList = new JList();
        //filesList.setBackground(Color.LIGHT_GRAY);
        filesList.setSelectionMode(DefaultListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        filesList.getSelectionModel().addListSelectionListener(new FileListSelectionHandler());
        
        
        
        mainPanel.setLayout(new BorderLayout());

        ModRelLayoutManager topPnlLayoutMngr = new ModRelLayoutManager(topPanel);

        okButton.setText(Messages.getString("FileFilterDialog.0")); //$NON-NLS-1$
        okButton.setName("OKBtn"); //$NON-NLS-1$
        okButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                okButtonActionPerformed(evt);
            }
        });

        cancelButton.setText(Messages.getString("FileFilterDialog.2")); //$NON-NLS-1$
        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                cancelButtonActionPerformed(evt);
            }
        });

        topPnlLayoutMngr.addFromRightEdge(cancelButton, "cancelButton", //$NON-NLS-1$
                "filterTextField", RelativeLayoutManager.BOTTOM, 2, -2); //$NON-NLS-1$

        topPnlLayoutMngr.addFromLeftEdgeComponent(okButton, "okButton", //$NON-NLS-1$
                "filterTextField", "cancelButton", //$NON-NLS-1$ //$NON-NLS-2$
                RelativeLayoutManager.BOTTOM, 2, -1);

        filterTextField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                ;//filterTextFieldActionPerformed(evt);
            }
        });

        filterTextField.setPreferredSize(new Dimension(300, 20));
        topPnlLayoutMngr.addFromRightEdgeComponent(filterTextField,
                "filterTextField", "selectLabel", RelativeLayoutManager.TOP, 2, //$NON-NLS-1$ //$NON-NLS-2$
                2);

        selectLabel.setText(Messages.getString("FileFilterDialog.1")); //$NON-NLS-1$
        topPnlLayoutMngr.addFromLeftEdge(selectLabel, "selectLabel", //$NON-NLS-1$
                RelativeLayoutManager.ROOT_NAME, RelativeLayoutManager.TOP, 5,
                5);

        RelativeLayoutManager cenLayoutManager = new RelativeLayoutManager(
                centPanel);

        ModRelLayoutManager fileLstPanelLayoutMngr = new ModRelLayoutManager(
                fileLstPanel);

        foundLabel.setText(Messages.getString("FileFilterDialog.12")); //$NON-NLS-1$
        fileLstPanelLayoutMngr.addFromLeftToRightEdges(foundLabel,
                "foundLabel", RelativeLayoutManager.ROOT_NAME, //$NON-NLS-1$
                RelativeLayoutManager.TOP, 1, 1);

        filesScrollPane.setViewportView(filesList);
        fileLstPanelLayoutMngr.addFromLeftToRightEdges(filesScrollPane,
                "filesScrollPane", "foundLabel", RelativeLayoutManager.BOTTOM, //$NON-NLS-1$ //$NON-NLS-2$
                0, 0);

        ModRelLayoutManager bottomPnlLayoutMngr = new ModRelLayoutManager(
                bottomOKPanel);
        xformButton.setText(Messages.getString("FileFilterDialog.16")); //$NON-NLS-1$
        xformButton.setPreferredSize(new Dimension(150, 25));
        xformButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                xformButtonActionPerformed(evt);
            }
        });
        bottomPnlLayoutMngr.addFromLeftEdgeComponent(xformButton,
                "xformButton", RelativeLayoutManager.ROOT_NAME, //$NON-NLS-1$
                "xformCancelButton", RelativeLayoutManager.TOP, 0, 0); //$NON-NLS-1$

        xformCancelButton.setText(Messages.getString("FileFilterDialog.19")); //$NON-NLS-1$
        xformCancelButton.setPreferredSize(new Dimension(80, 25));
        xformCancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                xformCancelButtonActionPerformed(evt);
            }
        });

        bottomPnlLayoutMngr.addFromRightEdge(xformCancelButton,
                "xformCancelButton", RelativeLayoutManager.ROOT_NAME, //$NON-NLS-1$
                RelativeLayoutManager.TOP, 0, 0);

        cenLayoutManager.addFromLeftToRightEdges(fileLstPanel, "fileLstPanel", //$NON-NLS-1$
                RelativeLayoutManager.ROOT_NAME, RelativeLayoutManager.TOP, 0,
                0);

        cenLayoutManager.addFromLeftToRightEdges(bottomOKPanel,
                "bottomOKPanel", "fileLstPanel", RelativeLayoutManager.BOTTOM, //$NON-NLS-1$ //$NON-NLS-2$
                0, 0);

        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(centPanel, BorderLayout.CENTER);

        getContentPane().add(mainPanel, BorderLayout.CENTER);
        
        pack();
    }

    private void xformCancelButtonActionPerformed(ActionEvent evt) {
        // TODO
        fileLst = null;
        this.dispose();
    }

    private void cancelButtonActionPerformed(ActionEvent evt) {
        // TODO
        fileLst = null;
        this.dispose();
    }

    private void okButtonActionPerformed(ActionEvent evt) {
        // TODO
        updateFileList();
        centPanel.setVisible(true);
        this.setSize(width, heightMax);
        this.validate();

    }

    private void xformButtonActionPerformed(ActionEvent evt) {
        // TODO
        if(fileLst == null)
            return;
        filesList.setListData(fileLst.toArray());
        filesList.clearSelection();
        this.dispose();
    }

 /*   private void filterTextFieldActionPerformed(ActionEvent evt) {
        // TODO
    }*/

    private void updateFileList() {
        String filePattern = filterTextField.getText();
        if ((filePattern != null) && !("".equals(filePattern))) { //$NON-NLS-1$
            if (sourceDir != null) {
             fileLst = ListFilePatterns.listFiles(sourceDir, filePattern, filesList);
             filesList.repaint();
            }
        }

    }

    /**
     * @param args
     *            the command line arguments
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FileFilterDialog().setVisible(true);
            }
        });
    }
    public ArrayList getFileLst() {
        return fileLst;
    }

  
    /**
     * 
     */
    public ArrayList showDialog() {
        // TODO Auto-generated method stub
        show();
        //System.out.println(" returning file list " + fileLst.size());
        return fileLst;
        
    }
    
    
    /**
     * This is for file list selection
     * @author Roy P Cherian
     *
     * TODO
     */
    class FileListSelectionHandler implements ListSelectionListener {
        public void valueChanged(ListSelectionEvent e) { 
            ListSelectionModel lsm = (ListSelectionModel)e.getSource();
        
            if (lsm.isSelectionEmpty()) {
                //fileLst.clear();
            } else {
                fileLst.clear();
                fileLst = new ArrayList();
                // Find out which indexes are selected.
                int minIndex = lsm.getMinSelectionIndex();
                int maxIndex = lsm.getMaxSelectionIndex();
                
                for (int i = minIndex; i <= maxIndex; i++) {
                    if (lsm.isSelectedIndex(i)) {
                        //output.append(" " + i);
                        System.out.println(" from list selection listner adding item at " + i); //$NON-NLS-1$
                        fileLst.add(filesList.getModel().getElementAt(i));
                    }
                }
                System.out.println(" \t\t selection size is " + fileLst.size()); //$NON-NLS-1$
            }
        }
    }
}