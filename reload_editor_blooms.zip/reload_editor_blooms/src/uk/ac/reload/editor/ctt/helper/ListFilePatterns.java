/**
 *  Content Re-Engineerng Tool
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Roy P Cherian
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Roy P Cherian
 *  e-mail:   rc3@bolton.ac.uk
 *
 *
 */
package uk.ac.reload.editor.ctt.helper;
import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

import javax.swing.JList;
/**
 * @author Roy P Cherian
 *Based on a posting from Java technology forum
 * TODO
 */
public class ListFilePatterns {
    
    static void listPath(File path, FileFilter filter, List lst) {
      File files[];  // list of files in a directory
      
      // create list of files in this dir
      files = path.listFiles(filter);
      // Sort with help of Collections API
      Arrays.sort(files);
      for (int i=0, n=files.length; i < n; i++) {
        
        if (files[i].isDirectory()) {
          // recursively descend dir tree
          listPath(files[i], filter, lst);
        }else{
            //System.out.println(files[i].toString());
            //lst.add(files[i].getName());
            lst.add(files[i]);
            
        }
      }
      
    }
    
    /**
     * Provies a FileFilter that uses Regular Expression pattern
     * matching to restrict the set of files in the output
     * Auto-converts wildcard "*" to ".*" to match via patterns.
     */
    static class PatternFileFilter implements FileFilter {
      Pattern pattern;
      public PatternFileFilter(String pattern) {
        //
        pattern = pattern.replaceAll("\\*", ".*"); //$NON-NLS-1$ //$NON-NLS-2$
        this.pattern = Pattern.compile(pattern);
      }
      public boolean accept(File pathname) {
        if (pathname.isDirectory()) {
          return true;
        }
        return pattern.matcher(pathname.getName()).matches();
        
      }
    }
    
    static public ArrayList listFiles(File dir, String filePattern, JList lst){
        FileFilter filter = new PatternFileFilter(filePattern);
        ArrayList list = new ArrayList();
        listPath(dir, filter, list);
        lst.setListData(list.toArray());
        return list;
    }
}
