/**
 *  RELOAD TOOLS
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Phillip Beauvoir
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Phillip Beauvoir
 *  e-mail:   p.beauvoir@bolton.ac.uk
 *
 *  Web:      http://www.reload.ac.uk
 *
 */
package uk.ac.reload.editor.ctt.xformer;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.jdom.JDOMException;

/**
 * Performs xslt on jdom document - xalan is used for xslt 
 */
public class CTransfromer {

    private TransformerFactory tFactory;

    private static CTransfromer xformer;
   
    static public CTransfromer getInstance() {
        if (xformer == null) {
            xformer = new CTransfromer(); // only callable from within
        }
        return xformer;

    }

    

    /**
     *
     */
    public CTransfromer() {
        //TODO caching stylesheets
        tFactory = TransformerFactory.newInstance();

    }

    /**
     * sets the xsl transformer factory
     * @param factory
     */
    public void setTFactory(String factory) {
        System.setProperty("javax.xml.transform.TransformerFactoryImpl", //$NON-NLS-1$
                factory);
        tFactory = TransformerFactory.newInstance();
    }

 
    
    /**
     * XSL transform an xml document  
     * @param inputFile  xml document to be transformed
     * @param xslFile xsl file to be used 
    * @return outFile resultant output file
     * @throws JDOMException
     * @throws IOException
     */

    public File transform(File inputFile, File xslFile, File outFile)
            throws JDOMException, IOException {
       
        try {
            //TransformerFactory tFactory = TransformerFactory.newInstance();

            // Use the TransformerFactory to instantiate a Transformer that will
            // work with
            // the stylesheet you specify. This method call also processes the
            // stylesheet into a compiled Templates object.
            Transformer transformer = tFactory.newTransformer(new StreamSource(
                    xslFile));

            // Use the Transformer to apply the associated Templates object to
            // an XML document
            // inputFile and write the output to a file (outFile).
            transformer.transform(new StreamSource(inputFile),
                    new StreamResult(new FileOutputStream(outFile)));

        } catch (TransformerConfigurationException te) {
            System.err.println("transformer error " + te.toString()); //$NON-NLS-1$
            return null;
        } catch (TransformerException te) {
            System.err.println("transformer exception " + te.toString()); //$NON-NLS-1$
            return null;
        } catch (IOException ioe) {
            System.err.println("IO error " + ioe.toString()); //$NON-NLS-1$
            return null;
        }

        return outFile;
    }
    
}

