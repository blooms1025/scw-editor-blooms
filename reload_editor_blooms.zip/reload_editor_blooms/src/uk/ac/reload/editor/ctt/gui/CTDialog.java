/**
 *  RELOAD TOOLS
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Phillip Beauvoir
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Phillip Beauvoir
 *  e-mail:   p.beauvoir@bolton.ac.uk
 *
 *  Web:      http://www.reload.ac.uk
 *
 */
package uk.ac.reload.editor.ctt.gui;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.JOptionPane;

import org.jdom.Document;
import org.jdom.JDOMException;
import org.jdom.Namespace;

import uk.ac.reload.diva.util.FileUtils;
import uk.ac.reload.dweezil.gui.DweezilProgressMonitor;
import uk.ac.reload.dweezil.gui.ErrorDialogBox;
import uk.ac.reload.dweezil.util.DweezilUIManager;
import uk.ac.reload.editor.EditorFrame;
import uk.ac.reload.editor.EditorHandler;
import uk.ac.reload.editor.IIcons;
import uk.ac.reload.editor.Messages;
import uk.ac.reload.editor.contentpackaging.CP_EditorHandler;
import uk.ac.reload.editor.contentpackaging.editor.CP_Editor;
import uk.ac.reload.editor.contentpackaging.xml.ContentPackage;
import uk.ac.reload.editor.ctt.helper.RelativePath;
import uk.ac.reload.editor.ctt.xformer.CTransfromer;
import uk.ac.reload.editor.ctt.xformer.ScriptLoader;
import uk.ac.reload.jdom.XMLUtils;
import uk.ac.reload.moonunit.contentpackaging.CP_Core;
import uk.ac.reload.moonunit.schema.SchemaException;

/**
 * This is for presenting the dialog screens for import As and export As content
 * packages from one version to version another using XSLT
 */
public class CTDialog {

    /**
     * XSLT root Folder
     */
   /* public static File SCHEMAROOTFOLDER = EditorProperties
            .getFileProperty("schema.dir"); //$NON-NLS-1$

    public static final File XFORM_FOLDER = new File(SCHEMAROOTFOLDER
            .getParentFile(), "transform"); //$NON-NLS-1$
   */
    public static final File XFORM_FOLDER = new File("transform");
    private static SourceTargetDialog stDialog;

    /* *//**
     *  
     */
   
    /*
     * Imports a content package and perform xslt on the manifest and open the
     * transformed content in editor
     */
    public static void ctImport() throws JDOMException, SchemaException,
            IOException {
        String srcVersion = ""; //$NON-NLS-1$
        String targVersion = ""; //$NON-NLS-1$
        String xsltLocn = ""; //$NON-NLS-1$
        File sFile = null;
        File tFile = null;
        ScriptLoader sl;
        // this is the XSLTd document i.e manifest
        //Document xdoc = null;
        CTransfromer ct = new CTransfromer();
        DweezilProgressMonitor progressMonitor = null;

        stDialog = new SourceTargetDialog(XFORM_FOLDER, EditorFrame
                .getInstance(), null);
        //present source target schema dialog
        srcVersion = stDialog.showDialog();
        if (srcVersion == null) {
            return;
        } 
        
        targVersion = stDialog.getSchemaTName();

        // load all the xslts
        sl = stDialog.getSl();
        // get xslt file name
        xsltLocn = sl.getXSLT(srcVersion, targVersion);

        // find location of input file and target folder
        CTFileOpenDialog ctDialog = new CTFileOpenDialog(srcVersion,
                targVersion, EditorFrame.getInstance());
        ctDialog.showDialog();
        sFile = ctDialog.getSourceFile();
        tFile = ctDialog.getTargetFile();
        if (xsltLocn.equalsIgnoreCase("") || (sFile == null) || (tFile == null)) { //$NON-NLS-1$
            return;
        }

        // unzip if its a zip file
        if (sFile.getName().toLowerCase().endsWith(".zip")) { //$NON-NLS-1$

            // First check that archive contains a manifest file
            if (!CP_EditorHandler.containsManifest(sFile)) {
                throw new IOException(
                        Messages
                                .getString("uk.ac.reload.editor.contentpackaging.CP_EditorHandler.8")); //$NON-NLS-1$
            }

            progressMonitor = new DweezilProgressMonitor(
                    EditorFrame.getInstance(),
                    Messages
                            .getString("uk.ac.reload.editor.contentpackaging.CP_EditorHandler.10"), //$NON-NLS-1$
                    Messages
                            .getString("uk.ac.reload.editor.contentpackaging.CP_EditorHandler.11"), //$NON-NLS-1$
                    Messages
                            .getString("uk.ac.reload.editor.contentpackaging.CP_EditorHandler.12"), //$NON-NLS-1$
                    true, DweezilUIManager.getIcon(IIcons.ICON_APP16));

            try {
                // Unzip and get imsmanifest
                sFile = CP_EditorHandler.unzipContentPackage(sFile, tFile,
                        progressMonitor);
            } finally {
                progressMonitor.close();
            }
        } else {
            try {
                // Progress Monitor
                progressMonitor = new DweezilProgressMonitor(
                        EditorFrame.getInstance(),
                        Messages
                                .getString("uk.ac.reload.editor.contentpackaging.CP_Editor.38"), //$NON-NLS-1$
                        Messages
                                .getString("uk.ac.reload.editor.contentpackaging.CP_Editor.16"), //$NON-NLS-1$
                        Messages
                                .getString("uk.ac.reload.editor.contentpackaging.CP_Editor.16"), //$NON-NLS-1$
                        true, DweezilUIManager.getIcon(IIcons.ICON_APP16));

                // Copy source folder to new location
                FileUtils.copyFolder(sFile.getParentFile(), tFile,
                        progressMonitor);

                progressMonitor.close();

                /**
                 * This is for copying files specified by the user to the target
                 * folder this could be schema files and other support files
                 * (API wrappers etc) and is not mandatory
                 */
                String folderLocn = sl.getFolderToCopy(srcVersion, targVersion);
                if (!("".equals(folderLocn))) { //$NON-NLS-1$
                    String folder = XFORM_FOLDER.getAbsolutePath()
                            + File.separatorChar + File.separatorChar
                            + folderLocn.trim();
                    // Copy support file folder to new location
                    File supportFolder = new File(folder);
                    if (supportFolder.exists() && (supportFolder.isDirectory())) {
                        FileUtils.copyFolder(supportFolder, tFile);
                    }
                }

                /*
                 * // User cancelled if(!result) { return null; }
                 */
            } catch (Exception ex) {
                if (progressMonitor != null) {
                    progressMonitor.close();
                }
                ErrorDialogBox
                        .showWarning(
                                Messages
                                        .getString("uk.ac.reload.editor.contentpackaging.CP_Editor.32"), //$NON-NLS-1$
                                Messages
                                        .getString("uk.ac.reload.editor.contentpackaging.CP_Editor.33"), //$NON-NLS-1$
                                ex);
                return;
            }
        }
        // how to check the document to see whether they are what they seem
        // The following assume that version names are put in a standard way ?
        File manifestLocn = new File(tFile, CP_Core.MANIFEST_NAME);

        // Load the Document
        Document manifestDoc = XMLUtils.readXMLFile(manifestLocn);

        // Get version from Namespace
        Namespace nameSpace = XMLUtils.getDocumentNamespace(manifestDoc);

        String versionCP = ""; //$NON-NLS-1$

        if (srcVersion.indexOf("SCORM") != -1) { //$NON-NLS-1$
            nameSpace = XMLUtils.getDocumentNamespace(manifestDoc, "adlcp"); //$NON-NLS-1$
            versionCP = EditorHandler.SCORM12_EDITORHANDLER
                    .getVersion(nameSpace);
            versionCP = versionCP.substring(0, versionCP.indexOf(",")).trim(); //$NON-NLS-1$
        } else {

            versionCP = EditorHandler.CP_EDITORHANDLER.getVersion(nameSpace);
        }

        if (!versionCP.equalsIgnoreCase(srcVersion)) {
            System.err.println(Messages.getString("CTDialog.0")); //$NON-NLS-1$
            return;
        }
        xsltLocn = XFORM_FOLDER.getAbsolutePath() + File.separatorChar
                + xsltLocn.trim();
        /*xdoc = ct.transform(sFile.getAbsolutePath(), xsltLocn);
         if (xdoc == null)
         return;*/
        // in the end save the XSLTd file to the target folder
        if (manifestLocn.exists()) {
            manifestLocn.delete();
        }
        manifestLocn = ct.transform(sFile, new File(xsltLocn), manifestLocn);
        if (manifestLocn == null)
            return;

        //XMLUtils.write2XMLFile(xdoc, manifestLocn);

        EditorHandler.getSharedInstance().openFile(manifestLocn);

    }

    /*
     * Export the content package being edited using xslt and open a new editor
     * window with the converted content package
     */
    public static void ctExport(CP_Editor cpEditor) throws JDOMException,
            SchemaException, IOException {

        String targVersion = ""; //$NON-NLS-1$
        String xsltLocn = ""; //$NON-NLS-1$
        File sFile = null;
        File tFile = null;
        
        String versionCP = ""; //$NON-NLS-1$
        ScriptLoader sl;

        CTransfromer ct = new CTransfromer();
        //DweezilProgressMonitor progressMonitor = null;
        ContentPackage cp = cpEditor.getContentPackage();

        // Load the Document
        Document manifestDoc = cp.getDocument();

        // Get version from Namespace
        Namespace nameSpace = XMLUtils.getDocumentNamespace(manifestDoc);

        // check whether this is ADLCP in which case check again with prefix
        Namespace nameSpace1 = XMLUtils.getDocumentNamespace(manifestDoc,
                "adlcp"); //$NON-NLS-1$
        //Get version from Namespace
        if (nameSpace1 != null) {
            versionCP = EditorHandler.SCORM12_EDITORHANDLER
                    .getVersion(nameSpace1);
            versionCP = versionCP.substring(0, versionCP.indexOf(",")).trim(); //$NON-NLS-1$
        } else {

            versionCP = EditorHandler.CP_EDITORHANDLER.getVersion(nameSpace);
        }

        stDialog = new SourceTargetDialog(XFORM_FOLDER, EditorFrame
                .getInstance(), versionCP);
        //present source target schema dialog
        stDialog.showDialog();
        targVersion = stDialog.getSchemaTName();
        if (targVersion == null) {
            return;
        }
        // load all the xslts
        sl = stDialog.getSl();
        // get xslt file name]
        xsltLocn = sl.getXSLT(versionCP, targVersion);
        String manifestPath = cp.getFile().getAbsolutePath();
        // find location of input file and target folder
        CTFileOpenDialog ctDialog = new CTFileOpenDialog(versionCP,
                targVersion, manifestPath, EditorFrame.getInstance());
        ctDialog.showDialog();
        sFile = new File(manifestPath);
        tFile = ctDialog.getTargetFile();
        if (xsltLocn.equalsIgnoreCase("") || (tFile == null)) { //$NON-NLS-1$
            return;
        }


        // first copy the CP 'as is' to the new folder
        copyCP(cp, tFile);

        // how to check the document to see whether they are what they seem

        xsltLocn = XFORM_FOLDER.getAbsolutePath() + File.separatorChar
                + xsltLocn.trim();

        //
        // in the end save the XSLTd file to the target folder
        File manifestLocn = new File(tFile, CP_Core.MANIFEST_NAME);
        if (manifestLocn.exists()) {
            manifestLocn.delete();
        }
        manifestLocn = ct.transform(sFile, new File(xsltLocn), manifestLocn);
        if (manifestLocn == null) {
            return;
        }
        //XMLUtils.write2XMLFile(xdoc, manifestLocn);

        /**
         * This is for copying files specified by the user to the target folder
         * this could be schema files and other support files (API wrappers etc)
         * and is not mandatory
         */
        String folderLocn = sl.getFolderToCopy(versionCP, targVersion);
        if (!("".equals(folderLocn))) { //$NON-NLS-1$
            String folder = XFORM_FOLDER.getAbsolutePath() + File.separatorChar
                    + File.separatorChar + folderLocn.trim();
            // Copy support file folder to new location
            File supportFolder = new File(folder);
            if (supportFolder.exists() && (supportFolder.isDirectory())) {
                FileUtils.copyFolder(supportFolder, tFile);
            }
        }

        EditorHandler.getSharedInstance().openFile(manifestLocn);
    }

    /**
     * 
     * Export all the content in a specified folder recursively to the target
     * folder
     * 
     * @throws JDOMException
     * @throws SchemaException
     * @throws IOException
     */

    public static void ctBatchExport() throws JDOMException, SchemaException,
            IOException {
        String srcVersion = ""; //$NON-NLS-1$
        String targVersion = ""; //$NON-NLS-1$
        String xsltLocn = ""; //$NON-NLS-1$
        File sFolder = null;
        File tFolder = null;
        
        ScriptLoader sl;

        CTransfromer ct = new CTransfromer();
        DweezilProgressMonitor progressMonitor = null;

        stDialog = new SourceTargetDialog(XFORM_FOLDER, EditorFrame
                .getInstance(), null);

        srcVersion = stDialog.showDialog();
        if (srcVersion == null) {
            return;
        }
        targVersion = stDialog.getSchemaTName();
        if (targVersion == null) {
            return;
        }
        

        // load all the xslts
        sl = stDialog.getSl();
        // get xslt file name
        xsltLocn = sl.getXSLT(srcVersion, targVersion);

        // find location of input folder and target folder
        CTFileOpenDialog ctDialog = new CTFileOpenDialog(srcVersion,
                targVersion, true, EditorFrame.getInstance());
        ctDialog.showDialog();
        sFolder = ctDialog.getSourceFile();
        tFolder = ctDialog.getTargetFile();
        if (xsltLocn.equalsIgnoreCase("") || (sFolder == null) || (tFolder == null)) { //$NON-NLS-1$
            return;
        }

        //TODO
        try {
            // Progress Monitor
            progressMonitor = new DweezilProgressMonitor(
                    EditorFrame.getInstance(),
                    Messages
                            .getString("uk.ac.reload.editor.contentpackaging.CP_Editor.38"), //$NON-NLS-1$
                    Messages
                            .getString("uk.ac.reload.editor.contentpackaging.CP_Editor.16"), //$NON-NLS-1$
                    Messages
                            .getString("uk.ac.reload.editor.contentpackaging.CP_Editor.16"), //$NON-NLS-1$
                    true, DweezilUIManager.getIcon(IIcons.ICON_APP16));

            // Copy source folder to new location
            FileUtils.copyFolder(sFolder, tFolder, progressMonitor);

            progressMonitor.close();

            /**
             * This is for copying files specified by the user to the target
             * folder this could be schema files and other support files (API
             * wrappers etc) and is not mandatory
             */

        } catch (Exception ex) {
            if (progressMonitor != null) {
                progressMonitor.close();
            }
            ErrorDialogBox
                    .showWarning(
                            Messages
                                    .getString("uk.ac.reload.editor.contentpackaging.CP_Editor.32"), //$NON-NLS-1$
                            Messages
                                    .getString("uk.ac.reload.editor.contentpackaging.CP_Editor.33"), //$NON-NLS-1$
                            ex);
            return;
        }

        FileFilterDialog filesDialog = new FileFilterDialog(sFolder);
        ArrayList fileLst = filesDialog.showDialog();
        xsltLocn = XFORM_FOLDER.getAbsolutePath() + File.separatorChar
                + xsltLocn.trim();

        if ((fileLst != null) && (fileLst.size() > 0)) {
            int docCount = 0;
            for (Iterator iter = fileLst.iterator(); iter.hasNext();) {
                File file = (File) iter.next();

                String relPath = RelativePath.getRelativePath(sFolder, file);

                File xmlLocn = new File(tFolder, relPath);

                if (file.exists() && file.isFile()) {

                    if (xmlLocn.exists()) {
                        xmlLocn.delete();
                    }
                    xmlLocn = ct.transform(file, new File(xsltLocn), xmlLocn);
                    if (xmlLocn == null) {
                        System.err.println(Messages.getString("CTDialog.11")); //$NON-NLS-1$
                        continue;
                    }
                    docCount++;
                    //in the end save the XSLTd file to the target folder
                    //XMLUtils.write2XMLFile(xdoc, xmlLocn);

                } else {
                    System.err
                            .println(Messages.getString("CTDialog.12")); //$NON-NLS-1$
                }
            }
            // provide some dialog message about status here ?
            String message = Messages.getString("CTDialog.13") + docCount + Messages.getString("CTDialog.14"); //$NON-NLS-1$ //$NON-NLS-2$
            JOptionPane.showMessageDialog(EditorFrame.getInstance(), message);
        }

    }

    /**
     * Copy a content package with associated resources to new folder
     * 
     * @param cp
     * @param tFolder
     */
    public static void copyCP(ContentPackage cp, File tFolder) {
        DweezilProgressMonitor progressMonitor = null;
        //      Progress Monitor
        progressMonitor = new DweezilProgressMonitor(
                EditorFrame.getInstance(),
                Messages
                        .getString("uk.ac.reload.editor.contentpackaging.CP_Editor.31"), //$NON-NLS-1$
                Messages
                        .getString("uk.ac.reload.editor.contentpackaging.CP_Editor.16"), //$NON-NLS-1$
                Messages
                        .getString("uk.ac.reload.editor.contentpackaging.CP_Editor.16"), //$NON-NLS-1$
                true, DweezilUIManager.getIcon(IIcons.ICON_APP16));
        //Do it

        try {
            cp.saveDocumentAs(tFolder, progressMonitor);
        } catch (Exception ex) {
            progressMonitor.close();

        }
        progressMonitor.close();
    }

    /**
     * This method converts plain XML documents using XSL sheets specified by the user
     * and then attempts to open the document in an available editor
     * @throws IOException
     * @throws JDOMException
     * @throws FileNotFoundException
     */
    public void convertXML() throws FileNotFoundException, JDOMException,
            IOException {
        // TODO Auto-generated method stub
        // what to do ??
        // first get the XSLt file from the stored ones and then
        // ask for the document to be transformed
        // then open Xformed document in the editor ?

        String srcVersion = ""; //$NON-NLS-1$
        String targVersion = ""; //$NON-NLS-1$
        String xsltLocn = ""; //$NON-NLS-1$
        File sFile = null;
        File tFile = null;
        ScriptLoader sl;

        CTransfromer ct = new CTransfromer();
        stDialog = new SourceTargetDialog(XFORM_FOLDER, EditorFrame
                .getInstance(), "adl & imscp");

        srcVersion = stDialog.showDialog();
        if (srcVersion == null) {
            return;
        }
        targVersion = stDialog.getSchemaTName();
        if (targVersion == null) {
            return;
        }

        //load all the xslts
        sl = stDialog.getSl();
        // get xslt file name
        xsltLocn = sl.getXSLT(srcVersion, targVersion);

        CTFileOpenDialog ctDialog = new CTFileOpenDialog(srcVersion,
                targVersion, EditorFrame.getInstance());
        ctDialog.showDialog();
        sFile = ctDialog.getSourceFile();
        tFile = ctDialog.getTargetFile();

        if (xsltLocn.equalsIgnoreCase("") || (sFile == null) || (tFile == null)) { //$NON-NLS-1$
            return;
        }
        //handle only xml files
        if(sFile.getName().indexOf(".xml") == -1){
            return;
        }
        xsltLocn = XFORM_FOLDER.getAbsolutePath() + File.separatorChar
                + xsltLocn.trim();

        // in the end save the XSLTd file to the target folder
        String sourceFileName = sFile.getName();
        sourceFileName = sourceFileName.substring(0,sourceFileName.lastIndexOf(".")) + "copy.xml";
       
        //File xsltResultLocn = new File(tFile, sFile.getName());
        File xsltResultLocn = new File(tFile, sourceFileName);
        if (xsltResultLocn.exists()) {
            xsltResultLocn.delete();
        }
        xsltResultLocn = ct
                .transform(sFile, new File(xsltLocn), xsltResultLocn);
        if (xsltResultLocn == null){
            return;
        }

        EditorHandler.getSharedInstance().openFile(xsltResultLocn);

       

    }

}