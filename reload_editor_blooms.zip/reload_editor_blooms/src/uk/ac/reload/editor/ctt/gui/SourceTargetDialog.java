/**
 *  RELOAD TOOLS
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Phillip Beauvoir
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Phillip Beauvoir
 *  e-mail:   p.beauvoir@bolton.ac.uk
 *
 *  Web:      http://www.reload.ac.uk
 *
 */
package uk.ac.reload.editor.ctt.gui;

import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.swing.AbstractAction;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;

import uk.ac.reload.editor.EditorFrame;
import uk.ac.reload.editor.Messages;
import uk.ac.reload.editor.ctt.xformer.ScriptLoader;

import com.brunchboy.util.swing.relativelayout.AttributeConstraint;
import com.brunchboy.util.swing.relativelayout.AttributeType;
import com.brunchboy.util.swing.relativelayout.DependencyManager;
import com.brunchboy.util.swing.relativelayout.RelativeLayout;

/**
 * Dialogs for selecting the source and target schema label in performing xslt 
 * import As and export As function 
 */
public class SourceTargetDialog extends JDialog {
    
    /**
     * Selected source schema name 
     */
    private String schemaSName = null;
    /**
     * Selected target schema name 
     */
    private String schemaTName = null;
    
    // document containing possible xslt transforms
    private Document ctDoc;
    
    private JList sSchemaList;
    private DefaultListModel sModel;
    
    private JList tSchemaList;
    private DefaultListModel tModel;
    
    private JScrollPane sSchemaLstSP;
    private JScrollPane tSchemaLstSP;
    private JTextField selTTxtField;
    private JTextField selSTxtField;
    
    // this contain refe to source/target schema and xslt file
    private ScriptLoader sl;
    
    /**
     * c'str 
     * @param xformDir
     * @param parent
     * @param ver
     * @throws JDOMException
     * @throws IOException
     * @throws FileNotFoundException
     */
    public SourceTargetDialog(File xformDir, JFrame parent, String ver) throws JDOMException, IOException, FileNotFoundException {
        super(parent, Messages.getString("SourceTargetDialog.0"), true); //$NON-NLS-1$
        setSize(420, 400);
        setResizable(false);
        
        sModel = new DefaultListModel();
        sSchemaList = new JList(sModel);       
        sSchemaList.addListSelectionListener(new slistSelListener());
        
        tModel = new DefaultListModel();
        tSchemaList = new JList(tModel);
        
        tSchemaList.addListSelectionListener(new tlistSelListener());
        
        if(ver == null){
            setSchemaDir(xformDir);
        }else{
            filterTargetSchemaList(xformDir, ver);
        }
        
        
        
        RelativeLayout ourLayout = new RelativeLayout();
        getContentPane().setLayout(ourLayout);
        
        
        // Title Label
        JLabel title = new JLabel(Messages.getString("SourceTargetDialog.1")); //$NON-NLS-1$
        title.setFont(title.getFont().deriveFont(14.0f));
        getContentPane().add(title, "title"); //$NON-NLS-1$
        ourLayout.addConstraint("title", AttributeType.TOP, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME,
                        AttributeType.TOP, 10));
        ourLayout.addConstraint("title", AttributeType.HORIZONTAL_CENTER, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME,
                        AttributeType.HORIZONTAL_CENTER));
        // source schema label
        JLabel lblSchema = new JLabel(Messages.getString("SourceTargetDialog.5")); //$NON-NLS-1$
        
        getContentPane().add(lblSchema, "lblSchema"); //$NON-NLS-1$
        ourLayout.addConstraint("lblSchema", AttributeType.TOP, //$NON-NLS-1$
                new AttributeConstraint("title", AttributeType.BOTTOM, 8)); //$NON-NLS-1$
        
        ourLayout.addConstraint("lblSchema", AttributeType.LEFT, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME, AttributeType.LEFT, 20));
        
        
        // target schema label
        JLabel lbltchema = new JLabel(Messages.getString("SourceTargetDialog.10")); //$NON-NLS-1$
        
        getContentPane().add(lbltchema, "lbltchema"); //$NON-NLS-1$
        
        ourLayout.addConstraint("lbltchema", AttributeType.TOP, //$NON-NLS-1$
                new AttributeConstraint("lblSchema", AttributeType.TOP)); //$NON-NLS-1$
        ourLayout.addConstraint("lbltchema", AttributeType.LEFT, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME, AttributeType.LEFT, 200));
        
        sSchemaLstSP = new JScrollPane();
        sSchemaLstSP.setViewportView(sSchemaList);
        getContentPane().add(sSchemaLstSP, "sSchemaLstSP"); //$NON-NLS-1$
        ourLayout.addConstraint("sSchemaLstSP", AttributeType.LEFT, //$NON-NLS-1$
                new AttributeConstraint("lblSchema", AttributeType.LEFT)); //$NON-NLS-1$
        ourLayout.addConstraint("sSchemaLstSP", AttributeType.RIGHT, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME, AttributeType.LEFT, 200));
        //new AttributeConstraint("lbltchema", AttributeType.LEFT));
        ourLayout.addConstraint("sSchemaLstSP", AttributeType.TOP, //$NON-NLS-1$
                new AttributeConstraint("lblSchema", AttributeType.BOTTOM, 4)); //$NON-NLS-1$
        ourLayout.addConstraint("sSchemaLstSP", AttributeType.BOTTOM, //$NON-NLS-1$
                new AttributeConstraint("btnOK", AttributeType.TOP, -40)); //$NON-NLS-1$
        
        
        tSchemaLstSP = new JScrollPane();
        tSchemaLstSP.setViewportView(tSchemaList);
        getContentPane().add(tSchemaLstSP, "tSchemaLstSP"); //$NON-NLS-1$
        
        ourLayout.addConstraint("tSchemaLstSP", AttributeType.LEFT, //$NON-NLS-1$
                new AttributeConstraint("sSchemaLstSP", AttributeType.RIGHT)); //$NON-NLS-1$
        ourLayout.addConstraint("tSchemaLstSP", AttributeType.RIGHT, //$NON-NLS-1$
                new AttributeConstraint("sSchemaLstSP", AttributeType.RIGHT, 200)); //$NON-NLS-1$
        ourLayout.addConstraint("tSchemaLstSP", AttributeType.TOP, //$NON-NLS-1$
                new AttributeConstraint("lbltchema", AttributeType.BOTTOM, 4)); //$NON-NLS-1$
        ourLayout.addConstraint("tSchemaLstSP", AttributeType.BOTTOM, //$NON-NLS-1$
                new AttributeConstraint("btnOK", AttributeType.TOP, -40)); //$NON-NLS-1$
        
        // Selected Source schema label
        JLabel selSLbl = new JLabel(Messages.getString("SourceTargetDialog.32")); //$NON-NLS-1$
        
        selSTxtField = new JTextField(""); //$NON-NLS-1$
        
        selSTxtField.setEditable(false);
        
        getContentPane().add(selSLbl, "selSLbl"); //$NON-NLS-1$
        
        ourLayout.addConstraint("selSLbl", AttributeType.LEFT, //$NON-NLS-1$
                new AttributeConstraint("sSchemaLstSP", AttributeType.LEFT)); //$NON-NLS-1$
        ourLayout.addConstraint("selSLbl", AttributeType.RIGHT, //$NON-NLS-1$
                new AttributeConstraint("sSchemaLstSP", AttributeType.RIGHT)); //$NON-NLS-1$
        ourLayout.addConstraint("selSLbl", AttributeType.TOP, //$NON-NLS-1$
                new AttributeConstraint("sSchemaLstSP", AttributeType.BOTTOM)); //$NON-NLS-1$
        ourLayout.addConstraint("selSLbl", AttributeType.BOTTOM, //$NON-NLS-1$
                new AttributeConstraint("sSchemaLstSP", AttributeType.BOTTOM, 20)); //$NON-NLS-1$
        
        getContentPane().add(selSTxtField, "selSTxtField"); //$NON-NLS-1$
        
        ourLayout.addConstraint("selSTxtField", AttributeType.LEFT, //$NON-NLS-1$
                new AttributeConstraint("selSLbl", AttributeType.LEFT)); //$NON-NLS-1$
        ourLayout.addConstraint("selSTxtField", AttributeType.RIGHT, //$NON-NLS-1$
                new AttributeConstraint("selSLbl", AttributeType.RIGHT)); //$NON-NLS-1$
        ourLayout.addConstraint("selSTxtField", AttributeType.TOP, //$NON-NLS-1$
                new AttributeConstraint("selSLbl", AttributeType.BOTTOM)); //$NON-NLS-1$
        ourLayout.addConstraint("selSTxtField", AttributeType.BOTTOM, //$NON-NLS-1$
                new AttributeConstraint("selSLbl", AttributeType.BOTTOM, 20)); //$NON-NLS-1$
        
        //		 Selected target schema label
        JLabel selTLbl = new JLabel(Messages.getString("SourceTargetDialog.2")); //$NON-NLS-1$
        selTTxtField = new JTextField(""); //$NON-NLS-1$
        
        selTTxtField.setEditable(false);
        
        getContentPane().add(selTLbl, "selTLbl"); //$NON-NLS-1$
        
        ourLayout.addConstraint("selTLbl", AttributeType.LEFT, //$NON-NLS-1$
                new AttributeConstraint("tSchemaLstSP", AttributeType.LEFT)); //$NON-NLS-1$
        ourLayout.addConstraint("selTLbl", AttributeType.RIGHT, //$NON-NLS-1$
                new AttributeConstraint("tSchemaLstSP", AttributeType.RIGHT)); //$NON-NLS-1$
        ourLayout.addConstraint("selTLbl", AttributeType.TOP, //$NON-NLS-1$
                new AttributeConstraint("tSchemaLstSP", AttributeType.BOTTOM)); //$NON-NLS-1$
        ourLayout.addConstraint("selTLbl", AttributeType.BOTTOM, //$NON-NLS-1$
                new AttributeConstraint("tSchemaLstSP", AttributeType.BOTTOM, 20)); //$NON-NLS-1$
        
        getContentPane().add(selTTxtField, "selTTxtField"); //$NON-NLS-1$
        
        ourLayout.addConstraint("selTTxtField", AttributeType.LEFT, //$NON-NLS-1$
                new AttributeConstraint("selTLbl", AttributeType.LEFT)); //$NON-NLS-1$
        ourLayout.addConstraint("selTTxtField", AttributeType.RIGHT, //$NON-NLS-1$
                new AttributeConstraint("selTLbl", AttributeType.RIGHT)); //$NON-NLS-1$
        ourLayout.addConstraint("selTTxtField", AttributeType.TOP, //$NON-NLS-1$
                new AttributeConstraint("selTLbl", AttributeType.BOTTOM)); //$NON-NLS-1$
        ourLayout.addConstraint("selTTxtField", AttributeType.BOTTOM, //$NON-NLS-1$
                new AttributeConstraint("selTLbl", AttributeType.BOTTOM, 20));		 //$NON-NLS-1$
        
        
        
        // Cancel Buttton
        JButton btnCancel = new JButton(Messages.getString("SourceTargetDialog.72")); //$NON-NLS-1$
        btnCancel.addActionListener(new CancelClick());
        getContentPane().add(btnCancel, "btnCancel"); //$NON-NLS-1$
        
        ourLayout.addConstraint("btnCancel", AttributeType.RIGHT, //$NON-NLS-1$
                new AttributeConstraint("selTTxtField", AttributeType.RIGHT)); //$NON-NLS-1$
        ourLayout.addConstraint("btnCancel", AttributeType.BOTTOM, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME, AttributeType.BOTTOM, -5));
        
        
        // OK Button
        JButton btnOK = new JButton(Messages.getString("SourceTargetDialog.77")); //$NON-NLS-1$
        btnOK.addActionListener(new OKClick());
        getContentPane().add(btnOK, "btnOK"); //$NON-NLS-1$
        
        
        ourLayout.addConstraint("btnOK", AttributeType.RIGHT, //$NON-NLS-1$
                new AttributeConstraint("btnCancel", AttributeType.LEFT, -5)); //$NON-NLS-1$
        ourLayout.addConstraint("btnOK", AttributeType.BOTTOM, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME, AttributeType.BOTTOM, -5));
        
        //pack();
        setLocationRelativeTo(EditorFrame.getInstance());
    }
    
    
    /**
     * Show the dialog
     * @return The user response either OK_OPTION or CANCEL_OPTION
     */
    public String showDialog() {
        show();
        return schemaSName;
    }
    
    
    
    /**
     * OK handler
     */
    private class OKClick extends AbstractAction {
        public void actionPerformed(ActionEvent e) {
            schemaSName = selSTxtField.getText();
            schemaTName = selTTxtField.getText();
            dispose();
        }
    }
    
    /**
     * Cancel handler
     */
    private class CancelClick extends AbstractAction {
        public void actionPerformed(ActionEvent e) {
            schemaSName = null;
            dispose();
        }
    }
    
    /**
     * Listener for list selection event when choosing source schema
     * update the available target schema, set the value in selected text field 
     */
    
    private class slistSelListener implements ListSelectionListener {
        public void valueChanged(ListSelectionEvent event) {
            tModel.removeAllElements();
            if (!event.getValueIsAdjusting()) {          	
                schemaSName = (String)sSchemaList.getSelectedValue();
                updateTargetSchemaList(schemaSName);
                selSTxtField.setText(schemaSName);
                
            }
        }
    }
    
    /**
     * Listener for list selection event when choosing target schema
     * set the value of target schema in text field
     */
    private class tlistSelListener implements ListSelectionListener {
        public void valueChanged(ListSelectionEvent event) {
            if (!event.getValueIsAdjusting()) {
                selTTxtField.setText((String)tSchemaList.getSelectedValue());
            }
        }
    }
    
    /**
     * Set the transfomer directory and load xslt files
     * @param xformDir
     * @throws JDOMException
     * @throws IOException
     * @throws FileNotFoundException
     */
    
    
    public void setSchemaDir(File xformDir) throws JDOMException, IOException, FileNotFoundException {
        sl = new ScriptLoader(xformDir);
        ctDoc = sl.getCtXRef();
        List sSchemas = ctDoc.getRootElement().getChildren("sourceSchema"); //$NON-NLS-1$
        Iterator sIter = sSchemas.iterator();
        int indx = 0;
        int indx1 = 0;
        while (sIter.hasNext()) {
            Element sSchema = (Element)sIter.next();
            if ((sSchema.getTextTrim().indexOf("adl") != -1)
                    || (sSchema.getTextTrim().indexOf("imscp") != -1)) {            
            
            sModel.add(indx++, sSchema.getChild("sourceSchemaLabel").getTextTrim()); //$NON-NLS-1$
            Iterator tIter =  sSchema.getChildren("targetSchema").iterator(); //$NON-NLS-1$
            while (tIter.hasNext()) {
                Element tSchema = (Element)tIter.next();
                tModel.add(indx1++, tSchema.getChild("targetSchemaLabel").getTextTrim()); //$NON-NLS-1$
            }
            }
        }
        return;
    }
    
    /**
     * update the target schema list based on selection on the source schema list
     * @param sSchemaLbl
     */
    
    public void updateTargetSchemaList(String sSchemaLbl){
        List sSchemas = ctDoc.getRootElement().getChildren("sourceSchema"); //$NON-NLS-1$
        Iterator sIter = sSchemas.iterator();
        int indx = 0;
        while (sIter.hasNext()) {
            Element sSchema = (Element)sIter.next();
            if(sSchema.getChild("sourceSchemaLabel").getTextTrim().equalsIgnoreCase(sSchemaLbl)){ //$NON-NLS-1$
                Iterator tIter =  sSchema.getChildren("targetSchema").iterator(); //$NON-NLS-1$
                while (tIter.hasNext()) {
                    Element tSchema = (Element)tIter.next();
                    tModel.add(indx++, tSchema.getChild("targetSchemaLabel").getTextTrim()); //$NON-NLS-1$
                }
                
            }
            
        }
        
    }
    
    
    /**
     * List a filtered list of target schemas for a given source schema
     * based on available xslt's
     * @param xformDir
     * @param schemaVer
     * @throws JDOMException
     * @throws IOException
     * @throws FileNotFoundException
     */
    
    public void filterTargetSchemaList(File xformDir, String schemaVer)throws JDOMException, 
    IOException, FileNotFoundException {
        sl = new ScriptLoader(xformDir);
        ctDoc = sl.getCtXRef();
        List sSchemas = ctDoc.getRootElement().getChildren("sourceSchema"); //$NON-NLS-1$
        Iterator sIter = sSchemas.iterator();
        int indx = 0;
        int indx1 = 0;
        
        String[] result = schemaVer.split("&");
        
      
        while (sIter.hasNext()) {
            Element sSchema = (Element) sIter.next();            
            if (result.length == 1) {
                if (sSchema.getChild("sourceSchemaLabel").getTextTrim()
                        .equalsIgnoreCase(schemaVer)) { //$NON-NLS-1$

                    sModel.add(indx, sSchema
                            .getChild("sourceSchemaLabel").getTextTrim()); //$NON-NLS-1$ 
                    Iterator tIter = sSchema
                            .getChildren("targetSchema").iterator();//$NON-NLS-1$ 
                    while (tIter.hasNext()) {
                        Element tSchema = (Element) tIter.next();
                        tModel.add(indx1++, tSchema.getChild(
                                "targetSchemaLabel").getTextTrim());//$NON-NLS-1$ }

                        
                    }
                }
            } else if ((sSchema.getTextTrim().indexOf(result[0].trim()) == -1)
                    && (sSchema.getTextTrim().indexOf(result[1].trim()) == -1)) { //$NON-NLS-1$

                
                sModel.add(indx, sSchema
                        .getChild("sourceSchemaLabel").getTextTrim()); //$NON-NLS-1$ 
                Iterator tIter = sSchema.getChildren("targetSchema").iterator();//$NON-NLS-1$ 
                while (tIter.hasNext()) {
                    Element tSchema = (Element) tIter.next();
                    tModel.add(indx1++, tSchema
                            .getChild("targetSchemaLabel").getTextTrim());//$NON-NLS-1$ }
                    
                }

            }

        }
        return;
        
    }
    
 
    /**
     * @return Returns the schemaSName.
     */
    public String getSchemaSName() {
        return schemaSName;
    }
    /**
     * @return Returns the schemaTName.
     */
    public String getSchemaTName() {
        return schemaTName;
    }
    /**
     * @return Returns the ctDoc.
     */
    public Document getCtDoc() {
        return ctDoc;
    }
    /**
     * @return Returns the sl.
     */
    public ScriptLoader getSl() {
        return sl;
    }
}
