/**
 *  RELOAD Editor - An IMS Metadata, Content Packaging and Learning Design tool.
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Phillip Beauvoir
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Phillip Beauvoir
 *  e-mail:   p.beauvoir@bolton.ac.uk
 *
 *  Web:      http://www.reload.ac.uk
 *
 */
package uk.ac.reload.editor.menu;

import java.awt.event.ActionEvent;

import uk.ac.reload.dweezil.menu.MenuAction;
import uk.ac.reload.editor.EditorHandler;
import uk.ac.reload.editor.IIcons;
import uk.ac.reload.editor.scorm.scorm2004.SCORM13_EditorHandler;

/**
 * Open File Menu Action
 *
 * @author Jennifer Brooks
 * @version 2004
 */
public class MenuAction_NewTemplate extends MenuAction {

    /**
     * Constructor for Open file with Dialog
     */
    public MenuAction_NewTemplate() {
        super("ADL SCORM 2004 Package from Template", IIcons.ICON_CPSCORM);
    }

    public void actionPerformed(ActionEvent e) {
        // Start the loader thread
        Thread thread = new Thread() {
            public void run() {
                setEnabled(false);  // Stop inadvertant presses
                //ReloadEditorDocumentHandler.openFile(ReloadEditor.getInstance(), "Choose Template", true);
                //EditorHandler.getSharedInstance().openFile();
                EditorHandler.getSharedInstance()
                .openSCORMTemplate("Choose a SCORM 2004 Template", SCORM13_EditorHandler.TEMPLATE_FOLDER);
                setEnabled(true);
            }
        };

        thread.start();
    }
}

