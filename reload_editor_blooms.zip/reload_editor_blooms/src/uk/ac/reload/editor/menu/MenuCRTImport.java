/**
 *  RELOAD TOOLS
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Phillip Beauvoir
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Phillip Beauvoir
 *  e-mail:   p.beauvoir@bolton.ac.uk
 *
 *  Web:      http://www.reload.ac.uk
 *
 */
package uk.ac.reload.editor.menu;

import java.awt.event.ActionEvent;

import uk.ac.reload.dweezil.gui.ErrorDialogBox;
import uk.ac.reload.dweezil.menu.MenuAction;
import uk.ac.reload.editor.Messages;
import uk.ac.reload.editor.ctt.gui.CTDialog;


/**
 * Menu for exporting content packages using available xslts
 */
public class MenuCRTImport extends MenuAction {
    
    /*
     * 
     */
    public MenuCRTImport() {
        super(Messages.getString("MenuCRTImport.0")); //$NON-NLS-1$
        
    }
    /*
     *  (non-Javadoc)
     * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
     */
    public void actionPerformed(ActionEvent e) {
        // Try to create a new CT Editor internal frame 
        //final CTDialog ctd = new CTDialog();
        
        try{
            CTDialog.ctImport();
           /* final EditorInternalFrame iframe = ctd.ctImport();
            if(iframe == null){
                return;
            }
            SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    EditorHandler.getSharedInstance().addInternalFrame(iframe);
                    iframe.show();
                }
            });*/
            
        }catch (Exception ex){
            //ex.printStackTrace();
            ErrorDialogBox.showWarning(Messages.getString("MenuCRTImport.1"), Messages.getString("MenuCRTImport.2") ,ex); //$NON-NLS-1$ //$NON-NLS-2$
        }
        
        
    }
    
}
