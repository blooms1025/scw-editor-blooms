/**
  *  RELOAD Editor - An IMS Metadata, Content Packaging and Learning Design tool.
  *
  *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Phillip Beauvoir, Phil Barker, Tina Manoharan
  *
  *  Permission is hereby granted, free of charge, to any person obtaining a copy
  *  of this software and associated documentation files (the "Software"), to deal
  *  in the Software without restriction, including without limitation the rights
  *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
  *  copies of the Software, and to permit persons to whom the Software is
  *  furnished to do so, subject to the following conditions:
  *
  *  The above copyright notice and this permission notice shall be included in
  *  all copies or substantial portions of the Software.
  *
  *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
  *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
  *
  *  Project Management Contact:
  *
  *  Oleg Liber
  *  Bolton Institute of Higher Education
  *  Deane Road
  *  Bolton BL3 5AB
  *  UK
  *
  *  e-mail:   o.liber@bolton.ac.uk
  *
  *  Phil Barker
  *  ICBL, Heriot-Watt University
  *  Riccarton
  *  Edinburgh EH14 4AS
  *  UK
  *
  *  e-mail:   philb@icbl.hw.ac.uk
  *
  *
  *  Technical Contact:
  *
  *  Phillip Beauvoir
  *  e-mail:   p.beauvoir@bolton.ac.uk
  *
  *  Web:      http://www.reload.ac.uk
  *
  *  Tina Manoharan
  *  e-mail:   ceetm2@macs.hw.ac.uk
  *
  */


package uk.ac.reload.editor.menu;

import java.awt.event.ActionEvent;

import uk.ac.reload.dweezil.menu.MenuAction;
import uk.ac.reload.editor.Messages;
import uk.ac.reload.editor.vdx.VdexEditorHandler;

/**
 * The Menu Action "Export Zthes Vocabulary"
 *
 *
 * @author Tina Manoharan
 * @version 2003-10-20
 */
public class MenuAction_ExportZthes
extends MenuAction {

	/**
    * Default constructor
    */
    public MenuAction_ExportZthes() {

		super(Messages.getString("MenuAction_ExportZthes.0"), null); //$NON-NLS-1$
		//setEnabled(false);
		setEnabled(true);
	}

    /**
     * The Menu Item was selected.
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        // Start the loader thread
        Thread thread = new Thread() {
            public void run() {
                VdexEditorHandler.exportZthesVocabulary();
            }
        };

        thread.start();
    }

}
