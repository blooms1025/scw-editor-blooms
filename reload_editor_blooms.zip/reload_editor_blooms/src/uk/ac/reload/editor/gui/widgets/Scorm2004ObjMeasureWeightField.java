/**
 *  Content Re-Engineerng Tool
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Roy P Cherian
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Roy P Cherian
 *  e-mail:   rc3@bolton.ac.uk
 *
 **  Reload Dweezil Library - Handles GUI, Undo and Utility functions
 */
package uk.ac.reload.editor.gui.widgets;

import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;

/**
 * An ObjectiveMeasureWeight TextField Widget
 * 
 * @author Jennifer Brooks
 * @version 2004
 */
public class Scorm2004ObjMeasureWeightField extends TextFieldWidget {
    /**
     * Default Constructor
     */
    public Scorm2004ObjMeasureWeightField() {
        this(-1);
    }

    /**
     * Number Constructor
     */
    public Scorm2004ObjMeasureWeightField(int maxLength) {
        setMaxLength(maxLength);
        setDocument(new ObjMeasureWeightFieldVerifier());
        setUI();
    }

    class ObjMeasureWeightFieldVerifier extends TextFieldVerifier {
        String nums = "0123456789";

        String zero = "0";

        String one = "1";

        boolean isZero = false;

        private int checkNum = 0;

        protected int _offset = -1;

        public void insertString(int offset, String str, AttributeSet attSet)
                throws BadLocationException {
            if (str == null)
                return;
            _offset = offset;
            super.insertString(offset, str, attSet);
        }

        /**
         * Check for number input
         */
boolean isStringOK(String str) {
            for(int i = 0; i < str.length(); i++) {
                String s = str.substring(i, i + 1);
                if((_offset == checkNum || _offset == checkNum+1) && str.equals(".")){
                    return true; 
                }else if(_offset == checkNum && (zero.indexOf(s) >= 0)){
                        isZero = true;
                        return true;
                        
                }else if(_offset == checkNum && (one.indexOf(s) >= 0)){
                        isZero = false;
                        return true;
                        
                }else if(nums.indexOf(s) >= 0 && (_offset >= checkNum+2) && isZero){
                    return true;
                }else if(nums.indexOf(s) == 0 && (_offset >= checkNum+2) && !isZero){
                    return true; 
                }else {
                    return false;
                }
            }
            return false;
        }    }
}