/**
 *  RELOAD TOOLS
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Phillip Beauvoir
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Phillip Beauvoir
 *  e-mail:   p.beauvoir@bolton.ac.uk
 *
 *  Web:      http://www.reload.ac.uk
 *
 */
package uk.ac.reload.editor.gencontent.editor;

import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.io.File;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import uk.ac.reload.dweezil.gui.DweezilFileChooser;
import uk.ac.reload.dweezil.gui.DweezilFolderChooser;
import uk.ac.reload.editor.EditorFrame;
import uk.ac.reload.editor.Messages;

import com.brunchboy.util.swing.relativelayout.AttributeConstraint;
import com.brunchboy.util.swing.relativelayout.AttributeType;
import com.brunchboy.util.swing.relativelayout.DependencyManager;
import com.brunchboy.util.swing.relativelayout.RelativeLayout;

/**
 *For selecting the source and target schema names for doing transform 
 *  
 */
public class NewCPDialog extends JDialog {
    
    /**
     * The File Chooser
     */
    private DweezilFolderChooser _sourceChooser;
    private File sourceFile;
    
    private DweezilFolderChooser _targetChooser;
    private File targetFile;
     
    private RelativeLayout layout;
    
    private JButton schemaOpenBtn;
    private JButton newCPFolderBtn;

    private JTextField txtContentFolder;
    
    private JTextField txtSchemaFolder;
    
    /**
     * @throws java.awt.HeadlessException
     */
    public NewCPDialog(JFrame parent)
    throws HeadlessException {
        super(parent, Messages.getString("NewCPDialog.0"), true); //$NON-NLS-1$
        init();		
        newCPFolderBtn.addActionListener(new AbstractAction() {
            
            public void actionPerformed(ActionEvent evt) {

                // Show dialog; and get selected file
                int rtn = getSourceFolderChooser().showDialog(NewCPDialog.this,
                        "Select"); //$NON-NLS-1$
                // User Cancelled
                if (rtn != DweezilFolderChooser.APPROVE_OPTION) {
                    return;
                }
                // Get the chosen folder
                sourceFile = getSourceFolderChooser().getSelectedFileAndStore();

                if (sourceFile != null)
                    txtContentFolder.setText(sourceFile.getName());
            }
        });
        
        
    }
    

    /**
     * OK handler
     */
    private class OKClick extends AbstractAction {
        public void actionPerformed(ActionEvent e) {
            //schemaFName = "could not find schema";
            dispose();
        }
    }
    
    /**
     * Cancel handler
     */
    private class CancelClick extends AbstractAction {
        public void actionPerformed(ActionEvent e) {
            _sourceChooser = null;
            dispose();
        }
    }
    
    
    /**
     * @return The DweezilFileChooser
     */
    public DweezilFileChooser getSourceFolderChooser() {
        return _sourceChooser;
    }
    
    /**
     * @return The DweezilFolderChooser
     */
    public DweezilFolderChooser getTargetFolderChooser() {
        return _targetChooser;
    }
    
    /*
     * 
     */
    public void showDialog() {
        show();
    }
    /**
     * @return Returns the sourceFile.
     */
    public File getSourceFile() {
        return sourceFile;
    }
    /**
     * @return Returns the targetFile.
     */
    public File getTargetFile() {
        return targetFile;
    }
    
    /**
     * Setup the dialog panel
     */
    protected void init() {
        setSize(500, 200);
        //setResizable(false);
        
        layout = new RelativeLayout();
        getContentPane().setLayout(layout);
        _sourceChooser = new DweezilFolderChooser();
        _targetChooser = new DweezilFolderChooser();
        
        JLabel title = new JLabel(Messages.getString("NewCPDialog.2")); //$NON-NLS-1$
        title.setFont(title.getFont().deriveFont(14.0f));
        getContentPane().add(title, "title"); //$NON-NLS-1$
        layout.addConstraint("title", AttributeType.TOP, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME,
                        AttributeType.TOP, 10));
        layout.addConstraint("title", AttributeType.HORIZONTAL_CENTER, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME,
                        AttributeType.HORIZONTAL_CENTER));
        
        
        // for selecting source file folder
        
        JLabel lblContent = new JLabel(Messages.getString("NewCPDialog.6")); //$NON-NLS-1$
        
        getContentPane().add(lblContent, "lblContent"); //$NON-NLS-1$
        layout.addConstraint("lblContent", AttributeType.TOP, //$NON-NLS-1$
                new AttributeConstraint("title", AttributeType.BOTTOM, 10)); //$NON-NLS-1$
        layout.addConstraint("lblContent", AttributeType.LEFT, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME,
                        AttributeType.LEFT, 25));
        
        
        
        // add a text field for displaying selected source file
        txtContentFolder = new JTextField(""); //$NON-NLS-1$
        getContentPane().add(txtContentFolder, "txtContentFolder"); //$NON-NLS-1$
        
        layout.addConstraint("txtContentFolder", AttributeType.TOP, //$NON-NLS-1$
                new AttributeConstraint("lblContent", AttributeType.BOTTOM, 10)); //$NON-NLS-1$
        layout.addConstraint("txtContentFolder", AttributeType.LEFT, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME,
                        AttributeType.LEFT, 25));
        layout.addConstraint("txtContentFolder", AttributeType.RIGHT, //$NON-NLS-1$
                new AttributeConstraint("newCPFolderBtn", AttributeType.LEFT)); //$NON-NLS-1$
                //new AttributeConstraint("txtSource", AttributeType.RIGHT));
        
        // add a button for open source file
        
        newCPFolderBtn = new JButton();
        
        newCPFolderBtn.setText("..."); //$NON-NLS-1$
        
        getContentPane().add(newCPFolderBtn, "newCPFolderBtn"); //$NON-NLS-1$
        
        layout.addConstraint("newCPFolderBtn", AttributeType.TOP, //$NON-NLS-1$
                new AttributeConstraint("txtContentFolder", AttributeType.TOP)); //$NON-NLS-1$
        layout.addConstraint("newCPFolderBtn", AttributeType.RIGHT, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME,
                        AttributeType.HORIZONTAL_CENTER, -10));
        layout.addConstraint("newCPFolderBtn", AttributeType.BOTTOM, //$NON-NLS-1$
                new AttributeConstraint("txtContentFolder", AttributeType.BOTTOM)); //$NON-NLS-1$
        
        // for selecting target file/folder
        
        JLabel lblTargetFile = new JLabel(Messages.getString("NewCPDialog.25")); //$NON-NLS-1$
        
        getContentPane().add(lblTargetFile, "lblTargetFile"); //$NON-NLS-1$
        layout.addConstraint("lblTargetFile", AttributeType.TOP, //$NON-NLS-1$
                new AttributeConstraint("title", AttributeType.BOTTOM, 10)); //$NON-NLS-1$
        layout.addConstraint("lblTargetFile", AttributeType.LEFT, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME,
                        AttributeType.HORIZONTAL_CENTER, 10));
        
        //		 add a text field for displaying selected target file
 
        txtSchemaFolder = new JTextField(""); //$NON-NLS-1$
        getContentPane().add(txtSchemaFolder, "txtSchemaFolder"); //$NON-NLS-1$
        
        layout.addConstraint("txtSchemaFolder", AttributeType.TOP, //$NON-NLS-1$
                new AttributeConstraint("lblTargetFile", AttributeType.BOTTOM, 10)); //$NON-NLS-1$
        layout.addConstraint("txtSchemaFolder", AttributeType.LEFT, //$NON-NLS-1$
                new AttributeConstraint("lblTargetFile", AttributeType.LEFT)); //$NON-NLS-1$
        layout.addConstraint("txtSchemaFolder", AttributeType.RIGHT, //$NON-NLS-1$
                new AttributeConstraint("schemaOpenBtn", AttributeType.LEFT)); //$NON-NLS-1$
 
        
        //	 add a button for open target file
        
        schemaOpenBtn = new JButton();
        schemaOpenBtn.setText("..."); //$NON-NLS-1$
        schemaOpenBtn.addActionListener(new AbstractAction() {
            public void actionPerformed(ActionEvent evt) {
                // Show dialog; and get selected file
                int rtn = getTargetFolderChooser().showDialog(NewCPDialog.this, "Select"); //$NON-NLS-1$
                // User Cancelled
                if(rtn != DweezilFolderChooser.APPROVE_OPTION) {
                    return;
                }
                // Get the chosen folder
                targetFile = getTargetFolderChooser().getSelectedFileAndStore();
                
                if(targetFile!= null)
                    txtSchemaFolder.setText(targetFile.getName());
            }
        });
        
        
        getContentPane().add(schemaOpenBtn, "schemaOpenBtn"); //$NON-NLS-1$
        
        layout.addConstraint("schemaOpenBtn", AttributeType.TOP, //$NON-NLS-1$
                new AttributeConstraint("txtSchemaFolder", AttributeType.TOP)); //$NON-NLS-1$
        layout.addConstraint("schemaOpenBtn", AttributeType.RIGHT, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME,
                        AttributeType.RIGHT, -5));
        layout.addConstraint("schemaOpenBtn", AttributeType.BOTTOM, //$NON-NLS-1$
                new AttributeConstraint("txtSchemaFolder", AttributeType.BOTTOM)); //$NON-NLS-1$
        
        // Cancel Buttton
        JButton btnCancel = new JButton(Messages.getString("NewCPDialog.46")); //$NON-NLS-1$
        btnCancel.addActionListener(new CancelClick());
        getContentPane().add(btnCancel, "btnCancel"); //$NON-NLS-1$
        
        layout.addConstraint("btnCancel", AttributeType.RIGHT, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME,
                        AttributeType.RIGHT));
        layout.addConstraint("btnCancel", AttributeType.BOTTOM, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME,
                        AttributeType.BOTTOM, -5));
        
        // OK Button
        JButton btnOK = new JButton(Messages.getString("NewCPDialog.50")); //$NON-NLS-1$
        btnOK.addActionListener(new OKClick());
        getContentPane().add(btnOK, "btnOK"); //$NON-NLS-1$
        
        layout.addConstraint("btnOK", AttributeType.RIGHT, //$NON-NLS-1$
                new AttributeConstraint("btnCancel", AttributeType.LEFT, -5)); //$NON-NLS-1$
        layout.addConstraint("btnOK", AttributeType.BOTTOM, //$NON-NLS-1$
                new AttributeConstraint(DependencyManager.ROOT_NAME,
                        AttributeType.BOTTOM, -5));
        setLocationRelativeTo(EditorFrame.getInstance());
        
    }
    
}