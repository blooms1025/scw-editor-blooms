/**
 *  RELOAD TOOLS
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Phillip Beauvoir
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Phillip Beauvoir
 *  e-mail:   p.beauvoir@bolton.ac.uk
 *
 *  Web:      http://www.reload.ac.uk
 *
 */
package uk.ac.reload.editor.gencontent;

import java.io.File;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.StringTokenizer;

import org.eclipse.xsd.XSDSchema;
import org.jdom.Attribute;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.Namespace;

import uk.ac.reload.diva.util.ZipUtils;
import uk.ac.reload.dweezil.gui.ErrorDialogBox;
import uk.ac.reload.editor.EditorFrame;
import uk.ac.reload.editor.EditorHandler;
import uk.ac.reload.editor.EditorInternalFrame;
import uk.ac.reload.editor.Messages;
import uk.ac.reload.editor.contentpackaging.CP_EditorHandler;
import uk.ac.reload.editor.contentpackaging.xml.CP114_SchemaController;
import uk.ac.reload.editor.gencontent.editor.GenCPEditor;
import uk.ac.reload.editor.gencontent.editor.NewCPDialog;
import uk.ac.reload.editor.gencontent.xml.GenCPSchemaController;
import uk.ac.reload.editor.gencontent.xml.GenContentPackage;
import uk.ac.reload.editor.gencontent.xml.GenMDSchemaController;
import uk.ac.reload.editor.metadata.xml.MD_SchemaController;
import uk.ac.reload.editor.prefs.EditorPrefs;
import uk.ac.reload.jdom.XMLUtils;
import uk.ac.reload.moonunit.contentpackaging.CP_Core;
import uk.ac.reload.moonunit.schema.SchemaException;
import uk.ac.reload.moonunit.schema.SchemaModel;
import uk.ac.reload.moonunit.schema.utils.SchemaUtils;

/**
 * Content editor handler for editing localised content packages
 */
public class GenContentEditorHandler extends CP_EditorHandler {
    
    
    /**
     * 
     */
    public GenContentEditorHandler() {
        super();
        
    }
    
    /**
     * 
     */
    public boolean canCreateDocuments() {
        return true;
    }
    /**
     * 
     */
    public boolean canEditFile(File file) {
        return checkFolder(file);
    }
    /**
     * 
     */
    public EditorInternalFrame editFile(File file) throws JDOMException,
    SchemaException, IOException {
        return getEditorFrame(file);
    }
    /**
     * 
     */
    public String getDefaultMDVersion() {
        // This will have to be changed to load localised MD files
        return super.getDefaultMDVersion();
    }
    /**
     * 
     */
    public String getDefaultVersion() {
        return super.getDefaultVersion();
    }
    
    /**
     * 
     */
    public String[] getSupportedVersions() {
        return null;
    }
    /**
     * 
     */
    protected Document getDocument(File file) throws IOException, JDOMException {
        return super.getDocument(file);
    }
    
    /**
     * 
     */
    public String getName() {
        return Messages.getString("GenContentEditorHandler.0"); //$NON-NLS-1$
    }
    
    /**
     * 
     */
    public String getVersion(Namespace ns) {
        // TODO Auto-generated method stub
        return super.getVersion(ns);
    }
    
    /**  Create a new document using localised schema and new editor frame for editing
     * 
     */   
    public EditorInternalFrame newDocument() throws JDOMException,
            SchemaException, IOException {

        // find location of input file and target folder
        NewCPDialog cpDialog = new NewCPDialog(EditorFrame.getInstance());
        cpDialog.showDialog();
        File cpFolder = cpDialog.getSourceFile();
        File schemaFolder = cpDialog.getTargetFile();
        if ((cpFolder == null) || (schemaFolder == null)) {
            return null;
        }

       try{
           GenCPSchemaController.setSchemaFiles(schemaFolder.getAbsolutePath());
       }catch(Exception ex){
           ErrorDialogBox.showWarning(Messages.getString("GenContentEditorHandler.1"), Messages.getString("GenContentEditorHandler.2"), ex); //$NON-NLS-1$ //$NON-NLS-2$
           return null;
       }
       
       GenCPSchemaController cpController = new GenCPSchemaController();       
        MD_SchemaController mdController=null;
        if(GenCPSchemaController.getMdSchemaFile() == null){
        String versionMD = EditorPrefs.getInstance().getValue(
                EditorPrefs.CP_DEFAULT_MD_VERSION);
        mdController = (MD_SchemaController) EditorHandler.MD_EDITORHANDLER
                .getSchemaControllerInstance(versionMD);
        }else{
            //File mdFile = GenCPSchemaController.getMdSchemaFile();
            GenMDSchemaController.setSchemaFile(GenCPSchemaController.getMdSchemaFile());
            mdController = new GenMDSchemaController();
        }
        GenContentPackage cp = new GenContentPackage(cpFolder, cpController,
                mdController);
        //Element root = cp.getDocument().getRootElement(); //TODO changed by Roy
        //cp.getDocument().setRootElement(root);
        
        if (!GenCPSchemaController.extSchemaLocns.equals("")) { //$NON-NLS-1$
            addExtSchemaLocnsToRoot(cp.getDocument(), GenCPSchemaController.extSchemaLocns);
        }
        return new GenCPEditor(cp);
  
    }
     
     
    
     /**
     * @param document
     * @param extSchemaLocns
     */
    private void addExtSchemaLocnsToRoot(Document document, String extSchemaLocns) {
        // TODO Auto-generated method stub
        Element root = document.getRootElement();
        if(root != null){
        //Attribute locnAtt = root.getAttribute(XMLUtils.XSI_SchemaLocation, XMLUtils.XSI_Namespace);
        String schLocnStr = root.getAttributeValue(XMLUtils.XSI_SchemaLocation, XMLUtils.XSI_Namespace);
        if(schLocnStr.indexOf(extSchemaLocns) == -1){
            schLocnStr = schLocnStr + " " + extSchemaLocns;         //$NON-NLS-1$
            root.setAttribute(XMLUtils.XSI_SchemaLocation, schLocnStr, XMLUtils.XSI_Namespace);
        }
        }
    }

    /**
      * Check a folder for associated control schema files  for the imsmanifest.xml 
      * @param file
      * @return true or false based on whether this document is editable
      */
     public boolean checkFolder(File file) {
         try {
         if (file.getName().endsWith("imsmanifest.xml")) { //$NON-NLS-1$
            
                Document manifestDoc = XMLUtils.readXMLFile(file);
                return checkDocument(file, manifestDoc);
                
         }else if(file.getName().toLowerCase().endsWith(".zip")){ //$NON-NLS-1$
            String manifest = ZipUtils.extractZipEntry(file, CP_Core.MANIFEST_NAME);
	        if(manifest != null) {
	             Document manifestdoc = XMLUtils.readXMLString(manifest);
	             //The first thing we do is to see if there is a root Namespace in the Document
	     		Namespace nameSpace = XMLUtils.getDocumentNamespace(manifestdoc);
	     		
	     		// No Namespace, sorry we don't know what it is!
	     		if(nameSpace == null || nameSpace.equals(Namespace.NO_NAMESPACE)) {
	     		    return false;
	     		}
	     		
	     		// Now find out if it is a SCORM Document. If so, say No!
	     		if(getSCORM_Namespace(manifestdoc) != null) {
	     		    return false;
	     		}
	     		
	             //TODO
	             return true;
	        }
            return false;
            //throw new IOException(Messages.getString("uk.ac.reload.editor.contentpackaging.CP_EditorHandler.6")); //$NON-NLS-1$
        }else {
            return false;
        }
        } catch (Exception e) {
            //e.printStackTrace();
            return false;
        }
    }
     
     
     /**
      * Creates a editor frame for localised content 
      * @param file
      * @return EditorInternalFrames
      */
     public EditorInternalFrame getEditorFrame(File file) throws IOException,
            JDOMException, SchemaException {
        
         File schfile = null;
        
	    // Test if a zip file
	    if(file.getName().toLowerCase().endsWith(".zip")) { //$NON-NLS-1$
	        File manifest = unzipManifest(file);
	        if(manifest == null) {
	            return null;
	        }
            // reference the imsmanifest.xml
            file = manifest;
	    }
        
        
        try {
            Document manifestDoc = XMLUtils.readXMLFile(file);

            // The first thing we do is to see if there is a root Namespace
            // in the Document
            Namespace nsCP = XMLUtils.getDocumentNamespace(manifestDoc);
            Namespace nsMD = manifestDoc.getRootElement().getNamespace("imsmd"); //$NON-NLS-1$
            Namespace nsLD = manifestDoc.getRootElement().getNamespace("imsld"); //$NON-NLS-1$
            
            // Get version from Namespace
            String cpschLocn = XMLUtils.getSchemaLocation(manifestDoc, nsCP);
           
            File schemaFolder = file.getParentFile();
            
            GenCPSchemaController cpController = null;
            
            if ((cpschLocn != null) && !("".equals(cpschLocn))) { //$NON-NLS-1$
                if(!cpschLocn.startsWith("http")){   //$NON-NLS-1$
                    schfile = new File(schemaFolder, cpschLocn);
                    GenCPSchemaController.setSchemaFile(schfile);
                    cpController = new GenCPSchemaController();                         
                }else{
                    GenCPSchemaController.setSchemaURL(new URL(cpschLocn));
                    cpController = new GenCPSchemaController(
                            new URL(cpschLocn));
                }
            }
            // in case there is no schema set in the doc, assume we have a default controller
            if(cpController == null){
                schfile = CP114_SchemaController.fileSchemaCP1_1_4;
                GenCPSchemaController.setSchemaFile(schfile);
                cpController = new GenCPSchemaController();                        
                
            }
            
            //==========for retrieving extension schema locations for later use
            Attribute attr = manifestDoc.getRootElement().getAttribute(
                    XMLUtils.XSI_SchemaLocation, XMLUtils.XSI_Namespace);
            String schemaLocns = ""; //$NON-NLS-1$
            if (attr != null) {
                schemaLocns = attr.getValue();
            }

            //if schemas are mentioned in the location attribute, load them
            // so that we can use it later for updating menus
            //if (!(nsURI.equals(""))&&(schemaLocns.indexOf(nsURI) != -1)) {
            StringTokenizer parser = new StringTokenizer(schemaLocns);

            while (parser.hasMoreTokens()) {
                String nsURI = parser.nextToken();
                //skip those schema location values as they are taken care of
                // store rest in a table for later use
                if (nsURI.equals(nsCP.getURI())) {
                    parser.nextToken();
                } else if ((nsMD != null) && (nsURI.equals(nsMD.getURI()))) {
                    parser.nextToken();
                } else if ((nsLD != null) && (nsURI.equals(nsLD.getURI()))) {
                    parser.nextToken();
                } else {
                    schemaLocns = parser.nextToken();
                    if (schemaLocns.indexOf("http") == -1) { //$NON-NLS-1$
                        File schFile = new File(file.getParent(), schemaLocns);
                        if (schFile.exists() && schFile.isFile()) {
                            try {
                                SchemaModel newSM = new SchemaModel();
                                XSDSchema extSchema = newSM.loadSchema(schFile);
                                SchemaUtils.getExtURItoSchemaMap()
                                        				.put(nsURI, extSchema);                               
                                
                            } catch (IOException e) {
                                // TODO Auto-generated catch block
                                e.printStackTrace();
                            } catch (SchemaException e) {
                                // TODO Auto-generated catch block
                                e.printStackTrace();
                            }
                        }
                    }
                }
            }
                
           
            //=======================================retrieve schema locations============
            
            //TODO
            // this at the moment handles only 'imsmd' namespace            

            
            if ((nsMD != null)){
                String mdschLocn = XMLUtils
                        .getSchemaLocation(manifestDoc, nsMD);
                if (mdschLocn != null) {
                    
                    File mdschemaFile = new File(schemaFolder, mdschLocn);
                    if (mdschemaFile.exists()) {
                        GenContentPackage cp = new GenContentPackage(file,
                                manifestDoc, cpController);
                        GenMDSchemaController.setSchemaFile(mdschemaFile);
                        GenMDSchemaController mdController = new GenMDSchemaController();
                        cpController.setMD_SchemaController(mdController);
                       
                        /**
                         * The following is for profiled LD packages for telcert use
                         * this assumes that Containing LD elements invariably have some Metadata as well
                         * to get this far ! ?
                         */
                        
                        
              /*          if (nsLD != null) {
                            String ldschLocn = XMLUtils
                                    .getSchemaLocation(manifestDoc, nsLD);
                           
                            if (ldschLocn != null) {
                                File ldschemaFile = new File(schemaFolder, ldschLocn);
                                if (ldschemaFile.exists()) {
                                  // get the cp schema model and attach ld schema model
                                    SchemaModel cpsm = cpController.getSchemaModel();
                                    //SchemaModel ldsm =  new SchemaModel(ldschemaFile, "learning-design"); //$NON-NLS-1$
                                    cpsm.addImportedSchema(ldsm,"imsld"); //$NON-NLS-1$
                                    cpsm.attachSchemaElement(ldsm, "organizationsType", "learning-design"); //$NON-NLS-1$ //$NON-NLS-2$
                                    
                                    SchemaElement orgEl = cpsm.getRootElement().getChild("organizations");
                                    SchemaElement[] kids = orgEl.getChildren();
                                    for (int i = 0; i < kids.length; i++) {
                                        SchemaElement[] kids1 = kids[i].getChildren();
                                    }
                                    //cpsm.getRootElement().getChild("organizations").attachExtSchemaElement(ldsm.getSchema(), "learning-design");
                                    }
                            }
                        }*/
                        
                        
                        return new GenCPEditor(cp);
                    }
                }
            }
            
           GenContentPackage cp = new GenContentPackage(file, manifestDoc,
                    cpController);
          /*  Element root = cp.getDocument().getRootElement();
            cp.getDocument().setRootElement(root);*/
            return new GenCPEditor(cp);

        } catch (Exception e) {
            //e.printStackTrace();
            //System.out.println("can't OPEN this CP - as no schema file in the folder " + e.getMessage());
            //return null;
            throw new SchemaException(Messages.getString("GenContentEditorHandler.15") + "\n"+ e.getMessage()); //$NON-NLS-1$
           
            
        }

    }
     
     /**
      * 
      * @param file
      * @param manifestDoc
      * @return true or false  - whether this document is editable
      */
   
     private static boolean checkDocument(File file, Document manifestDoc) {
        // The first thing we do is to see if there is a root Namespace
        // in the Document
        Namespace nameSpace = XMLUtils.getDocumentNamespace(manifestDoc);

        // No Namespace, sorry we don't know what it is!
        if (nameSpace == null || nameSpace.equals(Namespace.NO_NAMESPACE)) {
            return false;
        }

        // Now find out if it is a SCORM Document. If so, say No!
        if (CP_EditorHandler.getSCORM_Namespace(manifestDoc) != null) {
            return false;
        }
        
       

        // Get version from Namespace
        String schLocn = XMLUtils.getSchemaLocation(manifestDoc, nameSpace);
        // TODO
        // if the schema location is not http location then only do the following:
        if (!schLocn.startsWith("http")) { // deal only locally available schema files //$NON-NLS-1$

            File schemaFolder = file.getParentFile();
            File schemaFile = new File(schemaFolder, schLocn);
            if (!schemaFile.exists()) {
                return false;
            }
            Namespace nsMD = manifestDoc.getRootElement().getNamespace(
                    "imsmd"); //$NON-NLS-1$
            if (nsMD != null) {
                String mdschLocn = XMLUtils.getSchemaLocation(manifestDoc,
                        nsMD);
                File mdschemaFile = new File(schemaFolder, mdschLocn);
                //File mdschemaFile = new File(schemaFolder, schLocn);
                if (!mdschemaFile.exists()) {
                    return false;
                }

            }
            
            // one last check for veryfying whether there is an LD stuff in this manifest
            Namespace nsLD = manifestDoc.getRootElement().getNamespace(
                    "imsld"); //$NON-NLS-1$
            if (nsLD != null) {
                String ldschLocn = XMLUtils.getSchemaLocation(manifestDoc,
                        nsLD);
                File ldschemaFile = new File(schemaFolder, ldschLocn);
                //File ldschemaFile = new File(schemaFolder, schLocn);
                if (!ldschemaFile.exists()) {
                    return false;
                }

            }

            return true;

        }
        //handle http based schema locations
        try {
            URL url = new URL(schLocn);

            HttpURLConnection conn = (HttpURLConnection) url
                    .openConnection();
            conn.connect();
            //System.out.println("The file : " + url.toString() + " not exists and can't be read");
            return conn.getResponseCode() == HttpURLConnection.HTTP_OK;

        } catch (MalformedURLException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return false;
    }

}