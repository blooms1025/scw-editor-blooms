/**
 *  RELOAD TOOLS
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Phillip Beauvoir
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Phillip Beauvoir
 *  e-mail:   p.beauvoir@bolton.ac.uk
 *
 *  Web:      http://www.reload.ac.uk
 *
 */
package uk.ac.reload.editor.gencontent.xml;

import java.io.File;
import java.io.IOException;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.Namespace;

import uk.ac.reload.editor.EditorHandler;
import uk.ac.reload.editor.Messages;
import uk.ac.reload.editor.contentpackaging.xml.CP_SchemaController;
import uk.ac.reload.editor.contentpackaging.xml.ContentPackage;
import uk.ac.reload.editor.learningdesign.LD_EditorHandler;
import uk.ac.reload.editor.metadata.MD_EditorHandler;
import uk.ac.reload.editor.metadata.xml.MD_SchemaController;
import uk.ac.reload.jdom.XMLUtils;
import uk.ac.reload.moonunit.contentpackaging.CP_Core;
import uk.ac.reload.moonunit.schema.SchemaElement;
import uk.ac.reload.moonunit.schema.SchemaException;
import uk.ac.reload.moonunit.schema.SchemaModel;

/**
 * Content package extended to handle ims cp localised content
 */
public class GenContentPackage extends ContentPackage {
    
    /**
     * 
     *
     */
    public GenContentPackage() {
        super();
    }
    
    protected void init(File projectFolder, CP_SchemaController cpController) {
        // TODO Auto-generated method stub
        //super.init(projectFolder, cpController);
       		setDocument(new Document());
    		
    		// Add our signature
    		addCommentsToDocument();
    		
    		// Content Packaging Schema
    		SchemaModel cpSchemaModel = cpController.getSchemaModel();
    		
    		// Set Root Element
    		Element root = addElementBySchema(this, null, cpSchemaModel.getRootElement(), false);
    		getDocument().setRootElement(root);
    		
    		// Metadata Schema
    		SchemaModel mdSchemaModel = cpController.getMD_SchemaController().getSchemaModel();
    		
    		// Add Metadata Namespace
    		Namespace mdNamespace = Namespace.getNamespace(MD_EditorHandler.IMSMD_NAMESPACE_PREFIX, mdSchemaModel.getTargetNamespaceURI());
    		root.addNamespaceDeclaration(mdNamespace);
    		
    		// Add XSI Schema Instance Namespace
    		root.addNamespaceDeclaration(XMLUtils.XSI_Namespace);
    		
    		// Add Schema Location Attribute which is constructed from Target Namespace
    		// and file name of Schema, and also with Metadata Schema location
    		StringBuffer schemaLocationURI = new StringBuffer();
    		schemaLocationURI.append(cpSchemaModel.getTargetNamespaceURI());
    		schemaLocationURI.append(" "); //$NON-NLS-1$
    		schemaLocationURI.append(cpSchemaModel.getSchemaName());
    	
    		schemaLocationURI.append(" "); //$NON-NLS-1$
    		schemaLocationURI.append(mdSchemaModel.getTargetNamespaceURI());
    		schemaLocationURI.append(" "); //$NON-NLS-1$
    		if((cpController instanceof GenCPSchemaController) && 
    		        !(GenCPSchemaController.getMdSchemaFileName().equals(""))){ //$NON-NLS-1$
    		    schemaLocationURI.append(GenCPSchemaController.getMdSchemaFileName());
    		}else{
    		    schemaLocationURI.append(mdSchemaModel.getSchemaName());
    		}
    		
    		//root.setAttribute(XMLUtils.XSI_SchemaLocation, schemaLocationURI.toString(), XMLUtils.XSI_Namespace);
    		
    	
        // the following is to add ld schema to the cp
        if(GenCPSchemaController.getLdSchemaFile() != null){
           
            //ld Schema
    		SchemaModel ldSchema = ((GenCPSchemaController)cpController).getLdsm();
    		// Add ld Namespace
    		Namespace ldNamespace = Namespace.getNamespace(LD_EditorHandler.IMSLD_NAMESPACE_PREFIX, ldSchema.getTargetNamespaceURI());
    		
    		root.addNamespaceDeclaration(ldNamespace);
    		
    		schemaLocationURI.append(" "); //$NON-NLS-1$
    		schemaLocationURI.append(ldSchema.getTargetNamespaceURI());
    		schemaLocationURI.append(" "); //$NON-NLS-1$
    		if((cpController instanceof GenCPSchemaController) && 
    		        !(GenCPSchemaController.getLdSchemaFileName().equals(""))){ //$NON-NLS-1$
    		    schemaLocationURI.append(GenCPSchemaController.getLdSchemaFileName());
    		}else{
    		    schemaLocationURI.append(ldSchema.getSchemaName());
    		}
    		
    		
        }
    		root.setAttribute(XMLUtils.XSI_SchemaLocation, schemaLocationURI.toString(), XMLUtils.XSI_Namespace);
    		
    		
        //}
        
    	// Set as File
		setFile(new File(projectFolder, CP_Core.MANIFEST_NAME));

       
    }
    /**
     * c'str for blank document
     * @param projectFolder
     * @param cpController
     * @param mdController
     * @throws IOException
     */
    public GenContentPackage(File projectFolder,
            CP_SchemaController cpController, MD_SchemaController mdController)
    throws IOException {       
        super(projectFolder, cpController, mdController);
    }
    
    /**
     * Constructor for existing document
     * @param file
     * @throws JDOMException
     * @throws SchemaException
     * @throws IOException
     */
    public GenContentPackage(File file, Document manifest,
            GenCPSchemaController cpController) throws JDOMException,
            SchemaException, IOException {

        if (file == null) {
            throw new NullPointerException(
                    Messages.getString("GenContentPackage.2")); //$NON-NLS-1$
        }

        setFile(file);

        // Load the Document
        setDocument(manifest);

        setSchemaController(cpController);

        // Ascertain MD Controller
        // If not found in root element, don't set global one because the
        // Namespace might be declared in-line
        Namespace nsMD = getDocument().getRootElement().getNamespace("imsmd"); //$NON-NLS-1$
        if (nsMD != null) {
            String version = EditorHandler.MD_EDITORHANDLER.getVersion(nsMD);
            if (version != null) {
                MD_SchemaController mdController = (MD_SchemaController) EditorHandler.MD_EDITORHANDLER
                        .getSchemaControllerInstance(version);
                cpController.setMD_SchemaController(mdController);
            }
        }
    }
    
    /**
     * add a child element to parent element according to schema
     * set the default attributes to new element if any 
     * @param source  source of this request
     * @param parentElement  element to which new child element is added
     * @param newSchemaElement schema element for the child element
     * @param doSelect select/not select the newly created element in view
     */

    public Element addElementBySchema(Object source, Element parentElement,
            SchemaElement newSchemaElement, boolean doSelect) {
        Element newElement = null;
        if((newSchemaElement != null)&&(parentElement != null)){
            if(!super.canAddElement(parentElement, newSchemaElement))
                return null;
        }
        
        newElement = super.addElementBySchema(source, parentElement,
                newSchemaElement, doSelect);

 /*if ((newSchemaElement != null)
                && (newSchemaElement.hasSchemaAttributes())) {
            SchemaAttribute[] atts = newSchemaElement.getSchemaAttributes();
            for (int i = 0; i < atts.length; i++) {
                VocabularyList vList = atts[i].getVocabularyList();
                if (vList != null) {
                    String[] strs = vList.getList();
                    newElement.setAttribute(atts[i].getName(), strs[0]);
                }
            }
        }

        // Need to do this to update Tree
        fireElementChanged(new XMLDocumentListenerEvent(source, this,
                newElement, false));*/

        return newElement;
    }
   
    
}


