/**
 *  RELOAD TOOLS
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Phillip Beauvoir
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Phillip Beauvoir
 *  e-mail:   p.beauvoir@bolton.ac.uk
 *
 *  Web:      http://www.reload.ac.uk
 *
 */
package uk.ac.reload.editor.gencontent.xml;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.net.URL;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;

import uk.ac.reload.diva.util.FileUtils;
import uk.ac.reload.editor.Messages;
import uk.ac.reload.editor.contentpackaging.xml.CP_SchemaController;
import uk.ac.reload.editor.metadata.xml.MD124_SchemaController;
import uk.ac.reload.editor.metadata.xml.MD_SchemaController;
import uk.ac.reload.jdom.XMLUtils;
import uk.ac.reload.moonunit.schema.SchemaException;
import uk.ac.reload.moonunit.schema.SchemaModel;
import uk.ac.reload.moonunit.schema.utils.SchemaUtils;

/**
 * Schema Controller for modified(localised) IMS content package schema  
 */
public class GenCPSchemaController extends CP_SchemaController {
    
    private String root = "manifest"; //$NON-NLS-1$
    private String version;
    private static URL schemaUrl = null;
    
    //	Schema file
    private static File schemaFile;
    private static String cpSchemaFileName=""; //$NON-NLS-1$
    private static String mdSchemaFileName=""; //$NON-NLS-1$
    private static String ldSchemaFileName=""; //$NON-NLS-1$
    // Folder containing schema/support files
    private static File schemaFolder;
    private static Document configDoc;
    
    private static File mdSchemaFile;
    
    // could we use it for editing profile ld packages ?
    private static File ldSchemaFile;
    private SchemaModel ldsm;
    
    private static boolean schemaFileSet = false;
    public static String extSchemaLocns;
    
   
 
    
    /**
     * @param file File handle of schema
     * @throws JDOMException
     * @throws SchemaException
     * @throws IOException
     *//*
    public GenCPSchemaController(File file) throws JDOMException, SchemaException,
    IOException {
        super();
        loadSchemaModel(root);
    }*/
    
   /* *//**
     * @param schemaPath path to schema
     * @throws JDOMException
     * @throws SchemaException
     * @throws IOException
     *//*
    public GenCPSchemaController(String schemaPath) throws JDOMException, SchemaException,
    IOException {
       loadSchemaModel(root);
    }
    */
    
    /**
     * Constructor for loading the controller After setting the schema File 
     * @throws JDOMException
     * @throws SchemaException
     * @throws IOException
     */
    public GenCPSchemaController() throws JDOMException, SchemaException,
    IOException {
       loadSchemaModel(root);
    }
    
    /**
     * c'str
     * @param url URl of the schema
     * @throws SchemaException
     * @throws IOException
     * @throws JDOMException
     */
    
    public GenCPSchemaController(URL url) throws JDOMException, SchemaException, IOException {
        super();
        schemaUrl = url;
        SchemaModel sm = new SchemaModel(url, root);
        version = SchemaModel.getCurrentVerison();
        setSchemaModel(sm);
        
    }
    
    
    /**
     * Load in the SchemaModel as determined by getSchemaFile() and getRootElementName().
     * If the SchemaModel has already been set and loaded, nothing happens.
     * @throws SchemaException
     * @throws IOException
     */
    public void loadSchemaModel(String root) throws SchemaException, IOException {
        // a temporary work around until version issue is resolved - now pass some string..
        if(version == null){
        SchemaModel sm = new SchemaModel(getSchemaFile(), root);
        version = SchemaModel.getCurrentVerison();
        
        if(ldSchemaFile != null){
            ldsm = new SchemaModel(ldSchemaFile, "learning-design"); //$NON-NLS-1$
            sm.getRootElement().getChild("organizations")
            	.attachExtSchemaElement(ldsm.getSchema(), "learning-design");
           
            // removed on 08/03/2006
            //sm.addImportedSchema(ldsm,"imsld"); //$NON-NLS-1$
            //sm.attachSchemaElement(ldsm, "organizationsType", "learning-design"); //$NON-NLS-1$ //$NON-NLS-2$
            
        }
        setSchemaModel(sm);
        }
        
    }
    
  /*  *//**
     * 
     *//*
    
    public void loadSchemaModel(){
        
        if(getSchemaModel() == null) {
            try {
            if(schemaUrl !=null){
                SchemaModel sm;
               
                    sm = new SchemaModel(schemaUrl, "manifest");
               
                version = SchemaModel.getCurrentVerison();
                setSchemaModel(sm);   
            }else{
            // Get cached version
            SchemaModel sm = SchemaModel.getSchemaModel(getVersion(), getSchemaFile(), getRootElementName());
            }
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (SchemaException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }*/
    /**
     * 
     */
    public MD_SchemaController getDefaultMD_SchemaController()
    throws JDOMException, IOException, SchemaException {
        return new MD124_SchemaController();
    }
    
	/**
	 * Set the MD_SchemaController
	 * @param mdController
	 */
	public void setMD_SchemaController(GenMDSchemaController mdController) {
        //_mdController = mdController;
	    super.setMD_SchemaController(mdController);
	}
    /**
     * 
     */
    public String getVersion() {
        if((version != null) && !("".equals(version))) //$NON-NLS-1$
            return version;
        else
        return schemaFile.getAbsolutePath();
    }
    
    
    /**
     * Copy the Schema Files to the Project Folder
     */
    public void copySchemaFilesToFolder(File projectFolder) throws IOException {
        // this was added to copy default Md schema in case none is specified
        super.copySchemaFilesToFolder(projectFolder);        
        boolean success = true;
        if (configDoc.getRootElement().getChildren("supportFile").size() == 0) { //$NON-NLS-1$
            // the following for copying all the .xsd files in the source folder
            // to CP target folder
            File[] xsdFiles = schemaFolder.listFiles(new FilenameFilter() {
                public boolean accept(File dir, String name) {
                    return name.endsWith(".xsd"); //$NON-NLS-1$
                }
            });
            for (int i = 0; i < xsdFiles.length; i++) {
                String destFileName = projectFolder.getAbsolutePath()
                        + File.separator + xsdFiles[i].getName();
                FileUtils.copyFile(xsdFiles[i], new File(destFileName));
            }
            // now this is for copying Metadata schema in case it is standard
            // IMS one

            if (!(getMD_SchemaController() instanceof GenMDSchemaController)) {

                super.copySchemaFilesToFolder(projectFolder);
            }

        } else {
            //now this is for all the user specified xsd to be copied over
            Iterator fileNameItr = configDoc.getRootElement().getChildren(
                    "supportFile").iterator(); //$NON-NLS-1$
            while (fileNameItr.hasNext()) {
                String srcFileName = ((Element) fileNameItr.next()).getText();
                String srcFileAbs = srcFileName;
                // TO DO need some check here to verify the path specified is
                // absolute ?
                String destDir = projectFolder.getAbsolutePath();
                if (srcFileName.indexOf("/") != -1) { //$NON-NLS-1$
                    String srcDirectory = srcFileName.substring(0, srcFileName
                            .lastIndexOf("/")); //$NON-NLS-1$
                    srcFileAbs = srcFileName.substring(srcFileName
                            .lastIndexOf("/") + 1); //$NON-NLS-1$
                    destDir = projectFolder.getAbsolutePath() + File.separator
                            + srcDirectory;
                    success = (new File(destDir)).mkdirs();
                    if (!success) {
                        System.err.println(" Unable to create directories /: " //$NON-NLS-1$
                                + destDir);
                    }
                }else if (srcFileName.indexOf("\\") != -1) { //$NON-NLS-1$
                    String srcDirectory = srcFileName.substring(0, srcFileName
                            .lastIndexOf("\\")); //$NON-NLS-1$
                    srcFileAbs = srcFileName.substring(srcFileName
                            .lastIndexOf("\\") + 1); //$NON-NLS-1$
                    System.out.println(" file seperator was there in this: " //$NON-NLS-1$
                            + srcDirectory);
                    destDir = projectFolder.getAbsolutePath() + File.separator
                            + srcDirectory;
                    success = (new File(destDir)).mkdirs();
                    if (!success) {
                        System.err
                                .println(" Unable to create directories in : " //$NON-NLS-1$
                                        + destDir);
                    }

                }

                String destFileName = destDir + File.separator + srcFileAbs;
                srcFileName = schemaFolder.getAbsolutePath() + File.separator
                        + srcFileName;
                File srcFile = new File(srcFileName);
                if (srcFile.exists() && success) {
                    FileUtils.copyFile(new File(srcFileName), new File(
                            destFileName));
                } else {
                    System.err.println(" source file could not be copied " //$NON-NLS-1$
                            + destFileName);
                }
            }

        }
    }
    
 /*   *//**
     * Copy the Schema Files to the Project Folder
     *//*
    public void copySchemaFilesToFolder(File projectFolder) throws IOException {
        boolean success = true;
        if (configDoc.getRootElement().getChildren("supportFile").size() > 0) {
            Iterator fileNameItr = configDoc.getRootElement().getChildren(
                    "supportFile").iterator();
            while (fileNameItr.hasNext()) {
                String srcFileName = ((Element) fileNameItr.next()).getText();
                String srcFileAbs = srcFileName;
                // TO DO need some check here to verify the path specified is
                // absolute ?
                String destDir = projectFolder.getAbsolutePath();
                if (srcFileName.indexOf("/") != -1){
                    String srcDirectory = srcFileName.substring(0, srcFileName
                            .lastIndexOf("/"));
                    srcFileAbs = srcFileName.substring(srcFileName
                            .lastIndexOf("/") + 1);
                    destDir = projectFolder.getAbsolutePath() + File.separator
                            + srcDirectory;
                    success = (new File(destDir)).mkdirs();
                    if (!success) {
                        System.err.println(" Unable to create directories /: "
                                + destDir);
                    }
                } else if (srcFileName.indexOf("\\") != -1){
                    String srcDirectory = srcFileName.substring(0, srcFileName
                            .lastIndexOf("\\"));
                    srcFileAbs = srcFileName.substring(srcFileName
                            .lastIndexOf("\\") + 1);
                    System.out.println(" file seperator was there in this: "
                            + srcDirectory);
                    destDir = projectFolder.getAbsolutePath() + File.separator
                            + srcDirectory;
                    success = (new File(destDir)).mkdirs();
                    if (!success) {
                        System.err
                                .println(" Unable to create directories in //: "
                                        + destDir);
                    }
                
                String destFileName = destDir + File.separator + srcFileAbs;
                srcFileName = schemaFolder.getAbsolutePath() + File.separator
                        + srcFileName;
                File srcFile = new File(srcFileName);
                if (srcFile.exists() && success) {
                    FileUtils.copyFile(new File(srcFileName), new File(
                            destFileName));
                } else {
                    System.err.println(" source file could not be copied "
                            + destFileName);
                }
                }
            }            
            }else {

            // the following for copying all the .xsd files in the source folder
            // to CP target folder
            File[] xsdFiles = schemaFolder.listFiles(new FilenameFilter() {
                public boolean accept(File dir, String name) {
                    return name.endsWith(".xsd");
                }
            });
            for (int i = 0; i < xsdFiles.length; i++) {
                String destFileName = projectFolder.getAbsolutePath()
                        + File.separator + xsdFiles[i].getName();
                FileUtils.copyFile(xsdFiles[i], new File(destFileName));
            }
            // now this is for copying Metadata schema in case it is standard
            // IMS one

            if (!(getMD_SchemaController() instanceof GenMDSchemaController)) {

                super.copySchemaFilesToFolder(projectFolder);
            }
        }

    }*/
    
    /**
     * 
     */
    public File getSchemaFile() {
        return schemaFile;
    }
    /**
     * Set the schema file - loads the configuration file at the spec location
     * extracts the schema file name from config file
     * @param path
     * @throws JDOMException
     * @throws IOException
     */
    
    public static void setSchemaFiles(String path) throws IOException, JDOMException{
        schemaFolder = new File(path);
        String configFileName = schemaFolder.getAbsolutePath() + File.separator + "config.xml"; //$NON-NLS-1$
        File configFile = new File(configFileName);
        extSchemaLocns=""; //$NON-NLS-1$
        if(!configFile.exists()){
            throw new IOException(Messages.getString("GenCPSchemaController.0")); //$NON-NLS-1$
        }
     
            configDoc = XMLUtils.readXMLFile(configFile);
            //if(configDoc.getRootElement().getChild("cpSchema") == null){
            if((configDoc == null) || ( !validateConfigDoc(configDoc))){
                throw new JDOMException(Messages.getString("GenCPSchemaController.1")); //$NON-NLS-1$
            }
            schemaFile = new File(schemaFolder, configDoc.getRootElement().getChild("cpSchema").getText()); //$NON-NLS-1$
            cpSchemaFileName = configDoc.getRootElement().getChild("cpSchema").getText(); //$NON-NLS-1$
            // now try to load a modified schema controller if specified
            if(configDoc.getRootElement().getChild("mdSchema") != null){ //$NON-NLS-1$
                File mdfile = new File(schemaFolder, configDoc.getRootElement().getChild("mdSchema").getText()); //$NON-NLS-1$
                if(mdfile.exists() && !mdfile.isDirectory()){
                   mdSchemaFile = mdfile;
                   mdSchemaFileName = configDoc.getRootElement().getChild("mdSchema").getText(); //$NON-NLS-1$
                }else{
                    mdSchemaFile = null;
                    mdSchemaFileName=""; //$NON-NLS-1$
                }
            }else{
                //System.out.println("MD Schema file is not specified in this config file");
                mdSchemaFile = null;
            }
            
            
            // now try to load a modified schema controller if specified
            if(configDoc.getRootElement().getChild("ldSchema") != null){ //$NON-NLS-1$
                File ldfile = new File(schemaFolder, configDoc.getRootElement().getChild("ldSchema").getText()); //$NON-NLS-1$
                if(ldfile.exists() && !ldfile.isDirectory()){
                   ldSchemaFile = ldfile;
                   ldSchemaFileName = configDoc.getRootElement().getChild("ldSchema").getText(); //$NON-NLS-1$
                }else{
                    ldSchemaFile = null;
                    ldSchemaFileName = ""; //$NON-NLS-1$
                }
            }else{
                //System.out.println("MD Schema file is not specified in this config file");
                ldSchemaFile = null;
            }
            
            
            //==================================
            // if there are sub schemas for extension types 
            List extensions = configDoc.getRootElement().getChildren("extensionFile"); //$NON-NLS-1$
            
            if (extensions.size() > 0) {
                //System.out.println("Found extension types");
                Hashtable uri2SchemaTbl = new Hashtable();
                Hashtable uri2PrefxTbl = new Hashtable();
                Hashtable uri2RootTbl = new Hashtable();
                StringBuffer sb = new StringBuffer(""); //$NON-NLS-1$
                for (Iterator iter = extensions.iterator(); iter.hasNext();) {
                    Element element = (Element) iter.next();
                    String extFileName = element
                            .getChildTextTrim("filename"); //$NON-NLS-1$
                    String nsPrefix = element.getChildTextTrim("prefix"); //$NON-NLS-1$
                    String nsURI = element.getChildTextTrim("nsURI"); //$NON-NLS-1$
                    String rootElName = element.getChildTextTrim("rootElement"); //$NON-NLS-1$
                    File extSchemaFile = new File(configFile.getParent(), extFileName);
                    
                    if (!("".equals(extFileName) ||"".equals(nsPrefix) || "".equals(nsURI) || "".equals(rootElName))&& (extSchemaFile.exists())) { //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
                        //System.out.println("Adding extension types schemas " + extFileName);
                       
                        SchemaModel sm = null;
                        try {
                            sm = new SchemaModel(extSchemaFile, rootElName);
                        } catch (IOException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        } catch (SchemaException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                        if (sm != null) {
                            uri2SchemaTbl.put(nsURI, sm.get_xsdSchema());
                            //System.out.println(" adding extension schemas to hash table inner loop " + nsURI);
                            uri2PrefxTbl.put(nsURI, nsPrefix);
                            uri2PrefxTbl.put(nsURI, rootElName);
                            sb.append(nsURI);
                            sb.append(" "); //$NON-NLS-1$
                            sb.append(extFileName);
                            sb.append(" "); //$NON-NLS-1$
                           
                        }
                    }
                }
                //TODO
                extSchemaLocns = sb.toString();
                //System.out.println(" adding extension schemas to hash table - size " + smTbl.size());  
                SchemaUtils.getExtURItoSchemaMap().putAll(uri2SchemaTbl);
                SchemaUtils.getExtURItoPrefxMap().putAll(uri2PrefxTbl);
                SchemaUtils.getExtURItoRootMap().putAll(uri2RootTbl);
                uri2SchemaTbl.clear();
                uri2PrefxTbl.clear();
                uri2RootTbl.clear();
                uri2PrefxTbl = null;
                uri2SchemaTbl = null;
                uri2RootTbl = null;
            }
            
            
           //=================================
            
            
            //return true;
    }
    
    /**
     * @param file
     */
    
    
    public static void setSchemaFile(File file){
        schemaFile = file;        
    }
    
    public static Document getConfigDoc() {
        return configDoc;
    }
    /**
     * @return Returns the mdSchemaFile.
     */
    public static File getMdSchemaFile() {
        return mdSchemaFile;
    }
    
    /**
     * @return Returns the ldSchemaFile.
     */
    public static File getLdSchemaFile() {
        return ldSchemaFile;
    }
    /**
     * Check whether the config.xml file is in order
     * format : <config>
		<type>ContentPackage</type>
		<cpSchema>imscp_v1p1p3_localised.xsd</cpSchema>
		<mdSchema>imsmd_v1p2p2_localised.xsd</mdSchema>
		</config>
     * @param configDoc
     * @return true or false
     */
    
    public static boolean validateConfigDoc(Document configDoc){
        boolean result = true;
        if((configDoc.getRootElement().getChild("type") == null)||  //$NON-NLS-1$
                (!configDoc.getRootElement().getChild("type").getTextTrim().equals("ContentPackage"))) //$NON-NLS-1$ //$NON-NLS-2$
            return false;
        if((configDoc.getRootElement().getChild("cpSchema") == null)||  //$NON-NLS-1$
                (configDoc.getRootElement().getChild("cpSchema").getTextTrim().equals(""))) //$NON-NLS-1$ //$NON-NLS-2$
            return false;
        if((configDoc.getRootElement().getChild("mdSchema") != null)&&  //$NON-NLS-1$
                (configDoc.getRootElement().getChild("mdSchema").getTextTrim().equals(""))) //$NON-NLS-1$ //$NON-NLS-2$
            return false;
        if((configDoc.getRootElement().getChild("ldSchema") != null)&&  //$NON-NLS-1$
                (configDoc.getRootElement().getChild("ldSchema").getTextTrim().equals(""))) //$NON-NLS-1$ //$NON-NLS-2$
            return false;
        return result;
    }
    
    /**
     * return the learning design schemamodel if any
     * @return learning design schema model
     */
    public SchemaModel getLdsm() {
        return ldsm;
    }

    /**
     * @param schLocn
     */
    public static void setSchemaURL(URL schLocn) {
        // TODO Auto-generated method stub
        schemaUrl = schLocn;
    }
    public static String getCpSchemaFileName() {
        return cpSchemaFileName;
    }
    public static String getLdSchemaFileName() {
        return ldSchemaFileName;
    }
    public static String getMdSchemaFileName() {
        return mdSchemaFileName;
    }
}
