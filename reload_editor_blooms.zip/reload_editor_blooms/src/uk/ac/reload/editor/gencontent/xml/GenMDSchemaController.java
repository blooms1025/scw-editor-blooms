/**
 *  RELOAD TOOLS
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Phillip Beauvoir
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Phillip Beauvoir
 *  e-mail:   p.beauvoir@bolton.ac.uk
 *
 *  Web:      http://www.reload.ac.uk
 *
 */
package uk.ac.reload.editor.gencontent.xml;

import java.io.File;
import java.io.IOException;

import org.jdom.JDOMException;

import uk.ac.reload.editor.metadata.xml.MD_SchemaController;
import uk.ac.reload.moonunit.schema.SchemaException;
import uk.ac.reload.moonunit.schema.SchemaModel;


/**
 * TO DO 
 * Schema Controller for modified(localised) IMS Metadata schema  
 */
public class GenMDSchemaController extends MD_SchemaController {
    private String root;
    private String version;
    //	Schema file
    static File schemaFile;
    
    
    /**
     * Default Constructor
     * @throws JDOMException
     * @throws IOException
     * @throws SchemaException
     */
    public GenMDSchemaController() throws JDOMException, SchemaException, IOException {
        root = "lom"; //$NON-NLS-1$
        loadSchemaModel(root);
    }
    
    /**
     * 
     * @param schemaFile
     * @throws JDOMException
     * @throws SchemaException
     * @throws IOException
     */
    public GenMDSchemaController(File schFile, String rootName) throws JDOMException, SchemaException, IOException {
        root = rootName; //$NON-NLS-1$
        schemaFile = schFile;
        loadSchemaModel(root);
    }
    
    /**
     * Load in the SchemaModel as determined by getSchemaFile() and getRootElementName().
     * If the SchemaModel has already been set and loaded, nothing happens.
     * @throws SchemaException
     * @throws IOException
     */
    public void loadSchemaModel(String root) throws SchemaException, IOException {
        // a temporary work around until version issue is resolved - now pass some string..
        if(version == null){
        SchemaModel sm = new SchemaModel(getSchemaFile(), root);
        version = SchemaModel.getCurrentVerison();
        setSchemaModel(sm);
        //System.out.println("Loading schema model from Generic md schema first time ");
        }/*else{
            System.out.println("Loading schema model from Generic md schema Vesion is " + version);
        }*/
        //setSchemaModel(SchemaModel.getSchemaModel(getSchemaFile().getAbsolutePath(), getSchemaFile(), root));
        //_schemaModel = SchemaModel.getSchemaModel(getSchemaFile().getAbsolutePath(), getSchemaFile(), root);
        //System.out.println("Loading schema model from Generic md schema ");
    }
    
    /**
     * @return The Root Element name
     */
    public String getRootElementName() {
        return "lom"; //$NON-NLS-1$
    }
    
    public String getVersion() {
        if((version != null) && !("".equals(version))) //$NON-NLS-1$
            return version;
        else
        return schemaFile.getAbsolutePath();
      
    }
    
    /* (non-Javadoc)
     * @see uk.ac.reload.moonunit.handler.SchemaController#getSchemaFile()
     */
    public File getSchemaFile() {
        return schemaFile;
    }
    
    /**
     * 
     * @param file
     */
    
    
    public static void setSchemaFile(File file){        
        schemaFile = file;
    }
    
}
