/**
 *  Content Re-Engineerng Tool
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Roy P Cherian
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Roy P Cherian
 *  e-mail:   rc3@bolton.ac.uk
 *
 *
 */
package uk.ac.reload.editor.gencontent.editor;

import java.io.File;
import java.io.IOException;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.Namespace;

import uk.ac.reload.dweezil.gui.DweezilFileChooser;
import uk.ac.reload.dweezil.gui.DweezilFileFilter;
import uk.ac.reload.dweezil.gui.ErrorDialogBox;
import uk.ac.reload.editor.EditorHandler;
import uk.ac.reload.editor.Messages;
import uk.ac.reload.editor.contentpackaging.xml.CP_SchemaController;
import uk.ac.reload.editor.contentpackaging.xml.ContentPackage;
import uk.ac.reload.editor.gencontent.xml.GenCPSchemaController;
import uk.ac.reload.editor.genschema.GenMetadata;
import uk.ac.reload.editor.metadata.editor.MD_EditorDialog;
import uk.ac.reload.editor.metadata.xml.MD_SchemaController;
import uk.ac.reload.editor.metadata.xml.Metadata;
import uk.ac.reload.jdom.XMLUtils;
import uk.ac.reload.moonunit.schema.SchemaException;

public class GenCPMDEditorDialog extends MD_EditorDialog {

    public GenCPMDEditorDialog(ContentPackage contentPackage, Element mdElement)
            throws JDOMException, IOException, SchemaException {
        super(contentPackage, mdElement);
        // TODO Auto-generated constructor stub
    }

    @Override
    protected void createMetadataDocument(ContentPackage cp, Element mdElement)
            throws JDOMException, IOException, SchemaException {
        // TODO Auto-generated method stub
        // Firstly, we have to find the "lom" element with a MD Namespace
        _existingLomElement = cp.getMetadataLomElement(mdElement);

        // Yes, we got the "lom" Element - so edit a clone of the "lom" element
        if (_existingLomElement != null) {
            Metadata md = null;
            // Create a new JDOM Document cloned from the existing "lom" element
            Document doc = new Document();
            doc.setRootElement((Element) _existingLomElement.clone());

            Namespace ns = XMLUtils.getDocumentNamespace(doc);
            Document cpDocument = cp.getDocument();

            String mdSchemaPath = cp.getFile().getParent() + File.separator
                    + XMLUtils.getSchemaLocation(cpDocument, ns);

            //if ((ns.getURI().indexOf("localised") != -1)
            //        || (mdSchemaPath.indexOf("localised") != -1)) {
                md = new GenMetadata(doc, mdSchemaPath);
            //} 
            _mdEditorPanel.setDocument(md);
        } else {

               MD_SchemaController mdController = ((GenCPSchemaController) cp
                    .getSchemaController()).getMD_SchemaController();

            // No root Namespace, so use default Controller
            if (mdController == null) {
                mdController = ((CP_SchemaController) cp.getSchemaController())
                        .getDefaultMD_SchemaController();

            }

            // Edit a new document
            Metadata md = new Metadata(false, mdController);
            _mdEditorPanel.setDocument(md);
        }

        // Tell Undo Manager we got the Focus - this wakes it up
        _mdEditorPanel.getUndoManager().setFocusGained();
    }

    @Override
    protected void exportMetadata() {
        // TODO Auto-generated method stub
        try {
            // Ask for the File Name
            DweezilFileFilter filter = new DweezilFileFilter(
                    new String[] { "xml" }, "xml files"); //$NON-NLS-1$ //$NON-NLS-2$
            File file = DweezilFileChooser
                    .askFileNameSave(
                            this,
                            Messages
                                    .getString("uk.ac.reload.editor.metadata.MD_EditorDialog.9"), filter, "xml"); //$NON-NLS-1$ //$NON-NLS-2$
            if (file != null) {
                Metadata md = _mdEditorPanel.getMetadata()
                        .createStandaloneMetadata();
                md.saveAsDocument(file);
                
                //System.out.println(XMLUtils.write2XMLString(md.getDocument()));
            }
        } catch (IOException ex) {
            ErrorDialogBox
                    .showWarning(
                            Messages
                                    .getString("uk.ac.reload.editor.metadata.MD_EditorDialog.10"), //$NON-NLS-1$
                            Messages
                                    .getString("uk.ac.reload.editor.metadata.MD_EditorDialog.11"), //$NON-NLS-1$
                            ex);
        }
    }

    @Override
    protected void importMetadata() throws JDOMException, SchemaException,
            IOException {
        // TODO Auto-generated method stub
        // Get the chosen File
        DweezilFileFilter filter = new DweezilFileFilter(
                new String[] { "xml" }, "xml files"); //$NON-NLS-1$ //$NON-NLS-2$
        File file = DweezilFileChooser
                .askFileNameOpen(
                        this,
                        Messages
                                .getString("uk.ac.reload.editor.metadata.MD_EditorDialog.7"), filter); //$NON-NLS-1$

        // Changed by Roy
        GenMetadata md = null;
        if (file != null) {
            // Let's see what it is
            // It has to be a Metadata Document we support

            if (!EditorHandler.MD_EDITORHANDLER.canEditFile(file)) {
                // Added for telcert Roy
                md = new GenMetadata(file);
                if (md == null) {
                    throw new IOException(
                            Messages
                                    .getString("uk.ac.reload.editor.metadata.MD_EditorDialog.8")); //$NON-NLS-1$
                }
            } else {
                // Get a new Metadata instance
                md = new GenMetadata(file);
            }

            // Added by Roy
            if (md == null)
                throw new IOException(
                        Messages
                                .getString("uk.ac.reload.editor.metadata.MD_EditorDialog.8")); //$NON-NLS-1$
            // Create embedded version

            md = md.createEmbeddedMetadata();
            
            System.out.println(XMLUtils.write2XMLString(md.getDocument()));            
            md.setDirty(true);
            _mdEditorPanel.setDocument(md);

            // Tell Undo Manager we got the Focus
            _mdEditorPanel.getUndoManager().setFocusGained();
        }
    }
    
    @Override
    protected void finish() {
        // TODO Auto-generated method stub
        // Get the Metadata from the Editor
        Metadata md = _mdEditorPanel.getMetadata();

        // If user edited the MD
        if (md.isDirty()) {
            // If we had an old node, remove it
            if (_existingLomElement != null) {
                _mdElement.removeContent(_existingLomElement);
            }

            // Created embedded version (add prefixes)
            Metadata md2 = md.createEmbeddedMetadata();

            // Get root element from MD Document
            Element newRoot = md2.getRootElement();
            newRoot.detach();

            // Attach it
            _mdElement.addContent(newRoot);

            // Tell listeners
            _contentPackage.changedElement(this, _mdElement);
        }

        // Finished
        dispose();
    }

}
