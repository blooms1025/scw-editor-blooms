/**
 *  RELOAD TOOLS
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Phillip Beauvoir
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Phillip Beauvoir
 *  e-mail:   p.beauvoir@bolton.ac.uk
 *
 *  Web:      http://www.reload.ac.uk
 *
 */
package uk.ac.reload.editor.gencontent.editor;

import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import org.jdom.Element;
import org.jdom.Namespace;

import uk.ac.reload.editor.contentpackaging.editor.CP_Editor;
import uk.ac.reload.editor.contentpackaging.xml.ContentPackage;


/**
 * The Content Package Editor Frame - extended to work with modified ims cp schema
 */
public class GenCPEditor extends CP_Editor {
    
    /**
     * Default Constructor
     */
    public GenCPEditor() {
        super();
    }
    
    /**
     * Constructor
     * @param cp The ContentPackage
     */
    public GenCPEditor(ContentPackage cp) {
        super(cp);
    }
    
    /**
     * Over-ride this so we can set view stuff
     */
    public void show() {
        super.show();
        
    }
    
    /**
     * If the manifest has been edited, ask whether we should save it
     * @return true if OK, false if not
     */
    protected boolean saveDocument() {
        removeEmptyFileRef();
        return super.saveDocument();
    }
    
    /**
     * remove empty file href attribute elements
     */
    
    protected void removeEmptyFileRef(){
        // This is a temporary fix
        Namespace ns = getContentPackage().getDocument().getRootElement().getNamespace();
        List resChilds = getContentPackage().getDocument().getRootElement().getChild("resources", ns).getChildren("resource", ns); //$NON-NLS-1$ //$NON-NLS-2$
        Iterator resItr = resChilds.iterator();
        while(resItr.hasNext()){
            Element resChild = (Element)resItr.next();
            List fileChilds = resChild.getChildren("file", ns); //$NON-NLS-1$
            ListIterator fileItr = fileChilds.listIterator();
            while(fileItr.hasNext()){
                Element fileChild = (Element)fileItr.next();
                if((fileChild.getAttribute("href") != null) &&("".equals(fileChild.getAttribute("href").getValue()))){                     //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
                    fileItr.remove();	               
                }
            }
        }
        
        
    }
    
}