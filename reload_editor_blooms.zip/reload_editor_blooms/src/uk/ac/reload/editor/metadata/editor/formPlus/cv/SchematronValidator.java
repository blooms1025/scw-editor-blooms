/****************************************************************************
	Common Validator -  Performs wellformedness checks of XML file and 
						validates XML Instances, Schemas and Schematron rules
	
	File :			  SchemaValidator.java

	Copyright (c) 2004  The Open Group
Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to
deal in the Software without restriction, including without limitation the
rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
IN THE SOFTWARE.

Yuewen Chen
The Open Group, 
Thames Tower, 
37-45 Station Road,
Reading, 
Berkshire, 
RG1 1LX
United Kingdom 

***************************************************************************/

package uk.ac.reload.editor.metadata.editor.formPlus.cv; 

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.jdom.Element;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import uk.ac.reload.editor.properties.EditorProperties;

public class SchematronValidator
{
   // Global value so it can be ref'd by the tree-adapter
    public static File SCHEMAROOTFOLDER = EditorProperties.getFileProperty("schema.dir");
    public static String schemaPath = SCHEMAROOTFOLDER.getAbsolutePath();
    
    
    protected static final String PRE_STYLESHEET = (new File(schemaPath)).getParent() + File.separator
														+ "cvalidator/stylesheets/schematron-basic.xsl";
	static Document document;
	static File schematronfile;
	static File prestylesheet;
	private String prostylesheet = null;
	Element stelement;
	boolean haserror = false;
	
	/**
	Creates an instance of Schematron Validator class with the application profile.
	@param SchematronFile Path to the schemaron file to be validate against
	@exception java.io.FileNotFoundException if the path cannot be found
				SAXException
				ParserConfigurationException
				IOException
				TransformerException
				TransformerConfigurationException
	*/
   
	public SchematronValidator(String SchematronFile)
	throws java.io.FileNotFoundException, SAXException, ParserConfigurationException, IOException,TransformerException,TransformerConfigurationException
	{
	  
	  	stelement = new Element("schematronerror");
		
		SchematronValidator.schematronfile = new File (SchematronFile);
		if (!SchematronValidator.schematronfile.exists())
		{
			throw new java.io.FileNotFoundException("file " + SchematronFile + " does not exist");
		}

		SchematronValidator.prestylesheet = new File(PRE_STYLESHEET);
		
		preprocess((Properties)null);
	}


	/**
	Creates an instance of Schematron Validator class with the application profile.
	@param SchematronFile Path to the schemaron file to be validated against
	@param prestylesheet preprocess stylesheet which will transform schematron to a stylesheet
	@param props Path to the schemaron file to be validate against
	@exception java.io.FileNotFoundException if the path cannot be found
				SAXException
				ParserConfigurationException
				IOException
				TransformerException
				TransformerConfigurationException
	*/
	public SchematronValidator(String SchematronFile, String prestylesheet, Properties props)
	throws java.io.FileNotFoundException, SAXException, ParserConfigurationException, IOException,TransformerException,TransformerConfigurationException
	{
		stelement = new Element("schematronresult");
		
		SchematronValidator.schematronfile = new File (SchematronFile);
 		if (!SchematronValidator.schematronfile.exists())
		{
			throw new java.io.FileNotFoundException("file " + SchematronFile + " does not exist");
		}

	   	if (prestylesheet != null)
		{
	   	 SchematronValidator.prestylesheet = new File(prestylesheet);
		}
		else
		{
		   SchematronValidator.prestylesheet = new File(PRE_STYLESHEET);
		}
		
		preprocess(props);
	}
	
	/*
	   Transforms the xml file with the stylesheet given
	*/
	private void preprocess (Properties props)
	throws SAXException, ParserConfigurationException, IOException, TransformerException,TransformerConfigurationException
	{

		
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		//factory.setValidating(true);
 
		
		DocumentBuilder builder = factory.newDocumentBuilder();
		document = builder.parse(SchematronValidator.schematronfile);

		// Use a Transformer for output
		TransformerFactory tFactory = TransformerFactory.newInstance();
		StreamSource stylesource = new StreamSource(SchematronValidator.prestylesheet);
		Transformer transformer = tFactory.newTransformer(stylesource);
	 	Listener listener = new Listener();
		transformer.setErrorListener(listener);

		DOMSource source = new DOMSource(document);

	   	StringWriter resultout = new StringWriter();
		StreamResult result = new StreamResult(resultout);
		transformer.transform(source, result);
		resultout.close();
		prostylesheet = resultout.toString();
		return;
	}
	
	/**
	Perform validation on xml instance file.
	@param instancefile Path to the xml instance file to be validated
	@exception 
			TransformerException
			TransformerConfigurationException
			SAXException
			IOException
			ParserConfigurationException
	 */
	public String validate(String instancefile)
		throws TransformerException,
		   TransformerConfigurationException,
		   SAXException,
		   IOException,  
		   ParserConfigurationException

	{

	   	// With the stylesheet output from preprocessor and xml instance, do XSLT process
		TransformerFactory trsfactory = TransformerFactory.newInstance();
		//Transformer validator = trsfactory.newTransformer(new StreamSource(new StringBufferInputStream(prostylesheet)));
		//commented out by Roy on 04/02/05 as the above is deprecated
		Transformer validator = trsfactory.newTransformer(new StreamSource(new StringReader(prostylesheet)));
		Listener listener = new Listener();
		validator.setErrorListener(listener);

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		//factory.setNamespaceAware(true);
		//factory.setValidating(true);
		
		DocumentBuilder builder = factory.newDocumentBuilder();
		//document = builder.parse(new File(instancefile));
		StreamSource source = new StreamSource(new File(instancefile));

	   	StringWriter resultout = new StringWriter();
	   	StreamResult result = new StreamResult(resultout);
		   
		validator.transform(source, result);
		resultout.close();
		return resultout.toString();
	}

	public boolean getSchematronErrorStatus()
	{
		return haserror;
	}

	public Element getSchematronRootElement()
	{
		return stelement;
	}
	
  	private class Listener implements javax.xml.transform.ErrorListener
  	{

		public void warning(TransformerException e) 
		{
	  		//warnings.add(e.getMessage());
	  		haserror = true;
	  		Element element = new Element("element");
	  		Element errmsg = new Element ("errmsg");
	  		errmsg.setText(e.getMessage());
	  		element.addContent(errmsg);
	  		stelement.addContent(element);
		   
		}

		public void error(TransformerException e)
	  	throws TransformerException
		{
	  		haserror = true;
	   		Element element = new Element("element");
	  		Element errmsg = new Element ("errmsg");
	  		errmsg.setText(e.getMessage());
	  		element.addContent(errmsg);
	  		stelement.addContent(element);

		}

		public void fatalError(TransformerException e)
	  	throws TransformerException
		{
	  		haserror = true;
	   		Element element = new Element("element");
	  		Element errmsg = new Element ("errmsg");
	  		errmsg.setText(e.getMessage());
	  		element.addContent(errmsg);
	  		stelement.addContent(element);

		}
  	}


}
