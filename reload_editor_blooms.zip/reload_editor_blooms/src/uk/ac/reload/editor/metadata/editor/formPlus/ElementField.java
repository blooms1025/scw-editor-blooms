/**
 *  RELOAD TOOLS
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Phillip Beauvoir
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Phillip Beauvoir
 *  e-mail:   p.beauvoir@bolton.ac.uk
 *
 *  Web:      http://www.reload.ac.uk
 *
 */
package uk.ac.reload.editor.metadata.editor.formPlus;
import java.awt.Component;

import org.jdom.Element;

import uk.ac.reload.editor.gui.FormField;
import uk.ac.reload.jdom.XMLDocument;
import uk.ac.reload.jdom.XMLDocumentListener;
import uk.ac.reload.jdom.XMLDocumentListenerEvent;
import uk.ac.reload.moonunit.SchemaDocument;
import uk.ac.reload.moonunit.schema.SchemaElement;

/**
 * An Edit Field Form Text widget abstract class
 */

public abstract class ElementField extends FormField implements XMLDocumentListener {
    
    
    public ElementField(SchemaDocument schemaDocument, Element element){
        super(schemaDocument, element);
    }
    
    /**
     * @param schemaDocument
     * @param schemaElement
     */
    public ElementField(
            SchemaDocument schemaDocument,
            SchemaElement schemaElement) {
        super(schemaDocument, schemaElement);
    }
    
    /**
     * @param schemaDocument
     * @param element
     * @param schemaElement
     */
    public ElementField(
            SchemaDocument schemaDocument,
            Element element,
            SchemaElement schemaElement) {
        super(schemaDocument, element, schemaElement);
    }
    
    /**
     * Tell the SchemaDocument that we changed
     */
    protected synchronized void fireElementChanged() {
        
        String text = getValue();
        
        // Check first if we are not yet bound to an Element.  If not, add a new, unique, Element
        if (getElement() == null) {
            // This call will also take care of firing the appropriate event
            Element element =
                getSchemaDocument().addElementUniqueBySchemaUndoable(
                        this,
                        getSchemaElement(),
                        true);
            setElement(element);
        }
        
        // Now we have the Element(check for null just in case), set the Element's text value and tell the SchemaDocument
        if (getElement() != null) {
            getElement().setText(text);
            getSchemaDocument().changedElement(this, getElement());
        }
    }
    /**
     * 
     */
    public String getValue() {
        return null;
    }
    /**
     * 
     */
    public void setValue(String value) {
    }
    /**
     * 
     */
    public Component getComponent() {
        // TODO Auto-generated method stub
        return null;
    }
    
    /**
     * 
     */
    public void destroy() {
        
    }
    /**
     * 
     */
    public void elementAdded(XMLDocumentListenerEvent event) {
        // do nothing - container to manage this
    }
    
    /**
     * 
     */
    public void elementRemoved(XMLDocumentListenerEvent event) {
//      do nothing - container to manage this
    }
    
    /**
     * 
     */
    public void elementChanged(XMLDocumentListenerEvent event) {
        // Don't listen to events that we have fired
        if(event.getSource() == this) {
            return;
        }
        
        // We changed!
        Element element = event.getElement();
        if(element == getElement()) {
            setValue(getElement().getText());
           
        }
        

        
    }
    
    /**
     * 
     */
    public void documentSaved(XMLDocument doc) {
        
    }
    
}
