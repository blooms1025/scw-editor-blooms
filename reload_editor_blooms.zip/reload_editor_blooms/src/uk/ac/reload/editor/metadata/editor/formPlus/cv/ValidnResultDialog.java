/**
 *  Content Re-Engineerng Tool
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Roy P Cherian
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Roy P Cherian
 *  e-mail:   rc3@bolton.ac.uk
 *
 *
 */
package uk.ac.reload.editor.metadata.editor.formPlus.cv;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.util.Iterator;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import org.jdom.Element;

import uk.ac.reload.editor.EditorFrame;
import uk.ac.reload.editor.Messages;
import uk.ac.reload.editor.metadata.editor.formPlus.FormController;

/**
 * @author Roy P Cherian
 *
 * TODO
 */
public class ValidnResultDialog {

    static int Width = 170;
    static Font littleFont = new Font("Dialog", Font.PLAIN, 3); //$NON-NLS-1$
    
    /**
     * This method returns a nonmodal dialog for displaying error message from
     * parser validation result supplied by the common validator
     * 
     * @param valdnRoot
     * @param parent
     */
    static public JDialog getDialog(Element valdnRoot, Component parent,
            FormController fc) {
        

        //Create the dialog.
        JDialog dialog = new JDialog(EditorFrame.getInstance(),
                Messages.getString("ValidnResultDialog.0")); //$NON-NLS-1$
        JPanel msgPanel = new JPanel();
        msgPanel.setLayout(new BoxLayout(msgPanel, BoxLayout.Y_AXIS));
        FontMetrics fm =  dialog.getFontMetrics(littleFont);
        
        // the following for making labels from validation messages
        Element xpath = null;
        String path;
        JLabel label = null;
        //int count = 0;

        List errChildrn = valdnRoot.getChildren("element"); //$NON-NLS-1$
        for (Iterator iter = errChildrn.iterator(); iter.hasNext();) {
            Element element = (Element) iter.next();

            if ((element.getAttribute("type") != null)&& ((element.getAttribute("type").getValue().equals("error"))
                    || (element.getAttribute("type").getValue().equals("warning")))) { //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
                xpath = element.getChild("xpath"); //$NON-NLS-1$
                if ((xpath != null) && (xpath.getTextTrim() != "")) { //$NON-NLS-1$
                    path = Messages.getString("ValidnResultDialog.8") + xpath.getTextTrim(); //$NON-NLS-1$
                    label = new CVLabel(xpath.getTextTrim(), fc);
                    label.setAlignmentX(Component.CENTER_ALIGNMENT);
                    msgPanel.add(label);
                }
                path = Messages.getString("ValidnResultDialog.9") //$NON-NLS-1$
                        + element.getChild("errmsg").getTextTrim(); //$NON-NLS-1$
                
                // the following lines to break the string to something that fits the screen
               
                label = new JLabel("<html><font size=3 color=red>" + stringBreaker(path, fm) //$NON-NLS-1$
                        + "<br>"); //$NON-NLS-1$
                label.setAlignmentX(Component.CENTER_ALIGNMENT);
                msgPanel.add(label);

            }

            //TODO
            // add a divider for each error message
        }

        JScrollPane dialogSP = new JScrollPane(msgPanel);
        dialog.getContentPane().add(dialogSP);
        //dialog.setSize(new Dimension(600, 400));
        Dimension dim = EditorFrame.getInstance().getSize();
        dialog.setSize(new Dimension(dim.width*3/4, dim.height*3/4));
        //dialog.setBounds(new Rectangle(parent.getSize()));
        //dialog.pack();
        dialog.setLocationRelativeTo(parent);
        return dialog;
    }
    

    /**
     * This method returns a nonmodal dialog for displaying error message from
     * parser validation result supplied by the common validator
     * 
     * @param valdnRoot
     */
    static public JDialog getDialog(Element valdnRoot) {
        

        //Create the dialog.
        JDialog dialog = new JDialog(EditorFrame.getInstance(),
                Messages.getString("ValidnResultDialog.1")); //$NON-NLS-1$
        JPanel msgPanel = new JPanel();
        msgPanel.setLayout(new BoxLayout(msgPanel, BoxLayout.Y_AXIS));
        FontMetrics fm =  dialog.getFontMetrics(littleFont);
        // the following for making labels from validation messages
        Element xpath = null;
        String path;
        JLabel label = null;
        //int count = 0;

        List errChildrn = valdnRoot.getChildren("element"); //$NON-NLS-1$
        for (Iterator iter = errChildrn.iterator(); iter.hasNext();) {
            Element element = (Element) iter.next();

            if ((element.getAttribute("type") != null)&& (element.getAttribute("type").getValue().equals("error"))) { //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
                xpath = element.getChild("xpath"); //$NON-NLS-1$
                if ((xpath != null) && (xpath.getTextTrim() != "")) { //$NON-NLS-1$
                    path = Messages.getString("ValidnResultDialog.20") + xpath.getTextTrim(); //$NON-NLS-1$
                    label = new JLabel(xpath.getTextTrim());
                    label.setAlignmentX(Component.CENTER_ALIGNMENT);
                    msgPanel.add(label);
                }
                path = Messages.getString("ValidnResultDialog.21") //$NON-NLS-1$
                        + element.getChild("errmsg").getTextTrim(); //$NON-NLS-1$
                 label = new JLabel("<html><font size=3 color=red>" + stringBreaker(path, fm) //$NON-NLS-1$
                        + "<br>"); //$NON-NLS-1$
                label.setAlignmentX(Component.CENTER_ALIGNMENT);
                msgPanel.add(label);

            }

            //TODO
            // add a divider for each error message
        }

        JScrollPane dialogSP = new JScrollPane(msgPanel);
        dialog.getContentPane().add(dialogSP);
        
        Dimension dim = EditorFrame.getInstance().getSize();
        dialog.setSize(new Dimension(dim.width/2, dim.height/2));
        //dialog.setBounds(new Rectangle(EditorFrame.getInstance().getSize()));
        //dialog.pack();
        dialog.setLocationRelativeTo(EditorFrame.getInstance());
        return dialog;
    }
    
    
    /**
     * This method returns a nonmodal dialog for displaying error message from parser validation result 
     * supplied by the common validator
     * @param valdnRoot
     * @param parent
     */
    static public JDialog getDialogOld(Element valdnRoot, Component parent, FormController fc){

        //Create the dialog.
        JDialog dialog = new JDialog(EditorFrame.getInstance(), Messages.getString("ValidnResultDialog.2")); //$NON-NLS-1$
        //System.out.println(" I am getting jdialog from  !");
        
        /*JButton closeButton = new JButton("Close");
        closeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dialog.setVisible(false);
                dialog.dispose();
            }
        });*/
       /* JPanel closePanel = new JPanel();
        closePanel.setLayout(new BoxLayout(closePanel,
                                           BoxLayout.LINE_AXIS));
        closePanel.add(Box.createHorizontalGlue());
        //closePanel.add(closeButton);
        closePanel.setBorder(BorderFactory.createEmptyBorder(0,0,5,5));*/

        JPanel msgPane = new JPanel();
        //msgPane.setLayout(new BoxLayout(msgPane, BoxLayout.Y_AXIS));
       
        msgPane.setLayout(new BoxLayout(msgPane, BoxLayout.PAGE_AXIS));
        JScrollPane dialogSP = new JScrollPane(msgPane);
        
        // the following for making labels from validation messages
        Element xpath;
        String path;
        JLabel label= null;
      
        List errChildrn = valdnRoot.getChildren("element"); //$NON-NLS-1$
        for (Iterator iter = errChildrn.iterator(); iter.hasNext();) {
            Element element = (Element) iter.next();
            
            if ((element.getAttribute("type") != null)&&(element.getAttribute("type").getValue().equals("error"))) { //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
                xpath = element.getChild("xpath"); //$NON-NLS-1$
                if((xpath != null) && (xpath.getTextTrim() != "")){ //$NON-NLS-1$
                    path = Messages.getString("ValidnResultDialog.32") + xpath.getTextTrim(); //$NON-NLS-1$
                    print(path);
                    label = new CVLabel(xpath.getTextTrim(), fc);
                    label.setAlignmentX(Component.CENTER_ALIGNMENT);
                    msgPane.add(label);
                }
                path = Messages.getString("ValidnResultDialog.33") + element.getChild("errmsg").getTextTrim(); //$NON-NLS-1$ //$NON-NLS-2$
                print(path);
                label = new JLabel("<html><font size=3 color=red>" + path +"<br>"); //$NON-NLS-1$ //$NON-NLS-2$
                label.setAlignmentX(Component.CENTER_ALIGNMENT);
                msgPane.add(label);
                
            }
            //TODO
            // add a divider for each error message
        }

        //dialogSP.setOpaque(true);
        dialog.getContentPane().add(dialogSP);
              
        dialog.pack();
        dialog.setSize(new Dimension(600, 400));
        dialog.setLocationRelativeTo(parent);

        dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        return dialog;
    }
    
    
    public static void print(String msg){
        System.out.println(msg);
    }
    
    /**
     * This method break up a long string into multiple lines of width 80 chars 
     * plus new line chars
     * @param inString
     * @return
     */
    
    public static String stringBreaker(String inString, FontMetrics fm){
        
        StringBuffer sb = new StringBuffer(inString);
        int start = 0;
        int stop = 0;
        int hold = 0;
        int offset = 0;
 
        while(stop < inString.length()) {
            while(fm.stringWidth(inString.substring(start, stop)) < Width) {
                if(inString.charAt(stop) == '\n') {
                    start = ++stop;
                } else {
                    stop++;
                }
 
                if(stop >= (inString.length() - 1)) {
                    break;
                }
            }
 
            if(stop >= (inString.length() - 1)) {
                break;
            }
 
            hold = stop;
            while((inString.charAt(stop) != ' ') && (start != stop)) {
                stop--;
            }
 
            if(start == stop) {
                stop = hold;
            }
 
            if(sb.charAt(stop + offset) == ' ') {
                sb.insert(stop + offset, "<br>"); //$NON-NLS-1$
            } else {
                sb.insert(stop, "<br>"); //$NON-NLS-1$
                offset++;
            }
 
            start = ++stop;
        }
 
        return sb.toString();
     
    }
    

}
