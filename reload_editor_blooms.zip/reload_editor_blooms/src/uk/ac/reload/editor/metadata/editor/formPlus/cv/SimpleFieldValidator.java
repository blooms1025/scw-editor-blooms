/**
 *  Content Re-Engineerng Tool
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Roy P Cherian
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Roy P Cherian
 *  e-mail:   rc3@bolton.ac.uk
 *
 *
 */
package uk.ac.reload.editor.metadata.editor.formPlus.cv;

import org.eclipse.xsd.XSDAttributeDeclaration;
import org.eclipse.xsd.XSDAttributeUse;
import org.eclipse.xsd.XSDComplexTypeDefinition;
import org.eclipse.xsd.XSDConcreteComponent;
import org.eclipse.xsd.XSDElementDeclaration;
import org.eclipse.xsd.XSDSimpleTypeDefinition;
import org.eclipse.xsd.XSDTypeDefinition;

import uk.ac.reload.moonunit.schema.SchemaAttribute;
import uk.ac.reload.moonunit.schema.SchemaElement;

/**
 * @author Roy P Cherian
 * 
 * TODO
 */
public class SimpleFieldValidator {

    /**
     * This method checks whether the string value supplied is valid w r t the
     * simple type used for this xsd type - this is for cases where it is an
     * element
     */
    public static boolean isValid(SchemaElement schEl, String strVal) {
        //System.out.println(" Inside simple field valdiator schema element");
        if(schEl == null){
            //System.out.println("\t Schema element is null for this element and hence VALID");
            //TODO
            return true; // FIXME
        }
        XSDElementDeclaration xsdEl = schEl.getElementDecl();
        XSDTypeDefinition xsdType = xsdEl.getTypeDefinition();
        if (xsdType instanceof XSDSimpleTypeDefinition) {

            return ((XSDSimpleTypeDefinition) xsdType).isValidLiteral(strVal);
        } else {

            XSDComplexTypeDefinition cmplxType = (XSDComplexTypeDefinition) xsdType;

            XSDTypeDefinition baseType = cmplxType.getBaseTypeDefinition();

            if (baseType instanceof XSDSimpleTypeDefinition) {

                return ((XSDSimpleTypeDefinition) baseType)
                        .isValidLiteral(strVal);

            }

            //TODO
            //do nothing ?
            return false;
        }
    }

    /**
     * This method checks whether the string value supplied is valid w r t the
     * simple type used for this xsd type - this is for cases where it is an
     * attribute
     */
    public static boolean isValid(SchemaAttribute schAtt, String strVal) {
        //System.out.println(" Inside simple field valdiator schema attribute " + schAtt.getName() + " value: " + strVal);
        if(schAtt == null){
            //TODO
            //System.out.println("\t Schema element is null for this attribute and hence VALID");
            return true; // is this ok ?
        }// a temporary work around to displaying red in CP manifest tree
  /*      else if((schAtt.getName().equals("default")) && (schAtt.getParent().getName().equals("organizations"))){
            //System.out.println(" parent is " + schAtt.getParent().getName());
            return true;
        }*/
        XSDAttributeDeclaration xsdAtt = schAtt.getAttributeDecl()
                .getResolvedAttributeDeclaration();

        //Probably the getContainer of the XSDAttributeDeclaration will be the
        // XSDAttributeUse.
        XSDConcreteComponent comp = xsdAtt.getContainer();
        if (comp instanceof XSDAttributeUse) {
            //System.out.println("\t Schema attribute use constraint");
            //In the case of fixed attrinutes check to see that the supplied
            // string is what is needed
            XSDAttributeUse attUse = (XSDAttributeUse) comp;
            if (attUse.isSetConstraint()
                    && (attUse.getConstraint().getName().equals("fixed"))) {
                return strVal.equals(attUse.getLexicalValue());
            }

        }
        //System.out.println("\t Schema attribute NOT se constraint " + strVal);
        
        XSDSimpleTypeDefinition xsdType = xsdAtt.getTypeDefinition();
        //SchemaUtils.printComponent(xsdType);
        return ((XSDSimpleTypeDefinition) xsdType).isValidLiteral(strVal);

    }

}