/**
 *  RELOAD TOOLS
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Phillip Beauvoir
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Phillip Beauvoir
 *  e-mail:   p.beauvoir@bolton.ac.uk
 *
 *  Web:      http://www.reload.ac.uk
 *
 */
package uk.ac.reload.editor.metadata.editor.formPlus;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.Border;

import uk.ac.reload.dweezil.gui.GradientPanel;
import uk.ac.reload.dweezil.util.DweezilUIManager;
import uk.ac.reload.editor.Messages;

import com.brunchboy.util.swing.relativelayout.AttributeConstraint;
import com.brunchboy.util.swing.relativelayout.AttributeType;
import com.brunchboy.util.swing.relativelayout.DependencyManager;
import com.brunchboy.util.swing.relativelayout.RelativeLayout;


/**
 * Embedded panel for displaying schema validaiton results
 *
 */
public class ValidationPanel extends GradientPanel {
    /**
     * The JLabel to display title of panel
     */
    private JLabel titleLbl;
    
    /**
     * The TextArea to display the validation results
     */
    private JTextArea resultTxt;
    
    private RelativeLayout layout;
    
    
    public ValidationPanel() {
        layout = new RelativeLayout();
        setLayout(layout);
        
        // Name label
        titleLbl = new JLabel(Messages.getString("ValidationPanel.0")); //$NON-NLS-1$
        titleLbl.setFont(DweezilUIManager.boldFont11);
        
        add(titleLbl, "title"); //$NON-NLS-1$
        layout.addConstraint(
                "title", //$NON-NLS-1$
                AttributeType.TOP,
                new AttributeConstraint(
                        DependencyManager.ROOT_NAME,
                        AttributeType.TOP));
        layout.addConstraint(
                "title", //$NON-NLS-1$
                AttributeType.LEFT,
                new AttributeConstraint(
                        DependencyManager.ROOT_NAME,
                        AttributeType.LEFT));
        layout.addConstraint(
                "title", //$NON-NLS-1$
                AttributeType.RIGHT,
                new AttributeConstraint(
                        DependencyManager.ROOT_NAME,
                        AttributeType.LEFT, 100));
        
        resultTxt = new JTextArea();
        resultTxt.setLineWrap(true);
        resultTxt.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
        JScrollPane sp = new JScrollPane(resultTxt);
        sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        
        add(sp,"txt"); //$NON-NLS-1$
        layout.addConstraint(
                "txt", //$NON-NLS-1$
                AttributeType.TOP,
                new AttributeConstraint(
                        "title", //$NON-NLS-1$
                        AttributeType.BOTTOM));
        layout.addConstraint(
                "txt", //$NON-NLS-1$
                AttributeType.LEFT,
                new AttributeConstraint(
                        DependencyManager.ROOT_NAME,
                        AttributeType.LEFT));
        layout.addConstraint(
                "txt", //$NON-NLS-1$
                AttributeType.RIGHT,
                new AttributeConstraint(
                        DependencyManager.ROOT_NAME,
                        AttributeType.RIGHT));
        layout.addConstraint(
                "txt", //$NON-NLS-1$
                AttributeType.BOTTOM,
                new AttributeConstraint(
                        DependencyManager.ROOT_NAME,
                        AttributeType.BOTTOM));
        
        Border border = BorderFactory.createCompoundBorder(BorderFactory.createLoweredBevelBorder(),
                BorderFactory.createEmptyBorder(5, 10, 5, 10));
        setBorder(border);
    }
    
    /**
     * Clear the Settings
     */
    public void clear() {
        resultTxt.setText(""); //$NON-NLS-1$
    }
    
    /**
     * Update the text tip panel
     */
    public void setText(String txt) {
        resultTxt.setText(txt);
        
    }
    
}
