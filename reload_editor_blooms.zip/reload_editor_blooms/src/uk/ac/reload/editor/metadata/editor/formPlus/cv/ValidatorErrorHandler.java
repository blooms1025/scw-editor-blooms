/****************************************************************************
	Common Validator -  Performs wellformedness checks of XML file and 
						validates XML Instances, Schemas and Schematron rules
	
	File :			  ValidatorErrorHandler.java

	Copyright (c) 2004  The Open Group
Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to
deal in the Software without restriction, including without limitation the
rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
IN THE SOFTWARE.

Yuewen Chen
The Open Group, 
Thames Tower, 
37-45 Station Road,
Reading, 
Berkshire, 
RG1 1LX
United Kingdom 


***************************************************************************/

package uk.ac.reload.editor.metadata.editor.formPlus.cv;

//import java library
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.Iterator;
import java.util.StringTokenizer;

import javax.xml.parsers.ParserConfigurationException;

import org.jdom.Attribute;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.contrib.helpers.XPathHelper;
import org.jdom.contrib.input.LineNumberElement;
import org.jdom.contrib.input.LineNumberSAXBuilder;
import org.jdom.filter.ElementFilter;
import org.jdom.input.SAXBuilder;
import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

/**
 * This class will write a XML format test result
 */
public class ValidatorErrorHandler implements ErrorHandler
{
	StringBuffer strbuf;
	static boolean errOccurred = false;
	static String instancefile;
	static Document instancedoc;
	
	// Define the error types
	final private int ELE_ERROR = 1;
	final private int ELEVAL_ERROR = 2;
	final private int ATTR_ERROR = 3;
	final private int ATTRVAL_ERROR = 4;
	
  	Element root = null;
	Element valid = null;
	boolean hasbuilddoc= false;
	
	/**
	 * Class constructor.
	 */
	public ValidatorErrorHandler()
	{
		//Initialise the JDOM root element
		if (root == null)
		{
			root = new Element("d8output");
			//root.addContent(getTimestamp());
		}

		
	 }
	
	/** Receive notification of a warning. This warning is formatted into
	  XML for retrieval.
	 @param exception SAXParseException exception 
	 */
	public void  warning(SAXParseException exception) 
	{
		errOccurred = true;
		StringBuffer sbuf = new StringBuffer();
		StringTokenizer tokenizer;
		String msg;

        	msg = "line " + exception.getLineNumber() + ", " + exception.getMessage();
           
		Element element = new Element("element");
		element.setAttribute("type", "warning");
		
		if (hasbuilddoc)
		{
			Element xpath = new Element("xpath");
			try
			{
				String xpathexp = getXpath(msg);
				xpath.setText(xpathexp);
				element.addContent(xpath);
			}catch(Exception e)
			{
			}
		} 
		 
		Element errmsg = new Element("errmsg"); 
		errmsg.setText(msg); 
		element.addContent(errmsg);
		//etype.addContent(element);
		root.addContent(element);
	 }

	/** Receive notification of a recoverable error. This error is 
	 formatted into XML for retrieval.
	 @param exception SAXParseException exception 
	 */ 
	public void error(SAXParseException exception) 
	{
		errOccurred = true;
		StringBuffer sbuf = new StringBuffer();
		StringTokenizer tokenizer;
		String msg;
        	msg = "line " + exception.getLineNumber() + ", " + exception.getMessage();
           
		Element element = new Element("element");
		element.setAttribute("type", "error");

		if (hasbuilddoc)
		{
			Element xpath = new Element("xpath");
			try
			{
				String xpathexp = getXpath(msg);
				xpath.setText(xpathexp);
				element.addContent(xpath);
			}catch(Exception e)
			{
			 }
		}
		
		Element errmsg = new Element("errmsg"); 
		errmsg.setText(msg); 
		element.addContent(errmsg);
		//etype.addContent(element);
		root.addContent(element);
	}

	/** Receive notification of a non-recoverable error. This error is 
	 formatted into XML for retrieval.
	 @param exception SAXParseException exception 
	 */
	public void fatalError(SAXParseException exception) 
	{
		errOccurred = true;
		StringBuffer sbuf = new StringBuffer();
		StringTokenizer tokenizer;
		String msg;

        	msg = "line " + exception.getLineNumber() + ", " + exception.getMessage();
           
		Element element = new Element("element");
		element.setAttribute("type", "fatal");

		if (hasbuilddoc)
		{
			Element xpath = new Element("xpath");
			try
			{
				String xpathexp = getXpath(msg);
				xpath.setText(xpathexp);
				element.addContent(xpath);
			}catch(Exception e)
			{
			}
		} 

		Element errmsg = new Element("errmsg"); 
		errmsg.setText(msg); 
		element.addContent(errmsg);
		//etype.addContent(element);
		root.addContent(element);
	} 



	/** 
	Add STT tool error if error occurs
	 @param result Error message
	 */
	public void addSchematronResult(String result)
	throws ParserConfigurationException, SAXException, IOException
	{
		errOccurred = true;
		boolean hastitle = false;
		boolean iserror = false;
		
		Element schematronele = new Element("schematronvalidation");
		
		StringTokenizer t = new StringTokenizer (result, "\n");
		Element eletitle = null;
		String firsttk = null;
		if (t.hasMoreTokens())
		{
			firsttk = t.nextToken();
			eletitle = new Element ("title");
			if (firsttk.indexOf("In pattern") == -1)
			{
				// We think this is title
				eletitle.setText(firsttk);
				hastitle = true;
			}
		}
		
		while (t.hasMoreTokens())
		{
			Element element = new Element("element");
			Element errmsg = new Element("errmsg");
			if (!hastitle)
			{
				//This should be the pattern element
				element.setAttribute("pattern", firsttk.substring(11) );
				eletitle.addContent(element);
				
				// Should not do it again
				hastitle = true;
				
			}
		   
		   	String msg = t.nextToken();
		   
			// The forist could be title - need further confirm for different results
			if (msg.indexOf("In pattern") != -1)
			{
				element.setAttribute("pattern", msg.substring(11) );
				eletitle.addContent(element);

			}
			else
			{
				errmsg.setText(msg);
				eletitle.addContent(errmsg);
			}
			
		}
		schematronele.addContent(eletitle);
		root.addContent(schematronele);
	}

	/**
	Add error element to root
	@param element The error element to be added
	*/
	public void addErrorElement(Element element)
	{
		root.addContent(element);
	}
	

	/** 
	 Returns the xml formatted errors that have been found by the parser.
	 @return buffer containing formatted errors.
	*/
	public String getResultAsString() 
	throws IOException
	{
		return ValidatorUtils.getJDOMElementAsString(root);
	}

	/** 
	 Returns the validation status
	 @return boolean true if error occured; else false
	*/
	public boolean getErrorStatus() 
	{
		return errOccurred; 
	}

	/** 
	 Set validation status
	 @param errorstatus Set validation status
	*/
	public void setErrorStatus(boolean errorstatus) 
	{
		ValidatorErrorHandler.errOccurred = errorstatus; 
	}

	/** 
	 Set validation result of valid element
	 @param result set validation result to true if no error; else to false
	*/
	public void setValidationResult(String result) 
	{
		valid = new Element("valid");
		valid.setText(result);
		root.addContent(0, valid);
		//root.addContent(valid);
		 
	}

	/** 
	Get xml result root element
	*/
	public Element getRootElement() 
	{
		return root;		 
	}

	/**
	  Build JDOM document
	  @param instancefile The instance file to be built
	  @exception IOException
	*/
	public void buildInstanceDocument(String instancefile)
	throws JDOMException, IOException
	{
		if (!hasbuilddoc)
		{
			// Build instance file using SAX builder
			SAXBuilder builder = new LineNumberSAXBuilder();
			instancedoc = builder.build(new File(instancefile));
		
			hasbuilddoc = true;
		}
		
	}
	
	
	/**
	  Get xpath expression from error message
	  @param msg The error message
	  @exception Exception
	*/
	public String getXpath(String msg) 
					throws  Exception
	{
		// Need to consider the following error types:
		// 1.element error
		// 2. element value (text)
		// 3. attribute
		// 4. attribute value
		// The first 4 need to have "element" present
		
		Iterator iteri = instancedoc.getDescendants(new ElementFilter());
		String linestr = null;
		if (msg.indexOf("element") != -1 || msg.indexOf("Element") != -1)
		{
			// Get the line number
			int dotindex = msg.indexOf(",");
			linestr = msg.substring(5, dotindex);

			if (!isGigit(linestr))
			{
				throw new Exception("The line number : " + linestr + " is not a digit");
			}
			
			String xpathexp = null;
			int linenum = Integer.parseInt(linestr);

			while (iteri.hasNext())
			{

				LineNumberElement e = (LineNumberElement) iteri.next();
				if ((e.getName() != null)&&(e.getName().equals(getInfoFromString(msg, "element")) && e.getStartLine() == linenum))
				{
					// Element e is the one
					// need to identify what type of error it is
					int errorcode = getErrorType(msg);
						
					// get the element name form the error string  - always needed
					String elementname = getInfoFromString(msg, "element");
						
					if (errorcode == ELE_ERROR)
					{
						xpathexp = getXpathExpression(msg, e, ELE_ERROR);
					}
					else if (errorcode == ELEVAL_ERROR)
					{
					 	xpathexp = getXpathExpression(msg, e, ELEVAL_ERROR);
					}
					else if (errorcode == ATTR_ERROR)
					{
						xpathexp = getXpathExpression(msg, e, ATTR_ERROR);
					}
					else if (errorcode == ATTRVAL_ERROR)
					{
						xpathexp = getXpathExpression(msg, e, ATTRVAL_ERROR);
					}
					 
				 	return xpathexp;
					 
				}
			}
		}
		
		return null;
	}
			
					 
	/* 
	A private method to get xpath expression from error message and error type
	*/
	public String getXpathExpression(String msg, Element e, int errorcode) 
	throws JDOMException
	{
		if (errorcode == ELE_ERROR)
		{
			String elename =  getInfoFromString(msg, "element");
			return XPathHelper.getPathString(e);
			
		}
		else if (errorcode == ELEVAL_ERROR)
		{
			String eleval = getInfoFromString(msg, "value");
			return XPathHelper.getPathString(e) +
						"[. = '" + 
						eleval 
						+ "']";
		}
		else if (errorcode == ATTR_ERROR)
		{
			String attrname = getInfoFromString(msg, "attribute");
			Attribute attr = e.getAttribute(attrname);
			return XPathHelper.getPathString(e) + 
						"[" + 
			XPathHelper.getPathString(e, attr) +
						"]";
		}
		else if (errorcode == ATTRVAL_ERROR)
		{
			String attrname = getInfoFromString(msg, "attribute");
			String value = getInfoFromString(msg, "value");
			Attribute attr = e.getAttribute(attrname);
			return XPathHelper.getPathString(e) + 
						"[" + 
			XPathHelper.getPathString(e, attr) +
						"=\"" + value +
						"\"]";
		}
		
		return null;
		
	}
	
	/* 
	A private method to get error type
	*/
	private int getErrorType(String msg)
	{
		//element only - ELE_ERROR
		//element + attribte  - ATTR_ERROR
		//element + value - ELEVAL_ERROR
		// element + attribute + value - ATTRVAL_ERROR
		int eleindex = msg.indexOf("element");
		int attrindex = msg.indexOf("attribute");
		int valindex = msg.indexOf("value");
		
		if (eleindex != -1)
		{
			if (attrindex != -1)
			{
				if (valindex != -1)
				{
					return ATTRVAL_ERROR;
				}
				else
				{
					return ATTR_ERROR;
				}
			}
			else
			{
				if (valindex != -1)
				{
					return ELEVAL_ERROR;
				}
				else
				{
					return ELE_ERROR;
				}
			}
		}
		
		return -1;
	}
		
	 	/*
	 A private method to get the element name when error occurs
	 */
	 public String getInfoFromString(String msg, String comp)
	 {

		int namestart = -1;
		int nameend = -1;
		int startpoint;
		
		String errname = null;
	
		if (msg.indexOf(" element ") == -1)
			return null;
			
		startpoint = msg.indexOf(" " + comp + " ");
		if (startpoint == -1)
		{
			return null;
		}
		
		namestart = msg.indexOf("'", startpoint);
		if (namestart == -1)
		{
			namestart = msg.indexOf("\"", startpoint);
		}
		
		if (namestart == -1)
			return null;

		nameend = msg.indexOf("'", namestart + 1);
		if (nameend == -1)
		{
			nameend = msg.indexOf("\"", namestart + 1);
		}
		
		if (nameend == -1)
			return null;
	 
		return msg.substring (namestart + 1, nameend);
 		
	 }


	/*
	 A private method to get the attribute and value when error occurs
	 */
	 public String getAttributeAndValueFromString(String msg)
	 {
		int namestart = -1;
		int nameend = -1;
		int startpoint;
		
		String attrname = getInfoFromString(msg, "attribute");
		String value = getInfoFromString(msg, "value");
		
		return attrname + "=" + value;
	}

	/*
	A private method to check if the string is digit
	*/
	private boolean isGigit(String str)
	{

		char dataarray[] = str.toCharArray();
		for (int i = 0; i < str.length(); i++)
		{
			if ( !(Character.isDigit(dataarray[i])))
			{
				return false;
			}
		}

		return true;
	}
	
	

 	/*
  	*To generate time stamp for the test
  	*/
 	private Element getTimestamp()
 	{
   		Element timestamp = new Element ("timestamp");
   		timestamp.setText((new Date()).toString());
   		return timestamp;
 	}

}
