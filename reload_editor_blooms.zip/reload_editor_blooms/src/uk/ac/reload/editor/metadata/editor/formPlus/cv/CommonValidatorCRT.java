/* **************************************************************************
 Common Validator -  Performs wellformedness checks of XML file and 
 validates XML Instances, Schemas and schematron rules
 
 File :			  CommonValidator.java
 
 Copyright (c) 2004  The Open Group
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to
 deal in the Software without restriction, including without limitation the
 rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 IN THE SOFTWARE.
 
 Dave Scholefield, Yuewen Chen 
 The Open Group, 
 Thames Tower, 
 37-45 Station Road,
 Reading, 
 Berkshire, 
 RG1 1LX
 United Kingdom 
 
 ***************************************************************************/

package uk.ac.reload.editor.metadata.editor.formPlus.cv; 

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Properties;
import java.util.StringTokenizer;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.xerces.impl.Constants;
import org.apache.xerces.parsers.DOMParser;
import org.apache.xerces.parsers.XMLGrammarPreparser;
import org.apache.xerces.util.DefaultErrorHandler;
import org.apache.xerces.util.SymbolTable;
import org.apache.xerces.util.XMLGrammarPoolImpl;
import org.apache.xerces.xni.grammars.Grammar;
import org.apache.xerces.xni.grammars.XMLGrammarDescription;
import org.apache.xerces.xni.parser.XMLInputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;

public class CommonValidatorCRT extends Validator
{
    
    /* Object data */
    /* details of validation */
    private String validationResultString = null;
    private StringBuffer validationResultBuf = null;
    private String wellFormedResultString = null;
    private StringBuffer wellFormedResultBuf = null;
    
    /* result of validation */
    private boolean valResult = false;
    
    /* result of formedness check */
    private boolean formedResult = false;
    
    private int docType;
    
    private DOMParser parser;
    private ValidatorErrorHandler valErrHandler;
    //private String profileFile;
    private String instanceFile;
    private String schemaFile;
    private String schematronFile;
    private ByteArrayOutputStream bastream;
    private PrintWriter pwriter;
    private DefaultErrorHandler ehandler;
    
    /* Object constants */
    protected static final String VALIDATION_FEATURE = "http://xml.org/sax/features/validation";
    /* Schema validation feature id */
    protected static final String SCHEMA_VALIDATION_FEATURE = "http://apache.org/xml/features/validation/schema";
    /* Schema full checking feature id */
    protected static final String SCHEMA_FULL_CHECKING_FEATURE = "http://apache.org/xml/features/validation/schema-full-checking";
    /* Schema dynamic validation feature id */
    protected static final String DYNAMIC_VALIDATION_FEATURE = "http://apache.org/xml/features/validation/dynamic";
    /* Schema external schema validation feature id */
    protected static final String EXTERNAL_NNS_SCHEMA_FEATURE = "http://apache.org/xml/properties/schema/external-noNamespaceSchemaLocation";
    /* Schema external schema validation feature id */
    protected static final String EXTERNAL_SCHEMA_FEATURE = "http://apache.org/xml/properties/schema/external-schemaLocation";
    /* Namespaces feature id (http://xml.org/sax/features/namespaces). */
    protected static final String NAMESPACES_FEATURE = "http://xml.org/sax/features/namespaces";
    
    // Specify schemas for formed and validation output
    protected static final String WELLFORMED_XSD_NAME = "formed.xsd";
    protected static final String VALIDATION_XSD_NAME = "validate.xsd";
    
    // Specify the file suffix for STT generated schema and schematron
    //protected static final String SCHEMA_SUFFIX = "_localised.xsd";
    //protected static final String SCHEMATRON_SUFFIX = "_constraintsDocument.xml";
    
    public static final String GRAMMAR_POOL =
        Constants.XERCES_PROPERTY_PREFIX + Constants.XMLGRAMMAR_POOL_PROPERTY;
    
    // Static constants for schema validator using JAXP
    static final String JAXP_SCHEMA_LANGUAGE = "http://java.sun.com/xml/jaxp/properties/schemaLanguage";
    static final String W3C_XML_SCHEMA = "http://www.w3.org/2001/XMLSchema";
    static final String JAXP_SCHEMA_SOURCE = "http://java.sun.com/xml/jaxp/properties/schemaSource";
    
    private boolean iswellformed = false;
    
    /**
     Creates an instance of Validator class with no arguments
     */
    public CommonValidatorCRT() 
    {
        // Initialise the error handler
        valErrHandler = new ValidatorErrorHandler();
    }
    
    /**
     Performs a check on the well formedness of the loaded schema or profile.
     @param file Instance file to be checked for well-formed
     @return true if file is well formed, false if not or formedness fails
     */
    public boolean checkFormed(String file) 
    throws Exception
    {
        /* Variables */
        formedResult = true;
        StringBuffer sbuf;
        
        /* Set up the parser to check for formedness */
        parser = new DOMParser(); 
        parser.setErrorHandler(valErrHandler); 
        
        try{
            parser.setFeature(VALIDATION_FEATURE, false);
        }
        catch (SAXNotRecognizedException e) {
            //System.err.println("setFeature(" +VALIDATION_FEATURE +", false) threw exception " +e);
            formedResult = false;
            throw new Exception("setFeature(" + VALIDATION_FEATURE + ", false) threw exception " + e.getMessage());
            
        }
        catch (SAXNotSupportedException e) {
            //System.err.println("setFeature(" +VALIDATION_FEATURE +", false) threw exception " +e);
            formedResult = false;
            throw new Exception("setFeature(" +VALIDATION_FEATURE +", false) threw exception " + e.getMessage());
        }
        
        /* Parse the file */
        try 
        { 
            parser.parse(file);
        }
        catch (SAXException e) {
            formedResult = false;
            throw new Exception("parse " + file + " threw SAXException " + e.getMessage());
        }
        catch (IOException e) {
            formedResult = false;
            throw new Exception("parse " + file + " threw IOException " + e.getMessage());
        }
        
        
        if (!formedResult)
        {
            valErrHandler.setErrorStatus(!formedResult);
        }
        
        iswellformed = formedResult;
        
        return formedResult;
    } 
    
    /**
     Checking if the XML instance is well-formed
     @return true if the XML instance is well-formed, false if not.
     */
    public boolean isWellformed()
    {
        return iswellformed;
    }
    
    /**
     Performs a validation on an XML instance (not a schema or set of
     schematron rules.
     @param instancefile The xml instance file to be validated
     @return true if the XML instance is valid, false if not.
     */
    public boolean validateInstance(String instancefile) 
    throws Exception
    {
        // First need to build instance file using SAXBuild, 
        // so the error message will be able to be expressed in xpath.
        buildInstanceForXpath(instancefile);
        
        /* Variables */
        valResult = true;
        // Start SAXbuild of instance file, so we can use xpath for result
        /* Set up the parser to check for validation */
        parser = new DOMParser(); 
        parser.setErrorHandler(valErrHandler); 
        
        try {
            parser.setFeature(VALIDATION_FEATURE, true);
        }
        catch (SAXNotRecognizedException e) {
            //System.err.println("setFeature(" +VALIDATION_FEATURE +", true) threw exception " +e);
            valResult = false;
            throw new Exception("setFeature(" +VALIDATION_FEATURE +", true) threw exception " + e.getMessage());
            
        }
        catch (SAXNotSupportedException e) {
            //System.err.println("setFeature(" +VALIDATION_FEATURE +", true) threw exception " +e);
            valResult = false;
            throw new Exception("setFeature(" +VALIDATION_FEATURE +", true) threw exception " + e.getMessage());
        } 
        
        try {
            parser.setFeature(SCHEMA_VALIDATION_FEATURE, true);
        }
        catch (SAXNotRecognizedException e) {
            //System.err.println("setFeature(" +SCHEMA_VALIDATION_FEATURE +", true) threw exception " +e);
            valResult = false;
            throw new Exception("setFeature(" +SCHEMA_VALIDATION_FEATURE +", true) threw exception " + e.getMessage());
        }
        catch (SAXNotSupportedException e) {
            //System.err.println("setFeature(" +SCHEMA_VALIDATION_FEATURE +", true) threw exception " +e);
            valResult = false;
            throw new Exception("setFeature(" +SCHEMA_VALIDATION_FEATURE +", true) threw exception " + e.getMessage());
        } 
        
        try {
            parser.setFeature(SCHEMA_FULL_CHECKING_FEATURE, true);
        }
        catch (SAXNotRecognizedException e) {
            //System.err.println("setFeature(" +SCHEMA_FULL_CHECKING_FEATURE +", true) threw exception " +e);
            valResult = false;
            throw new Exception("setFeature(" +SCHEMA_FULL_CHECKING_FEATURE +", true) threw exception " + e.getMessage());
        }
        catch (SAXNotSupportedException e) {
            //System.err.println("setFeature(" +SCHEMA_FULL_CHECKING_FEATURE +", true) threw exception " +e);
            valResult = false;
            throw new Exception("setFeature(" +SCHEMA_FULL_CHECKING_FEATURE +", true) threw exception " + e.getMessage());
        }
        
        try {
            parser.setFeature(DYNAMIC_VALIDATION_FEATURE, true);
        }
        catch (SAXNotRecognizedException e) {
            //System.err.println("setFeature(" +DYNAMIC_VALIDATION_FEATURE +", true) threw exception " +e);
            valResult = false;
            throw new Exception("setFeature(" +DYNAMIC_VALIDATION_FEATURE +", true) threw exception " + e.getMessage());
        }
        catch (SAXNotSupportedException e) {
            //System.err.println("setFeature(" +DYNAMIC_VALIDATION_FEATURE +", true) threw exception " +e);
            valResult = false;
            throw new Exception("setFeature(" +DYNAMIC_VALIDATION_FEATURE +", true) threw exception " + e.getMessage());
        }
        /* parse the file */
        try { 
            parser.parse(instancefile);
        }
        catch (SAXException e) {
            //System.err.println("parse(" +instancefile +") threw exception " +e); 
            valResult = false;
            throw new Exception("parse(" +instancefile +") threw exception " + e.getMessage());
        }
        catch (IOException e) {
            //System.err.println("parse(" +instancefile +") threw exception " +e); 
            valResult = false;
            throw new Exception("parse(" +instancefile +") threw exception " + e.getMessage());
        }
        
        if (!valResult)
        {
            valErrHandler.setErrorStatus(!valResult);
        }
        
        return valResult;
    }
    
    /**
     Performs a validation on an XML instance (not a schema or set of
     schematron rules.
     @param instancefile The instance file to be validated
     @param schemafile The schema file to validate against
     @return true if the XML instance is valid, false if not.
     */
    public boolean validateInstance(String instancefile, String schemafile) 
    throws Exception
    {
        // First need to build instance file using SAXBuild, 
        // so the error meesage will be able to be expressed in xpath.
        buildInstanceForXpath(instancefile);
        
        // Variables 
        valResult = true;
        // Set up the parser to check for formedness 
        parser = new DOMParser(); 
        parser.setErrorHandler(valErrHandler); 
        
        try {
            parser.setProperty(EXTERNAL_SCHEMA_FEATURE, schemafile);
        }
        catch (SAXNotRecognizedException e) {
            //System.err.println("setProperty(" +EXTERNAL_SCHEMA_FEATURE +", true) threw exception " +e);
            valResult = false;
            throw new Exception("setProperty(" + EXTERNAL_SCHEMA_FEATURE + ", true) threw exception " + e.getMessage());
        }
        catch (SAXNotSupportedException e) {
            //System.err.println("setFeature(" +EXTERNAL_SCHEMA_FEATURE +", true) threw exception " +e);
            valResult = false;
            throw new Exception("setProperty(" +EXTERNAL_SCHEMA_FEATURE +", true) threw exception " + e.getMessage());
        } 
        
        try {
            parser.setFeature(VALIDATION_FEATURE, true);
        }
        catch (SAXNotRecognizedException e) {
            //System.err.println("setFeature(" +VALIDATION_FEATURE +", true) threw exception " +e);
            valResult = false;
            throw new Exception("setFeature(" +VALIDATION_FEATURE +", true) threw exception " + e.getMessage());
        }
        catch (SAXNotSupportedException e) {
            //System.err.println("setFeature(" +VALIDATION_FEATURE +", true) threw exception " +e);
            valResult = false;
            throw new Exception("setFeature(" +VALIDATION_FEATURE +", true) threw exception " + e.getMessage());
        } 
        
        try {
            parser.setFeature(SCHEMA_VALIDATION_FEATURE, true);
        }
        catch (SAXNotRecognizedException e) {
            //System.err.println("setFeature(" +SCHEMA_VALIDATION_FEATURE +", true) threw exception " +e);
            valResult = false;
            throw new Exception("setFeature(" +SCHEMA_VALIDATION_FEATURE +", true) threw exception " + e.getMessage());
        }
        catch (SAXNotSupportedException e) {
            //System.err.println("setFeature(" +SCHEMA_VALIDATION_FEATURE +", true) threw exception " +e);
            valResult = false;
            throw new Exception("setFeature(" +SCHEMA_VALIDATION_FEATURE +", true) threw exception " + e.getMessage());
        } 
        
        try {
            parser.setFeature(SCHEMA_FULL_CHECKING_FEATURE, true);
        }
        catch (SAXNotRecognizedException e) {
            //System.err.println("setFeature(" +SCHEMA_FULL_CHECKING_FEATURE +", true) threw exception " +e);
            valResult = false;
            throw new Exception("setFeature(" +SCHEMA_FULL_CHECKING_FEATURE +", true) threw exception " + e.getMessage());
        }
        catch (SAXNotSupportedException e) {
            //System.err.println("setFeature(" +SCHEMA_FULL_CHECKING_FEATURE +", true) threw exception " +e);
            valResult = false;
            throw new Exception("setFeature(" +SCHEMA_FULL_CHECKING_FEATURE +", true) threw exception " + e.getMessage());
        }
        
        try {
            parser.setFeature(DYNAMIC_VALIDATION_FEATURE, true);
        }
        catch (SAXNotRecognizedException e) {
            //System.err.println("setFeature(" +DYNAMIC_VALIDATION_FEATURE +", true) threw exception " +e);
            valResult = false;
            throw new Exception("setFeature(" +DYNAMIC_VALIDATION_FEATURE +", true) threw exception " +e);
        }
        catch (SAXNotSupportedException e) {
            //System.err.println("setFeature(" +DYNAMIC_VALIDATION_FEATURE +", true) threw exception " +e);
            valResult = false;
            throw new Exception("setFeature(" +DYNAMIC_VALIDATION_FEATURE +", true) threw exception " +e);
        }
        
        
        // parse the file //
        try { 
            parser.parse(instancefile);
        }
        catch (SAXException e) {
            //System.err.println("parse(" +instancefile +") threw exception " +e); 
            valResult = false;
            throw new Exception("parse(" +instancefile +") threw exception " + e);
        }
        catch (IOException e) {
            //System.err.println("parse(" +instancefile +") threw exception " +e); 
            valResult = false;
            throw new Exception("parse(" +instancefile +") threw exception " + e);
        }
        
        if (!valResult)
        {
            valErrHandler.setErrorStatus(!valResult);
        }
        return valResult;
    }
    
    /**
     Performs a validation on an XML instance (not a schema or set of
     schematron rules.
     @param instancefile The instance file to be validated
     @param schemafiles The schema files to validate against, in the format of array of string
     @return true if the XML instance is valid, false if not.
     */
    public boolean validateInstance(String instancefile, String[] schemafiles) 
    throws Exception
    {
        // First need to build instance file using SAXBuild, 
        // so the error meesage will be able to be expressed in xpath.
        buildInstanceForXpath(instancefile);
        /*StringBuffer sb = new StringBuffer("");
        for (int i = 0; i < schemafiles.length; i++) {
            sb.append(schemafiles[i]);
        }
        System.out.println(" Schema locations are " + sb.toString());*/
        // Variables 
        valResult = true;
        
        try
        {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setNamespaceAware(true);
            factory.setValidating(true);
            
            factory.setAttribute(JAXP_SCHEMA_LANGUAGE, W3C_XML_SCHEMA);
            
            // Set array of schema files as attribute
            factory.setAttribute(JAXP_SCHEMA_SOURCE, schemafiles);
            
            DocumentBuilder docBuilder = factory.newDocumentBuilder();
            
            // set up error handler
            docBuilder.setErrorHandler(valErrHandler); 
            
            // Validate the xml instance
            org.w3c.dom.Document doc = docBuilder.parse(new File(instancefile));
        }
        catch (Exception e)
        {
            valResult = false;
            throw new Exception("ValidateInstance threw exception: " + e.getMessage());
        }
        
        if (!valResult)
        {
            valErrHandler.setErrorStatus(!valResult);
        }
        return valResult;
    }
    
    /** 
     Performs a validation on an XML schema.
     @param schemafile The schema to be validated against
     @return true if the XML schema is valid, false if not.
     */ 
    public boolean validateSchema(String schemafile) 
    throws Exception
    {
        SymbolTable symTab;
        XMLGrammarPreparser preparser;
        XMLGrammarPoolImpl pool; 
        Grammar grammar;
        
        valResult = true;
        
        /* Set up alternate error handling to allow xml to be formed from
         * parser output
         */
        
        bastream = new ByteArrayOutputStream(2000);
        pwriter = new PrintWriter(bastream, true);
        ehandler = new DefaultErrorHandler(pwriter);
        
        symTab = new SymbolTable(2039);
        preparser = new XMLGrammarPreparser(symTab);
        pool = new XMLGrammarPoolImpl();
        preparser.setErrorHandler(ehandler); 
        preparser.registerPreparser(XMLGrammarDescription.XML_SCHEMA, null);
        preparser.setProperty(GRAMMAR_POOL, pool);
        preparser.setFeature(NAMESPACES_FEATURE, true);
        preparser.setFeature(VALIDATION_FEATURE, true);
        preparser.setFeature(SCHEMA_VALIDATION_FEATURE, true);
        preparser.setFeature(SCHEMA_FULL_CHECKING_FEATURE, true);
        
        // Parse the schema
        try {
            grammar = preparser.preparseGrammar(XMLGrammarDescription.XML_SCHEMA, stringToXIS(schemafile));
        }
        catch (IOException e) 
        {
            throw new Exception("preparseGrammar( ) threw exception " + e);
        }
        valResult = checkValidationResult(bastream.toString());
        
        return valResult; 
    }
    
    
    /** 
     Performs a validation on a set of Schematron Rules
     @param instancefile The xml instance file to be validated
     @param schematronFile The schematron file to be validated against 
     @return true if rules are valid, false if not.
     */ 
    public boolean validateSchematron(String instancefile, String schematronFile) 
    throws Exception
    {
        // First need to build instance file using SAXBuild, 
        // so the error meesage will be able to be expressed in xpath.
        buildInstanceForXpath(instancefile);
        
        boolean valresult = true;
        String result = null;
        
        SchematronValidator validator = null;
        try
        {
            validator = new SchematronValidator(schematronFile);
            
            result = validator.validate(instancefile);
            if((result != null)&& !("".equals(result))){
            valErrHandler.addSchematronResult(result);
            if (validator.getSchematronErrorStatus())
            {
                valErrHandler.setErrorStatus(true);
                valErrHandler.addErrorElement(validator.getSchematronRootElement());
            }
            }
        }
        catch (SAXException se)
        {
            valresult = false;
            throw new Exception("SchematronValidator threw SAXException: " + se.getMessage());
        }
        catch(ParserConfigurationException pe)
        {
            valresult = false;
            throw new Exception("SchematronValidator threw ParserConfigurationException: " + pe.getMessage());
        }
        catch(TransformerException te)
        {
            valresult = false;
            throw new Exception("SchematronValidator threw TransformerException: " + te.getMessage());
        }
        catch(IOException ioe)
        {
            valresult = false;
            throw new Exception("SchematronValidator threw IOException: " + ioe.getMessage());
        }
        
        
        if (!valresult)
        {
            valErrHandler.setErrorStatus(!valresult);
        }
        return valresult;	
    }
    
    /** 
     Performs a validation on a set of Schematron Rules 
     @param schematronFile The schematron file to validated against
     @param instancefile The xml instance file to be validated against
     @param prestylesheet The stylesheet to be used to transform schematron file to a stylesheet file
     @param props The properties to be passed to the validation process
     @return true if rules are valid, false if not.
     */ 
    public boolean validateSchematron(String schematronFile, String instancefile, String prestylesheet, Properties props) 
    throws Exception
    {
        // First need to build instance file using SAXBuild, 
        // so the error meesage will be able to be expressed in xpath.
        buildInstanceForXpath(instancefile);
        
        String result;
        boolean valresult = true;
        
        /* XXX to be coded  */
        SchematronValidator validator = null;
        try
        {
            validator = new SchematronValidator(schematronFile, prestylesheet, props);
            
            result = validator.validate(instancefile);
        }
        catch (SAXException se)
        {
            valresult = false;
            throw new Exception("SchematronValidator threw SAXException: " + se.getMessage());
        }
        catch(ParserConfigurationException pe)
        {
            valresult = false;
            throw new Exception("SchematronValidator threw ParserConfigurationException: " + pe.getMessage());
        }
        catch(TransformerException te)
        {
            valresult = false;
            throw new Exception("SchematronValidator threw TransformerException: " + te.getMessage());
        }
        catch(IOException ioe)
        {
            valresult = false;
            throw new Exception("SchematronValidator threw IOException: " + ioe.getMessage());
        }
        
        if (!valresult)
        {
            valErrHandler.setErrorStatus(!valresult);
        }
        return valresult;
    }
    
    
    
    /**
     validates the existing profile.
     @param instancefile The application profile for modification the base schema
     @param baseschemaloc The base schema used for validating against
     @param outputdir The Output directory that the modified schema/schematron will be output to
     @return true if schema/profile validates, false is validation fails.  
     */
    
    public boolean validateProfile(String instancefile, String baseschemaloc, String outputdir) throws Exception {
        // TODO Auto-generated method stub
        return false;
    }
    
    

    
    /**
     Returns the URL of the the file specified 
     @param filename The filename to get URL
     @return URL of the filename specified returned.
     */
    public java.net.URL getURL(String filename) 
    throws Exception
    {
        URL url = null;
        try {
            url = (new File(filename)).toURL();
        }
        catch (MalformedURLException e) {
            throw new Exception("toURL() threw exception" + e.getMessage()); 
        } 
        
        return url;
    }
    
    /**
     Returns the path (URI) to the last schema that was used as for validation. 
     @return path of schema, if no profile is loaded, then NULL is returned
     */
    public java.lang.String getFullSchemaName() 
    throws Exception
    {
        String schemaName = null;
        try {
            schemaName = (new File(schemaFile)).getCanonicalPath();
        }
        catch (IOException e) {
            throw new Exception("getCanonicalPath() threw exception: " + e.getMessage());
        }
        
        return schemaName;
    }
    
  
    
    /**
     Returns the name of the last schema that were used as for validation.
     @return schema name.
     */
    public java.lang.String getSchemaName() 
    {
        return schemaFile;
    }
    
    
    /**
     Returns the name of the last schematron rules that were used as for validation.
     @return Schematron name.
     */
    public java.lang.String getSchematronName() 
    {
        return schematronFile;
    }
    
    
    /**
     Returns the result of the last validation attempt.
     @return last validation result, false if no validation has been performed.
     */
    public boolean checkValidationResult() 
    {
        return valErrHandler.getErrorStatus();
    }
    
    /**
     Returns the result of the last validation attempt.
     @return last validation result, false if no validation has been performed.
     */
    public boolean checkValidationResult(String str) 
    {
        boolean returnValue = true;
        
        if (str.length() != 0) {
            returnValue = false;
        }
        return returnValue;
    }
    
    /**
     Returns details of validation. This is in XML.
     @return result of validation as a string
     */
    public String getValidationResult() 
    throws IOException
    {
        String result = "true";
        if (valErrHandler.getErrorStatus())
        {
            result = "false";
        }
        
        valErrHandler.setValidationResult(result);
        
        return ValidatorUtils.getJDOMElementAsString(valErrHandler.getRootElement());
    }
    
    /**
     Returns validation error handler.
     @return result of validation as a string
     */
    public ValidatorErrorHandler getValidationErrorHandler() 
    {
        return valErrHandler;
    }
    
    
    /**
     Returns the result of the last wellformed check.
     @return last well formed check, false if no validation has been performed.
     */
    public boolean getFormedResult() 
    {
        return formedResult;
    }
    
    
    /**
     Returns details of wellformed check. This is in XML.
     @return result of validation as a string
     */
    public java.lang.String wellFormedResult() 
    {
        return wellFormedResultString;
    }
    
    
    
    
    /* Method to format error messages in xml */
    private String formatSchemaValidationError() 
    {
        String xmlString;
        String s;
        String subString;
        StringBuffer sbuf;
        StringTokenizer tokenizer;
        boolean scanning = true;
        int start;
        int end;
        int innerStart;
        int innerEnd;
        int startOffset = 0;
        int errCnt = 1;
        String scratch;
        
        sbuf = new StringBuffer();
        s = bastream.toString();
        while (scanning) 
        {
            // Look for first occurrence of '[' and '\n' characters
            // indicating a parser error message
            start = s.indexOf("[", startOffset);
            end =  s.indexOf("\n", startOffset);
            
            if ((start == -1) && (end == -1)) 
            {
                // Reached the end of the error string
                scanning = false;
            }
            else {
                // Break down substring
                subString = s.substring(start, end);
                // Look for start of error level 
                innerStart = subString.indexOf("[");
                innerEnd = subString.indexOf("]");
                validationResultBuf.append("<element>\n"); 
                validationResultBuf.append("<number>" +errCnt++ 
                        +"</number>\n"); 
                validationResultBuf.append("<type>");
                validationResultBuf.append(subString.substring(innerStart+1, innerEnd));
                validationResultBuf.append("</type>\n");
                tokenizer = new StringTokenizer(subString, ":", false);
                // Discard the next three tokens 
                scratch = tokenizer.nextToken();
                scratch = tokenizer.nextToken();
                scratch = tokenizer.nextToken();
                // Extract the parser error message
                scratch = tokenizer.nextToken();
                validationResultBuf.append("<parserError>");
                validationResultBuf.append(scratch);
                validationResultBuf.append("</parserError>\n");
                // Extract the parser error message
                scratch = tokenizer.nextToken();
                validationResultBuf.append("<errmsg>");
                validationResultBuf.append(scratch);
                
                validationResultBuf.append("</errmsg>\n");
                validationResultBuf.append("</element>\n");
                
            }
            startOffset = end +1;
        }
        
        xmlString = validationResultBuf.toString();
        
        return xmlString;
    }
    
    // A private method to build instance file using SAXBuilder, if the instance file is well formed
    private boolean buildInstanceForXpath(String instancefile)
    throws Exception
    {
        // Check well formed first, if not, then should not continue for further validation.
        if (!checkFormed(instancefile))
            return false;
        
        if (isWellformed())
        {
            valErrHandler.buildInstanceDocument(instancefile);
        }
        
        return true;
        
    }
    
    private static XMLInputSource stringToXIS(String uri) 
    {
        return new XMLInputSource(null, uri, null);
    }

    /* (non-Javadoc)
     * @see org.TELCERT.validator.Validator#getFullProfileName()
     */
    public URL getFullProfileName() throws Exception {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.TELCERT.validator.Validator#getProfileName()
     */
    public String getProfileName() {
        // TODO Auto-generated method stub
        return null;
    }
    
    
    
    
}

