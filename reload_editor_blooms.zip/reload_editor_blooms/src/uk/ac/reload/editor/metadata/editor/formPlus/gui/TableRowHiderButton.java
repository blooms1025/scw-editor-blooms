/**
 *  RELOAD TOOLS
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Phillip Beauvoir
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Phillip Beauvoir
 *  e-mail:   p.beauvoir@bolton.ac.uk
 *
 *  Web:      http://www.reload.ac.uk
 *
 */
package uk.ac.reload.editor.metadata.editor.formPlus.gui;
import info.clearthought.layout.TableLayout;
import info.clearthought.layout.TableLayoutConstraints;

import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JComponent;

import uk.ac.reload.dweezil.util.DweezilUIManager;
import uk.ac.reload.editor.metadata.editor.formPlus.FormSubPanel;

/**
 * A Table layout row shrinking button
 */

public class TableRowHiderButton extends JButton {
    
    /**
     * The component to hide/show
     */
    private JComponent component;
    
    /**
     * State of component to hide/show
     */
    private boolean hidden = false;
    
    
    protected Icon iconSouth = DweezilUIManager.getIcon("uk/ac/reload/dweezil/resources/south.gif");
    protected Icon iconEast = DweezilUIManager.getIcon("uk/ac/reload/dweezil/resources/east.gif");
    
    /**
     * Constructor
     * @param component the JComponent to hide or show
     */
    public TableRowHiderButton(JComponent component) {
        this.component = component;
        setIcon(iconEast);
        hidden=true;
        addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showComponent(hidden);
            }
        });
    }
    
    /**
     * Show or hide the governed component
     * @param show if true will hide the component
     */
    public void showComponent(boolean show) {
        if(!(component.getParent() instanceof FormSubPanel))
            return;
        FormSubPanel parent = (FormSubPanel)component.getParent();
        
        if((TableLayout)parent.getLayout() != null){
        TableLayoutConstraints tlc =  ((TableLayout)parent.getLayout()).getConstraints(component);
        
        if(show) {
            setIcon(iconSouth);
            ((TableLayout)parent.getLayout()).setRow(tlc.row1, TableLayout.PREFERRED);
            hidden = !show;
        }else{
            setIcon(iconEast);
            ((TableLayout)parent.getLayout()).setRow(tlc.row1, 15);
            hidden = !show;
        }
        component.revalidate();
        component.repaint();
        }
    }
    
    
    /**
     * Set the UI
     */
    protected void setUI() {
        setBorder(BorderFactory.createEmptyBorder());
        setContentAreaFilled(false);
        setFocusPainted(false);
        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }
    
    /**
     * Update the UI
     */
    public void updateUI() {
        super.updateUI();
        setUI();
    }
    
    /* (non-Javadoc)
     * @see java.awt.Component#getPreferredSize()
     */
    public Dimension getPreferredSize() {
        return new Dimension(12, 12);
    }
    
    /* (non-Javadoc)
     * @see java.awt.Component#getMinimumSize()
     */
    public Dimension getMinimumSize() {
        return new Dimension(5, 5);
    }
    
    
}
