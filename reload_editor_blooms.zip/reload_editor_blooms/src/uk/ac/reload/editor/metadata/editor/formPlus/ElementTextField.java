/**
 *  RELOAD TOOLS
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Phillip Beauvoir
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Phillip Beauvoir
 *  e-mail:   p.beauvoir@bolton.ac.uk
 *
 *  Web:      http://www.reload.ac.uk
 *
 */
package uk.ac.reload.editor.metadata.editor.formPlus;

import java.awt.Color;
import java.awt.Component;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.AbstractDocument;
import javax.swing.text.DateFormatter;
import javax.swing.text.JTextComponent;

import org.jdom.Element;

import uk.ac.reload.editor.gui.widgets.NumberFieldWidget;
import uk.ac.reload.editor.gui.widgets.TextAreaWidget;
import uk.ac.reload.editor.gui.widgets.TextFieldWidget;
import uk.ac.reload.editor.gui.widgets.Widget;
import uk.ac.reload.editor.metadata.editor.formPlus.cv.SimpleFieldValidator;
import uk.ac.reload.editor.metadata.editor.formPlus.gui.DateFieldWidget;
import uk.ac.reload.editor.metadata.editor.formPlus.gui.DateTimeTypes;
import uk.ac.reload.editor.metadata.editor.formPlus.gui.FixedSizeFilter;
import uk.ac.reload.editor.metadata.xml.Metadata;
import uk.ac.reload.jdom.XMLDocumentListenerEvent;
import uk.ac.reload.moonunit.SchemaController;
import uk.ac.reload.moonunit.SchemaDocument;
import uk.ac.reload.moonunit.schema.SchemaElement;


/**
 * A Text Area widget.
 *
 * @author Phillip Beauvoir
 * @version $Id: ElementTextField.java,v 1.1 2007/02/13 16:03:33 rp_cherian Exp $
 */
public class ElementTextField extends ElementField implements DocumentListener {
    
    //the following string to be used when saving vCard values as they need to
    // preserve the line break/carriage returns
    private static String cdataBegin ="<![CDATA[";
    private static String cdataEnd ="]]>";
    /**
     * An internal flag
     */
    private boolean _allowNotification = true;
    
    /**
     * The suitable Component we shall use
     */
    private Widget _widget;
    
    /**
     * c'str
     * @param metadata
     * @param schemaElement
     */
    public ElementTextField(Metadata metadata, SchemaElement schemaElement) {
        super(metadata, schemaElement);
        
        //		Determine type of text field
        _widget = getMetadataTextFieldWidget(schemaElement);
        
        // Border
        ((JComponent) _widget).setBorder(BorderFactory
                .createLineBorder(Color.GRAY));
        
        setElement(metadata.getElement(getSchemaElement()));
        if (getElement() != null)
            setValue(getElement().getText());
        
        // We listen to Text Changes
        _widget.addDocumentListener(this);
        
        // We listen to Element changes
        metadata.addXMLDocumentListener(this);
        
    }
    
    /**
     * c'str
     * @param metadata
     * @param element
     * @param schemaElement
     */
    public ElementTextField(SchemaDocument metadata, Element element,
            SchemaElement schemaElement) {
        super(metadata, element, schemaElement);
        
        //		Determine type of text field
        _widget = getMetadataTextFieldWidget(schemaElement);
        
        // Border
        ((JComponent) _widget).setBorder(BorderFactory
                .createLineBorder(Color.GRAY));
        
        setElement(element);
        String elTxt = getElement().getText();
        //elTxt = (String)removeDuplicateWhitespace(elTxt);
        
        setValue(elTxt);
        
        // We listen to Text Changes
        _widget.addDocumentListener(this);
        
        // We listen to Element changes
        metadata.addXMLDocumentListener(this);
    }
    
    /**
     * c'str for creating a widget when schemanode is null
     * @param metadata parent document for this element
     * @param element	element of this gui widget
     */
    public ElementTextField(SchemaDocument metadata, Element element) {
        super(metadata, element);
       
        //get a default widget
        _widget = getDefaultWidget();
        
        // Border
        ((JComponent) _widget).setBorder(BorderFactory
                .createLineBorder(Color.GRAY));
        
        setElement(element);
        String elTxt = element.getText();
        //elTxt = (String)removeDuplicateWhitespace(elTxt);
        setValue(elTxt);
        
        // We listen to Text Changes
        _widget.addDocumentListener(this);
        
        // We listen to Element changes
        metadata.addXMLDocumentListener(this);
    }
    
    
    /**
     * @return A Text Widget suitable for the MD Form display
     */
    protected Widget getMetadataTextFieldWidget(SchemaElement schemaElement) {
        if (schemaElement == null)
            return getDefaultWidget();
        
        Widget component = null;
        
        SchemaController schemaController = getSchemaDocument()
        .getSchemaController();
        
        String widget_type = schemaController.getWidgetType(schemaElement
                .getXMLPath());
        String fieldType = schemaElement.getTypeName();
        if(schemaElement.getName().equals("vcard")){
           //FIXME
            // we need to have a routine that prefix/suffix CDATA to string
            // entered in this field - when CDATA is not there in the string
            //how
            
        }
        if (widget_type != null) {
            if (widget_type.equals("textpane")) {
                TextAreaWidget ta = new TextAreaWidget();
                component = ta;
                ta.setLineWrap(true);
                ta.setColumns(50);
            } else if (widget_type.equals("numberfield")) {
                component = new NumberFieldWidget();
                ((NumberFieldWidget) component).setColumns(30);
            }
        }else if ((fieldType != null )&&((fieldType.startsWith("date")) ||(fieldType.startsWith("time")) 
                							|| (fieldType.startsWith("gYear")) 
                							|| (fieldType.startsWith("gMonth"))
                							|| (fieldType.startsWith("gDay")))) {
            component = new DateFieldWidget();
            DateFormatter fmt = (DateFormatter) ((DateFieldWidget) component)
            													.getFormatter();
            DateTimeTypes.setDateTimeType(fmt, fieldType);
        /*else if ((fieldType != null )&&((fieldType.equalsIgnoreCase("datetimeType")) ||(fieldType.equals("dateTime")) )) {
            component = new DateFieldWidget();
            String type = schemaElement.getParent().getTypeName();
            if(fieldType.equals("dateTime")){
                DateFormatter fmt = (DateFormatter) ((DateFieldWidget) component)
                .getFormatter();
                fmt.setFormat(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss"));
                
            //}else if(((type != null )&&(type.equalsIgnoreCase("durationType")))) {
            }else if(fieldType.equals("time")){
             //if (((type != null )&&(type.equalsIgnoreCase("durationType")))) {
                DateFormatter fmt = (DateFormatter) ((DateFieldWidget) component)
                .getFormatter();
                fmt.setFormat(new SimpleDateFormat("hh:mm:ss"));
            }*/
            
        } else if(schemaElement.isStringType()){
            String value = schemaController.getFacetValue(schemaElement,
            "maxLength");
            if ((value != null) && (Integer.parseInt(value) > 80)){
                TextAreaWidget ta = new TextAreaWidget();
                component = ta;
                ta.setLineWrap(true);
                ta.setColumns(50);
            }else{
                component = getDefaultWidget();
            }
        }
        else{
            component = getDefaultWidget();
        }
        // this is to set the max length of the string
        if(schemaElement.isStringType()){
            String value = schemaController.getFacetValue(schemaElement,
            "maxLength");
            if (value != null) {
                if(component instanceof TextFieldWidget)
                    ((TextFieldWidget)component).setMaxLength(Integer.parseInt(value));
                else if(component instanceof TextAreaWidget){
                    ((TextAreaWidget)component).setMaxLength(Integer.parseInt(value));
                    AbstractDocument doc = (AbstractDocument) ((JTextComponent)component).getDocument();
                    doc.setDocumentFilter(new FixedSizeFilter(Integer.parseInt(value)));
                }
                
            }
        }
        return component;
    }
    
    /**
     * @return a default widget
     */
    private Widget getDefaultWidget() {
        TextFieldWidget textField = new TextFieldWidget();
        textField.setColumns(50);
        return textField;
    }
    
    /**
     * Clean up
     */
    public void destroy() {
        _widget.removeDocumentListener(this);
        getSchemaDocument().removeXMLDocumentListener(this);
    }
    
    /**
     * Get the value of this Widget
     * @return The value contained in the Widget
     */
    public String getValue() {
        return _widget.getTextValue();
    }
    
    /**
     * Set the value of the Widget
     * @param value The value
     */
    public void setValue(String value) {
        _allowNotification = false;
        _widget.setTextValue(value);
        _allowNotification = true;
    }
    
    /**
     * @return the Component that we're using
     */
    public Component getComponent() {
        return (Component) _widget;
    }
    //	=============================================================================
    //	=== These events are fired from the JTextArea when the textfield changes ====
    //	=============================================================================
    
    
    public void changedUpdate(DocumentEvent e) {
        if (_allowNotification)
            fireElementChanged();		
        
    }
    public void insertUpdate(DocumentEvent e) {
        if (_allowNotification)
            fireElementChanged();
        
    }
    public void removeUpdate(DocumentEvent e) {
        if (_allowNotification)
            fireElementChanged();
        
    }
    
    /**	 Returns a version of the input where all contiguous
     * whitespace characters are replaced with a single
     * space. Line terminators are treated like whitespace.
     * This example is taken from Java developers Almanac
     */
    public static CharSequence removeDuplicateWhitespace(CharSequence inputStr) {
        String patternStr = "\\s+";
        String replaceStr = " ";
        Pattern pattern = Pattern.compile(patternStr);
        Matcher matcher = pattern.matcher(inputStr);
        return matcher.replaceAll(replaceStr);
    }
    
    /* (non-Javadoc)
     * @see uk.ac.reload.editor.gui.FormField#cleanup()
     */
    public void cleanup() {
        
    }
    
    
    
    public void elementChanged(XMLDocumentListenerEvent event) {
        // TODO Auto-generated method stub
        super.elementChanged(event);
        // this was added by Roy to perform per field validation for Telcert
        if(event.getSource() == this) {
            SchemaElement schel = getSchemaElement();
            if((schel != null)&&(schel.isValue())){
             // add a field validator as well
             if(SimpleFieldValidator.isValid(getSchemaElement(), getElement().getText())){
                 ((JComponent) _widget).setForeground(Color.BLACK);
                 //((JComponent) _widget).getParent().repaint();
             }else{
                 //Border
                 ((JComponent) _widget).setForeground(Color.RED);
                 //((JComponent) _widget).getParent().repaint();
             }
             }
         
         return;
     }
    }
}

