/**
 *  RELOAD TOOLS
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Phillip Beauvoir
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Phillip Beauvoir
 *  e-mail:   p.beauvoir@bolton.ac.uk
 *
 *  Web:      http://www.reload.ac.uk
 *
 */
package uk.ac.reload.editor.metadata.editor.formPlus;

import java.awt.Color;
import java.awt.Component;

import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import org.jdom.Element;

import uk.ac.reload.editor.Messages;
import uk.ac.reload.editor.gui.widgets.Widget;
import uk.ac.reload.jdom.XMLDocument;
import uk.ac.reload.jdom.XMLDocumentListenerEvent;
import uk.ac.reload.moonunit.SchemaDocument;
import uk.ac.reload.moonunit.schema.SchemaElement;


/**
 * A Text Area widget.
 *
  */
public class ElementEmptyField extends ElementField  {
   private boolean _allowNotification = true;
   private Widget _widget;

    public ElementEmptyField(SchemaDocument metadata, Element element,
            SchemaElement schemaElement) {
        super(metadata, element);
        
        //		Determine type of text field
        _widget = getFieldWidget(schemaElement);
        
        // Border
        ((JComponent) _widget).setBorder(BorderFactory
                .createLineBorder(Color.GRAY));
        
        setElement(element);
        
        // We listen to Element changes
        metadata.addXMLDocumentListener(this);
    }
    
    
    

    /**
     * @return A Text Widget suitable for the MD Form display
     */
    protected Widget getFieldWidget(SchemaElement schemaElement) {

        Widget component = null;
        EmptyLabelWidget lw = new EmptyLabelWidget();
        lw.setText(Messages.getString("ElementEmptyField.0")); //$NON-NLS-1$
       
        //TextFieldWidget ta = new TextFieldWidget();
        //ta.setTextValue("<--Click to view - edit attribute for this empty element");
        //ta.setEnabled(false);
        component = lw;
       
       
        return component;
    }
    
    
    /* (non-Javadoc)
     * @see uk.ac.reload.editor.gui.FormField#getValue()
     */
    public String getValue() {
        // TODO Auto-generated method stub
        //return _widget.getTextValue();
        return null;
    }

    /* (non-Javadoc)
     * @see uk.ac.reload.editor.gui.FormField#setValue(java.lang.String)
     */
    public void setValue(String value) {
        // TODO Auto-generated method stub
    }

    /* (non-Javadoc)
     * @see uk.ac.reload.editor.gui.FormField#getComponent()
     */
    public Component getComponent() {
        // TODO Auto-generated method stub
        return (Component) _widget;
    }

    /* (non-Javadoc)
     * @see uk.ac.reload.editor.gui.FormField#cleanup()
     */
    public void cleanup() {
        // TODO Auto-generated method stub
        getSchemaDocument().removeXMLDocumentListener(this);
        
    }

    /* (non-Javadoc)
     * @see uk.ac.reload.jdom.XMLDocumentListener#elementAdded(uk.ac.reload.jdom.XMLDocumentListenerEvent)
     */
    public void elementAdded(XMLDocumentListenerEvent event) {
        // TODO Auto-generated method stub
         
    }

    /* (non-Javadoc)
     * @see uk.ac.reload.jdom.XMLDocumentListener#elementRemoved(uk.ac.reload.jdom.XMLDocumentListenerEvent)
     */
    public void elementRemoved(XMLDocumentListenerEvent event) {
        // TODO Auto-generated method stub
    }

    /* (non-Javadoc)
     * @see uk.ac.reload.jdom.XMLDocumentListener#elementChanged(uk.ac.reload.jdom.XMLDocumentListenerEvent)
     */
    public void elementChanged(XMLDocumentListenerEvent event) {
        // TODO Auto-generated method stub
     }

    /* (non-Javadoc)
     * @see uk.ac.reload.jdom.XMLDocumentListener#documentSaved(uk.ac.reload.jdom.XMLDocument)
     */
    public void documentSaved(XMLDocument doc) {
        // TODO Auto-generated method stub
        
           
    }

    /* (non-Javadoc)
     * @see javax.swing.event.DocumentListener#changedUpdate(javax.swing.event.DocumentEvent)
     */
    public void changedUpdate(DocumentEvent e) {
        // TODO Auto-generated method stub
        
    }

    /* (non-Javadoc)
     * @see javax.swing.event.DocumentListener#insertUpdate(javax.swing.event.DocumentEvent)
     */
    public void insertUpdate(DocumentEvent e) {
        // TODO Auto-generated method stub
         if (_allowNotification)
            fireElementChanged();
 
    }

    /* (non-Javadoc)
     * @see javax.swing.event.DocumentListener#removeUpdate(javax.swing.event.DocumentEvent)
     */
    public void removeUpdate(DocumentEvent e) {
        // TODO Auto-generated method stub
         if (_allowNotification)
            fireElementChanged();
    }
    /**
     * Tell the SchemaDocument that we changed
     */
    protected synchronized void fireElementChanged() {
        getSchemaDocument().changedElement(this, getElement());
    }
    
    public class EmptyLabelWidget extends JLabel implements Widget{

        /* (non-Javadoc)
         * @see uk.ac.reload.editor.gui.widgets.Widget#getTextValue()
         */
        public String getTextValue() {
            // TODO Auto-generated method stub
            return null;
        }

        /* (non-Javadoc)
         * @see uk.ac.reload.editor.gui.widgets.Widget#setTextValue(java.lang.String)
         */
        public void setTextValue(String text) {
            // TODO Auto-generated method stub
            
        }

        /* (non-Javadoc)
         * @see uk.ac.reload.editor.gui.widgets.Widget#insertTextValue(java.lang.String)
         */
        public void insertTextValue(String text) {
            // TODO Auto-generated method stub
            
        }

        /* (non-Javadoc)
         * @see uk.ac.reload.editor.gui.widgets.Widget#setMaxLength(int)
         */
        public void setMaxLength(int maxLength) {
            // TODO Auto-generated method stub
            
        }

        /* (non-Javadoc)
         * @see uk.ac.reload.editor.gui.widgets.Widget#isSingleLine()
         */
        public boolean isSingleLine() {
            // TODO Auto-generated method stub
            return false;
        }

        /* (non-Javadoc)
         * @see uk.ac.reload.editor.gui.widgets.Widget#addDocumentListener(javax.swing.event.DocumentListener)
         */
        public void addDocumentListener(DocumentListener dl) {
            // TODO Auto-generated method stub
            
        }

        /* (non-Javadoc)
         * @see uk.ac.reload.editor.gui.widgets.Widget#removeDocumentListener(javax.swing.event.DocumentListener)
         */
        public void removeDocumentListener(DocumentListener dl) {
            // TODO Auto-generated method stub
            
        }
        
    }
}

