/* **************************************************************************
	Common Validator -  Performs wellformedness checks of XML file and 
						validates XML Instances, Schemas and Schematron rules
	
	File :			  ValidatorUtils.java

	Copyright (c) 2004  The Open Group
Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to
deal in the Software without restriction, including without limitation the
rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
IN THE SOFTWARE.

Yuewen Chen
The Open Group, 
Thames Tower, 
37-45 Station Road,
Reading, 
Berkshire, 
RG1 1LX
United Kingdom 

***************************************************************************/

package uk.ac.reload.editor.metadata.editor.formPlus.cv;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;


public class ValidatorUtils
{
	/**

	  Get a JDOM element as a String.
	  @param root the JDOM root element
	  @exception IOException

	*/
	static public String getJDOMElementAsString (Element root)
											 throws  IOException
	{

		StringWriter sout = new StringWriter ();
		PrintWriter pout = new PrintWriter (new BufferedWriter (sout));
	
		// Output the rule to the string...
		XMLOutputter xout = new XMLOutputter ();
			
		/*
		xout.setIndent ("  ");
		xout.setNewlines (true);
		xout.setTextNormalize (true);
		*/
		xout.output (root, pout);
	
		pout.flush ();
		pout.close ();
	
		return sout.toString ();

	}

	/**

	  Save XML result as a file
	  @param root the JDOM root element
	  @exception IOException

	*/
	static public void saveJDOMElementAsFile (Element root, String filepath)
			 throws  IOException
	{

		PrintWriter xmlout = new PrintWriter(new BufferedWriter(new FileWriter(filepath)));
		Document doc = new Document(root);

		Format f = Format.getPrettyFormat();
		f.setTextMode (Format.TextMode.PRESERVE);
		// serialize it into xmlout
		XMLOutputter serializer = new XMLOutputter(f);
		serializer.output(doc, xmlout);
		xmlout.flush();
		xmlout.close();

	}



}
