/**
 *  RELOAD TOOLS
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Phillip Beauvoir
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Phillip Beauvoir
 *  e-mail:   p.beauvoir@bolton.ac.uk
 *
 *  Web:      http://www.reload.ac.uk
 *
 */
package uk.ac.reload.editor.metadata.editor.formPlus;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Iterator;
import java.util.List;

import javax.swing.AbstractAction;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JScrollPane;

import org.eclipse.xsd.XSDComplexTypeDefinition;
import org.eclipse.xsd.XSDElementDeclaration;

import uk.ac.reload.editor.EditorFrame;



/**
 * Dialog screen for selecting schema for creating new instances
 */
public class NewExtTypeSelectionDialog extends JDialog {
    
    
    private javax.swing.JButton okBtn;
    private javax.swing.JButton canclBtn;
    private javax.swing.JLabel topLbl;
    
    private JList typeList;
    private DefaultListModel model;
    private JScrollPane typeLstSP;

    String selectedTypeName;
    XSDElementDeclaration selectedType;
    //XSDTypeDefinition selectedType;
    List types;
     /**
     * Constructor
     */
    public NewExtTypeSelectionDialog(List elTypes){
        super(EditorFrame.getInstance(), " Select an extension Type", true);
        this.types = elTypes;
        setSize(210, 400);
        setResizable(false);
        getContentPane().setLayout(new GridBagLayout());
        
        // initialise gui compoents
        GridBagConstraints gridBagConstraints;
        
        topLbl = new JLabel("Select extension type from the list below:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        getContentPane().add(topLbl, gridBagConstraints);
        
        
 
        
        // initialise list
        model = new DefaultListModel();
        typeList = new JList(model);
        
        // add a double click for selection
        
        typeList.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                JList list = (JList)evt.getSource();
                if (evt.getClickCount() == 2) {          // Double-click
                    // Get item index
                    int index = typeList.locationToIndex(evt.getPoint());
                    selectedType = (XSDElementDeclaration)types.get(index);
                    //selectedType = (XSDTypeDefinition)types.get(index);
                    dispose();
                }
            }
        });
        
        int indx = 0;
        Iterator childItr = types.iterator(); 
        while (childItr.hasNext()) {
            XSDElementDeclaration elDeclrn = (XSDElementDeclaration) childItr.next();
            //XSDTypeDefinition elType = (XSDTypeDefinition) childItr.next();
            //if(elDeclrn.getType() instanceof XSDComplexTypeDefinition)
            //    model.add(indx++, elDeclrn.getQName());
            if(elDeclrn.getType() instanceof XSDComplexTypeDefinition)
                model.add(indx++, elDeclrn.getQName());
            
        }
        
        typeLstSP = new JScrollPane();
        typeLstSP.setViewportView(typeList);
        
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        getContentPane().add(typeLstSP, gridBagConstraints);

        okBtn = new JButton("OK");
        okBtn.addActionListener(new OKClick());
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(0, 2, 0, 2);
        getContentPane().add(okBtn, gridBagConstraints);
        
        canclBtn = new JButton("Cancel");
        canclBtn.addActionListener(new CancelClick());
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(0, 2, 0, 2);
        getContentPane().add(canclBtn, gridBagConstraints);
        

        setLocationRelativeTo(EditorFrame.getInstance());
        //setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
    }
    
    
    /**
     * Show the dialog
     * @return The user response either OK_OPTION or CANCEL_OPTION
     */
    public XSDElementDeclaration showDialog() {
        show();
        return selectedType;
    }
    
    
    
    /**
     * OK handler
     */
    private class OKClick extends AbstractAction {
        public void actionPerformed(ActionEvent e) {
//          Get the first selected item
            //selectedTypeName = (String)typeList.getSelectedValue();
            selectedType = (XSDElementDeclaration)types.get(typeList.getSelectedIndex());
            //selectedType = (XSDTypeDefinition)types.get(typeList.getSelectedIndex());
            dispose();
        }
    }
    
    /**
     * Cancel handler
     */
    private class CancelClick extends AbstractAction {
        public void actionPerformed(ActionEvent e) {
            selectedTypeName = null;
            dispose();
        }
    }
    
  
   
  
    /**
     * @return Returns the selectedType.
     */
    public String getSelectedTypeName() {
        return selectedTypeName;
    }
}
