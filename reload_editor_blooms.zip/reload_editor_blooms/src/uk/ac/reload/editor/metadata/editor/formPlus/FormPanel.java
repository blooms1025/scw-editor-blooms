/**
 *  RELOAD TOOLS
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Phillip Beauvoir
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Phillip Beauvoir
 *  e-mail:   p.beauvoir@bolton.ac.uk
 *
 *  Web:      http://www.reload.ac.uk
 *
 */
package uk.ac.reload.editor.metadata.editor.formPlus;

import java.awt.Point;
import java.awt.Rectangle;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;

import uk.ac.reload.dweezil.gui.GradientPanel;
import uk.ac.reload.editor.Messages;
import uk.ac.reload.editor.gui.AttributeEditor;
import uk.ac.reload.editor.gui.TipPanel;
import uk.ac.reload.editor.metadata.editor.formPlus.gui.ScrollPanel;
import uk.ac.reload.editor.metadata.xml.Metadata;

import com.brunchboy.util.swing.relativelayout.AttributeConstraint;
import com.brunchboy.util.swing.relativelayout.AttributeType;
import com.brunchboy.util.swing.relativelayout.DependencyManager;
import com.brunchboy.util.swing.relativelayout.RelativeLayout;

/**
 * Panel containing all embedded panels for displaying form view- 
 * attribute editor, tip panel and validation button and panel for elements
 *
 */
public class FormPanel extends GradientPanel {
    
    
    protected FormController controller;
    
    protected RelativeLayout layout;
    
    private TipPanel tipPanel;
    private AttributeEditor attrPanel;
    protected FormSubPanel mdPanel;
    private JScrollPane sp;
   
    
    public FormPanel() {
        layout = new RelativeLayout();
        setLayout(layout);
        controller = new FormController();
         
    }
    /**
     * set the document for the panel and add all inner panels;
     * @param md
     */
    public void setDocument(Metadata md) {
        //FIXME Added on 13/04 for error while importing/exporting embedded MD
        destroy();
        this.removeAll();
        controller.setMetadata(md, this);
        mdPanel = new FormSubPanel(md.getRootElement(), controller);
        initPanel();
        
        return;
    }
    
    
    /**
     * Initialise the form panel
     */
    protected void initPanel() {
      
        // this is for slow mouse movement
        ScrollPanel wrapper = new ScrollPanel();
        wrapper.add(mdPanel);
        
        // This is based on performance improvement tip posted at Java/Sun
        sp = new JScrollPane(wrapper);
        /*sp.getViewport().putClientProperty
        ("EnableWindowBlit", Boolean.TRUE);*/
        //add(new JScrollPane(wrapper), "main");
        add(sp, "main"); //$NON-NLS-1$
        
        layout.addConstraint(
                "main", //$NON-NLS-1$
                AttributeType.TOP,
                new AttributeConstraint(
                        DependencyManager.ROOT_NAME,
                        AttributeType.TOP, 25));
        layout.addConstraint(
                "main", //$NON-NLS-1$
                AttributeType.LEFT,
                new AttributeConstraint(
                        DependencyManager.ROOT_NAME,
                        AttributeType.LEFT));
        layout.addConstraint(
                "main", //$NON-NLS-1$
                AttributeType.RIGHT,
                new AttributeConstraint(
                        DependencyManager.ROOT_NAME,
                        AttributeType.RIGHT));
        layout.addConstraint(
                "main", //$NON-NLS-1$
                AttributeType.BOTTOM,
                new AttributeConstraint(
                        DependencyManager.ROOT_NAME,
                        AttributeType.BOTTOM, -150));
        
         
        // here add some temp panel to fill the gap ?        
        
        JPanel filler = new JPanel();
        add(filler, "filler"); //$NON-NLS-1$
        layout.addConstraint(
                "filler", //$NON-NLS-1$
                AttributeType.TOP,
                new AttributeConstraint(
                        DependencyManager.ROOT_NAME,
                        AttributeType.TOP));
        
        layout.addConstraint(
                "filler", //$NON-NLS-1$
                AttributeType.LEFT,
                new AttributeConstraint(
                        DependencyManager.ROOT_NAME,
                        AttributeType.LEFT));
        
        layout.addConstraint(
                "filler", //$NON-NLS-1$
                AttributeType.RIGHT,
                new AttributeConstraint(
                        DependencyManager.ROOT_NAME,
                        AttributeType.RIGHT));
        layout.addConstraint(
                "filler", //$NON-NLS-1$
                AttributeType.BOTTOM,
                new AttributeConstraint(
                        "main", //$NON-NLS-1$
                        AttributeType.TOP));
        
        //temporarily add a msg for prompting users to click on element to get more options
        JLabel optionTip = new JLabel(Messages.getString("FormPanel.11")); //$NON-NLS-1$
        filler.add(optionTip);
        
        // add a tip panel
        tipPanel = new TipPanel();
        add(tipPanel, "tip"); //$NON-NLS-1$
        layout.addConstraint(
                "tip", //$NON-NLS-1$
                AttributeType.LEFT,
                new AttributeConstraint(DependencyManager.ROOT_NAME, AttributeType.RIGHT, -400));
        layout.addConstraint(
                "tip", //$NON-NLS-1$
                AttributeType.RIGHT,
                new AttributeConstraint(DependencyManager.ROOT_NAME, AttributeType.RIGHT));
        layout.addConstraint(
                "tip", //$NON-NLS-1$
                AttributeType.TOP,
                new AttributeConstraint(
                        "main", //$NON-NLS-1$
                        AttributeType.BOTTOM));
        layout.addConstraint(
                "tip", //$NON-NLS-1$
                AttributeType.BOTTOM,
                new AttributeConstraint(
                        DependencyManager.ROOT_NAME,
                        AttributeType.BOTTOM));
        
        // Also add an attribute editor panel
        attrPanel = new AttributeEditor();
        add(attrPanel, "attr"); //$NON-NLS-1$
        layout.addConstraint(
                "attr", //$NON-NLS-1$
                AttributeType.LEFT,
                new AttributeConstraint(DependencyManager.ROOT_NAME, AttributeType.LEFT));
        layout.addConstraint(
                "attr", //$NON-NLS-1$
                AttributeType.RIGHT,
                new AttributeConstraint("tip", AttributeType.LEFT)); //$NON-NLS-1$
        layout.addConstraint(
                "attr", //$NON-NLS-1$
                AttributeType.TOP,
                new AttributeConstraint(
                        "main", //$NON-NLS-1$
                        AttributeType.BOTTOM));
        layout.addConstraint(
                "attr", //$NON-NLS-1$
                AttributeType.BOTTOM,
                new AttributeConstraint(DependencyManager.ROOT_NAME, AttributeType.BOTTOM));        
        
    }
    /**
     * @return return the Formcontroller
     */
    public FormController getController() {
        return controller;
    }
    
    /**
     * @return Returns the TipPanel.
     */
    public TipPanel getTipPanel() {
        return tipPanel;
    }
    /**
     * @return Returns the Attribute Panel.
     */
    public AttributeEditor getAttrPanel() {
        return attrPanel;
    }
    
    /**
     * Clean up
     */
    public void destroy() {
        if(sp != null)
            layout.removeLayoutComponent(sp);
        if(controller != null)
            controller.destroy();
        if(mdPanel != null)
            mdPanel.destroy();
        if(attrPanel != null)
            attrPanel.cleanup();
        
    }
    
    /** 
     * this is to scroll the panel to selected point
     * @param pt
     */
    public void scrollTo(final Point pt) {

        Runnable scroller = new Runnable() {
            public void run() {
                Rectangle viewRect=sp.getViewport().getViewRect();
                viewRect.x=pt.x;
                viewRect.y=pt.y;
                sp.getViewport().setViewPosition(new Point(viewRect.x,viewRect.y));               
             }
        };
        try {
            SwingUtilities.invokeLater(scroller);
        } catch (Exception e) {
            ;//System.out.println(e.getMessage());
        }
        
  
    }
    
}


