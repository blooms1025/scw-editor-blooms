/**
 *  RELOAD TOOLS
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Phillip Beauvoir
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Phillip Beauvoir
 *  e-mail:   p.beauvoir@bolton.ac.uk
 *
 *  Web:      http://www.reload.ac.uk
 *
 */
package uk.ac.reload.editor.metadata.editor.formPlus;

import java.util.ArrayList;
import info.clearthought.layout.TableLayout;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * A panel to display leaf nodes - A row of label and associated text
 *
 * 
 */
public class FieldPanel extends JPanel {
    TableLayout layout;

    int border = 3;

    double p = TableLayout.PREFERRED;

    ArrayList lbls = new ArrayList();

    ArrayList txtFlds = new ArrayList();

    /**
     * c'str with no text values
     * 
     * @param lbl
     */
    public FieldPanel(JComponent lbl) {
        super();

        double size[][] = { { border, 100, border, TableLayout.FILL, border }, //Columns
                { p } }; // Rows

        layout = new TableLayout(size);
        layout.setVGap(3);		// gap between rows

        setLayout(layout);
        add(lbl, "1,0");
        lbls.add(lbl);
        }

    /**
     * c'str with a text and label value
     * 
     * @param lbl
     * @param txtFld
     */   
    public FieldPanel(JComponent lbl, JComponent txtFld) {
        super();

        double size[][] = { { border, 100, border, TableLayout.FILL, border }, //Columns
                { p } }; // Rows

        layout = new TableLayout(size);
        layout.setVGap(3);		// gap between rows

        setLayout(layout);
        add(lbl, "1,0");
        add(txtFld, "3, 0");

        lbls.add(lbl);
        txtFlds.add(txtFld);

    }

    /**
     * Add a new label and text field in a row below the last row
     * @param lbl
     * @param txtFld
     */
    public void addRow(JComponent lbl, JComponent txtFld) {
        // add a row to the last one
        addRowAt(lbl, txtFld, layout.getNumRow());
      }

    /**
     * Delete a row containing the component from this panel
     * @param comp
     */
    public void deleteRow(JComponent comp) {
        int row = layout.getConstraints(comp).row1;
        if (row == 0) {
            if(txtFlds.size() >= 2){
            // In this case we can't delete the row as parent element label is there
            // so delete second row and copy textfield in place of first one
           
            layout.removeLayoutComponent((JComponent) txtFlds.get(1));
            layout.removeLayoutComponent((JComponent) lbls.get(1));
            layout.deleteRow(1);            
            Object tmptxtFld = txtFlds.remove(0);
            Object tmpLbl = lbls.remove(1);
            
            add((JComponent) txtFlds.get(0), "3," + Integer.toString(0));
            add((JComponent) tmpLbl, "1," + Integer.toString(1));
            add((JComponent) tmptxtFld, "3," + Integer.toString(1));
            }else if(txtFlds.size() == 1){
                layout.removeLayoutComponent((JComponent) txtFlds.get(0));
                txtFlds.remove(0);
            }
            
        } else {
            layout.removeLayoutComponent(comp);
            layout.removeLayoutComponent((JComponent) lbls.get(row));
            layout.deleteRow(row);
            lbls.remove(row);
            txtFlds.remove(row);
        }
       this.revalidate();

    }

    /**
     * remove the first row in a label - text value array
     * 
     * @param txt
     */
    public void addFirstRow(JComponent txt) {
        String txtLocn = "3,0";
        add(txt, txtLocn);        
        txtFlds.add(0, txt);
        this.revalidate();

    }
   
    /**
     * Add a new lable /text value pair at a specific line no
     * @param lbl
     * @param txt
     * @param rowNo
     */
    public void addRowAt(JComponent lbl, JComponent txt, int rowNo) {
        if (rowNo == 0) {
            moveFirstDown(lbl, txt);
            return;
        }
        layout.insertRow(rowNo, p);
        String lblLocn = "1," + Integer.toString(rowNo);
        String txtLocn = "3," + Integer.toString(rowNo);
        add(lbl, lblLocn);
        add(txt, txtLocn);

        lbls.add(rowNo, lbl);
        txtFlds.add(rowNo, txt);

        this.revalidate();

    }
/**
 * For moving rows of label/text pairs down depending on changes in other view
 * @param lblNew
 * @param txtNew
 */
    public void moveFirstDown(JComponent lblNew, JComponent txtNew) {
        if (txtFlds.size() >= 1) {
            layout.removeLayoutComponent((JComponent) txtFlds.get(0));
            String txtLocn = "3, 0";
            add(txtNew, txtLocn);
            Object txt0 = txtFlds.get(0);
            txtFlds.add(0, txtNew);

            // now insert a row 1
            layout.insertRow(1, p);
            String lblLocn = "1, 1";
            txtLocn = "3, 1";

            add(lblNew, lblLocn);
            lbls.add(1, lblNew);
            add((JComponent) txt0, txtLocn);
        } else {
            addFirstRow(txtNew);
        }
        this.revalidate();
    }

    /**
     * @return Returns the layout.
     */
    public TableLayout getTableLayout() {
        return layout;
    }
    
    /*
     *returns the first label of this label panel 
     */
    public JLabel getLabel(){
        if(!lbls.isEmpty() && (lbls.get(0) != null)){
            return (JLabel)lbls.get(0);
        }   
        return null;
    }
       
}