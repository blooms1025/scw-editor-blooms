/**
 *  RELOAD TOOLS
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Phillip Beauvoir
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Phillip Beauvoir
 *  e-mail:   p.beauvoir@bolton.ac.uk
 *
 *  Web:      http://www.reload.ac.uk
 *
 */
package uk.ac.reload.editor.metadata.editor.formPlus;

import info.clearthought.layout.TableLayout;

import java.awt.Container;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Vector;

import javax.swing.JComponent;
import javax.swing.JPanel;

import org.jdom.Element;
import org.jdom.JDOMException;

import uk.ac.reload.editor.gui.FormField;
import uk.ac.reload.editor.metadata.xml.Metadata;
import uk.ac.reload.jdom.XMLDocument;
import uk.ac.reload.jdom.XMLDocumentListener;
import uk.ac.reload.jdom.XMLDocumentListenerEvent;
import uk.ac.reload.jdom.XMLPath;
import uk.ac.reload.moonunit.schema.SchemaElement;
import uk.ac.reload.moonunit.schema.SchemaException;
import uk.ac.reload.moonunit.schema.SchemaModel;
import uk.ac.reload.moonunit.schema.utils.SchemaUtils;

/**
 * Form Controller listen to xml document event and control actions
 * This can hold an Element or an Attribute.
 *
 */

public class FormController implements XMLDocumentListener {
    
    Metadata md;
    JPanel mainPanel;
    private Hashtable formComps = new Hashtable();
    
   /**
     * Keep track of fields so we can release listeners and clean up
     */
    private Vector _fields = new Vector();
    
    public FormController() {
        super();
    }
    /**
     * 
     * @param file
     * @throws JDOMException
     * @throws SchemaException
     * @throws IOException
     */
    public FormController(File file, JPanel mainPanel)
    throws JDOMException, SchemaException, IOException {
        super();
        setMetadata(new Metadata(file), mainPanel);
        
    }
    /**
     * get the metadata that is currently being displayed
     * @return SchemaDocument
     */
    public Metadata getMetadata() {
        return md;
    }
    
    /**
     * set the metadata that is currently being displayed
     * @param metadata
     */
    public void setMetadata(Metadata metadata, JPanel mainPanel) {
        md = metadata;
        this.mainPanel = mainPanel; 
        md.addXMLDocumentListener(this);
        
    }
    /**
     * handles element additions to the xml instances
     * @param event XMLDocument events
     */
    
    public void elementAdded(XMLDocumentListenerEvent event) {
        
        if (event.getSource() == this) {
            return;
        }
        Element element = event.getElement();
        addElement(element);
    }
    /**
     * support function for element addition
     * @param element
     */
    protected void addElement(Element element) {
        SchemaElement schElParent = null;
        Element parent = element.getParentElement();
        XMLPath elPath = XMLPath.getXMLPathForElement(element);
        // get the no of chldren that this element can have
        
        SchemaElement schEl = (SchemaElement) (md.getSchemaController().getSchemaNode(elPath));
        
        if (schEl == null) {           
            schEl = SchemaUtils.getSchemaElementfromPath(md
                    .getSchemaController().getSchemaModel().getRootElement(),
                    elPath);
            if (schEl != null) {
                schElParent = (SchemaElement) schEl.getParent();
            } else {
                System.err.println("\t schema element us STILL NULL IN FORM CONTROLLER " + element.getName());
                return;
            }           
        }else{
             schElParent = (SchemaElement) schEl.getParent();
        }
        
        
       
        int childCount = schEl.getChildCount();
        boolean hasLangChild = schEl.hasChild("langstring");
        
        if((schEl.getChildWild() != null) && (!schEl.isResolvedWildCard())){
            SchemaModel sm = md.getSchemaController().getSchemaModel();
            
            //File schFile = new File(sm.getSchemaFile().getParent(), schemaLocns);
            String schemaFolderPath = sm.getSchemaFile().getParent();
            
            SchemaUtils.addWildCardSchemaElements(schEl, element, schemaFolderPath);
        }
      
        // case 1. if it is langstring child, check its parent - must be a
        // FieldPanel
        // append this langstring to that
        if((element.getName().equals("langstring")&& (schElParent.getChildren().length == 1))){
            Element gParent = (Element)element.getParent().getParent();
            JComponent gPanel = getFormComponent(gParent.hashCode());
            JComponent pPanel = getFormComponent(parent.hashCode());
            int indx = indexofChild(parent, element);
            FormSubPanel fsp = (FormSubPanel) gPanel;
            fsp.appendStringFieldAt(element, (FieldPanel)pPanel, indx);
            // open shrunk row             
             fsp.getHider().showComponent(true);
         }
        //TODO
        else if(schEl.isMixedType()){
            FormSubPanel sp = new FormSubPanel(element, this);            
            JComponent pPanel = getFormComponent(parent.hashCode());
            int indx = indexofChild(parent, element)+2;
           
            addFormComponent(element.hashCode(), sp);
            // this has to be a form sub panel
            FormSubPanel fsp = (FormSubPanel) pPanel;
            TableLayout layout = fsp.getTableLayout();
            layout.insertRow(indx, TableLayout.PREFERRED);
            // now add a string value field
             FormField mdField = new ElementTextOnlyField(getMetadata(), element, schEl);
            if(mdField != null){
                mdField.setValue(element.getTextTrim());
                 sp.add(mdField.getComponent(), "1,1, 1, 1");
                 sp.lastRow++; 
            }
            String rowLocn =  "1" + "," + Integer.toString(indx);
            fsp.add(sp, rowLocn);
            // open shrunk row
            fsp.getHider().showComponent(true);
            pPanel.revalidate();
            
        }
        //TODO
          else if(schEl.isEmptyType()){
               // case 2. if it is value field just add field after getting the parent form subpanel
              if(!(childCount > 0) ){
                  //System.out.println("adding empty as a FIELD");
            JComponent pPanel = getFormComponent(parent.hashCode());
            int indx = indexofChild(parent, element)+2;
            ((FormSubPanel) pPanel).addEmptyValueField(element,schEl, indx);
            	pPanel.revalidate();
              }else{
                  JComponent pPanel = getFormComponent(parent.hashCode());
                  int indx = indexofChild(parent, element)+2;
                  FormSubPanel sp = new FormSubPanel(element, this);
                  addFormComponent(element.hashCode(), sp);
                  // this has to be a form sub panel
                  FormSubPanel fsp = (FormSubPanel) pPanel;
                  TableLayout layout = fsp.getTableLayout();
                  layout.insertRow(indx, TableLayout.PREFERRED);
                  String rowLocn =  "1" + "," + Integer.toString(indx);
                  fsp.add(sp, rowLocn);
                  // open shrunk row
                  fsp.getHider().showComponent(true);
                  pPanel.revalidate();
              }
        }       
        else if((schEl.isComplexType() && ((childCount ==1) && (hasLangChild)))
                ||(schEl.isValueType() && !(childCount > 0))){
            //case 3. if it is not value field and has one lang string child but is of complex type
            // create a field only
            JComponent pPanel = getFormComponent(parent.hashCode());
            int indx = indexofChild(parent, element)+2;
            ((FormSubPanel) pPanel).addValueField(element,schEl, indx);
            pPanel.revalidate();
        //}else if((schEl.isComplexType())&& (schElParent.getChildren().length  >= 1)){
        } else if(schEl.isComplexType()){
            //case 4. if it is not value field and has children >1, then add formSubpanel to parent subpanel
            // create a new sub panel and insert it in the appropriate row in main panel
            JComponent pPanel = getFormComponent(parent.hashCode());
            int indx = indexofChild(parent, element)+2;
            FormSubPanel sp = new FormSubPanel(element, this);
            addFormComponent(element.hashCode(), sp);
            // this has to be a form sub panel
            FormSubPanel fsp = (FormSubPanel) pPanel;
            TableLayout layout = fsp.getTableLayout();
            layout.insertRow(indx, TableLayout.PREFERRED);
            String rowLocn =  "1" + "," + Integer.toString(indx);
            fsp.add(sp, rowLocn);
            // open shrunk row
            fsp.getHider().showComponent(true);
            pPanel.revalidate();
        }else{
            // case 6. All other types - what could that be ?
            System.err.println("Skipping element in form controller: " + element.getName());
           
               
        }
   
    }
    
  
    /**
     * Implements element removal from containing panel when elements are
     * removed
     * 
     * @param event
     *            XMLDocumentListenerEvent
     */
    public void elementRemoved(XMLDocumentListenerEvent event) {
        TableLayout layout =null;
        Element element = event.getElement();
        JComponent comp = getFormComponent(element.hashCode());
        if((comp == null ) && (element.getName().equalsIgnoreCase("langstring"))){
            element = (Element)element.getParent();
            if(element == null){
                return;
            }
            comp = getFormComponent(element.hashCode());
            // still not found then return ?
            if(comp == null)
                return;
        }
        if(comp == null){
            return;
        }
        Container parent = comp.getParent();
        if(parent instanceof FormSubPanel){
            layout = ((FormSubPanel) parent).getTableLayout();
            if(layout.getConstraints(comp) != null){
                int row = layout.getConstraints(comp).row1;
                layout.removeLayoutComponent(comp);
                layout.deleteRow(row);
                ((JPanel) parent).revalidate();
                removeFormComponent(element.hashCode());
            }
        }else if(parent instanceof FieldPanel){
            FieldPanel fp = (FieldPanel) parent;
            fp.deleteRow(comp);
            removeFormComponent(element.hashCode());
            return;
        }else{
            System.err.println("Unable to remove components in the view for " + element.getName());            
            return;
        }
   
    }
    
    /**
     * 
     */
    public void elementChanged(XMLDocumentListenerEvent event) {
       // do nothing for now - form fields to listen to this
        
    }
 
    
    /**
     * 
     */
    public void documentSaved(XMLDocument doc) {
      // do nothing for now
    }
    
    /**
     * Return the index of a child element in the parent element
     * @param parent
     * @param child
     * @return index
     */
    public static int indexofChild(Element parent, Element child) {
        if ((child == null) || (parent == null)) {
            return -1;
        }

        Object[] childs = parent.getChildren().toArray();
        for (int i = 0; i < childs.length; i++) {
            Element childEl = (Element)childs[i];
             if (childEl.equals(child)){
                return i;
            }
        }

        return -1;
    }
    

    /**
     * check whether the element is mandatory(minoccurs=1)
     * @param element
     * @return true if mandatory
     */
    public boolean isMandatory(Element element){
        XMLPath elPath = XMLPath.getXMLPathForElement(element);
        SchemaElement schEl = (SchemaElement) (md.getSchemaController().getSchemaNode(elPath));
        // true if the minOccurs is one (?)
        if(schEl != null){
            return schEl.getMinOccurs() == 1;
        }else{
            return false;
        }
    }
    
   
    /**
     * Select the component for an element from element hashkey
     * @param key
     * @return jcomponent
     */
    public JComponent getFormComponent(int key) {
        return (JComponent)formComps.get(new Integer(key));
    }
    
    /**
     * add components in the panel to hashmap
     * @param key
     * @param comp
     */
    public void addFormComponent(int key, JComponent comp) {
        formComps.put(new Integer(key), comp);
    }
    
    
    /**
     * remove components from hashtable
     * @param key
     */
    
    public void removeFormComponent(int key){
        formComps.remove(new Integer(key));
    }
    
    /**
     * remove listeners and clear hashtable
     */
    
    public void destroy() {
        for (int i = 0; i < _fields.size(); i++) {
            ElementField mdField = (ElementField) _fields.get(i);
            mdField.destroy();
        }
        _fields.clear();
        if(md !=null)
            md.removeXMLDocumentListener(this);
        formComps.clear();
    }
    
    /**
     * @return Returns the mainPanel.
     */
    public JPanel getMainPanel() {
        return mainPanel;
    }
    
    /**
     * @param mainPanel The mainPanel to set.
     */
    public void setMainPanel(JPanel mainPanel) {
        this.mainPanel = mainPanel;
    }
    
    /**
     * @return Returns the _fields.
     */
    public Vector get_fields() {
        return _fields;
    }
    
   /**
    * 
    * @return
    */ 
    
    public Metadata getMd() {
        return md;
    }
}