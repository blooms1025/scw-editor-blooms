/**
 *  RELOAD TOOLS
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Phillip Beauvoir
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Phillip Beauvoir
 *  e-mail:   p.beauvoir@bolton.ac.uk
 *
 *  Web:      http://www.reload.ac.uk
 *
 */
package uk.ac.reload.editor.metadata.editor.formPlus;

import info.clearthought.layout.TableLayout;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import org.eclipse.xsd.XSDSchema;
import org.jdom.Element;
import org.jdom.Namespace;

import uk.ac.reload.dweezil.menu.DweezilMenuEvent;
import uk.ac.reload.dweezil.menu.MenuAction;
import uk.ac.reload.dweezil.menu.ProxyAction;
import uk.ac.reload.dweezil.util.DweezilUIManager;
import uk.ac.reload.editor.datamodel.ElementBinding;
import uk.ac.reload.editor.gencontent.xml.GenMDSchemaController;
import uk.ac.reload.editor.genschema.GenSchemaController;
import uk.ac.reload.editor.gui.FormField;
import uk.ac.reload.editor.menu.Menu_Edit;
import uk.ac.reload.editor.metadata.editor.formPlus.gui.TableRowHiderButton;
import uk.ac.reload.jdom.XMLPath;
import uk.ac.reload.jdom.XMLUtils;
import uk.ac.reload.moonunit.SchemaController;
import uk.ac.reload.moonunit.SchemaDocument;
import uk.ac.reload.moonunit.schema.SchemaElement;
import uk.ac.reload.moonunit.schema.SchemaException;
import uk.ac.reload.moonunit.schema.SchemaModel;
import uk.ac.reload.moonunit.schema.SchemaNode;
import uk.ac.reload.moonunit.schema.utils.SchemaUtils;
import uk.ac.reload.moonunit.vocab.VocabularyList;

/**
 * Panel that is embedded in the main form panel. This is used for elements with
 * more than one child element elements with langstring fields are added as
 * label with text value in a row
 *  
 */
public class FormSubPanel extends JPanel {

    /**
     * Left Indent factor
     */
    private static int INDENT = 15;

    private static double BORDER = 15;

    private static double FILLWIDTH = TableLayout.FILL;

    private static double PREFDHEIGHT = TableLayout.PREFERRED;

    private static JPopupMenu popupMenu;

    private static ProxyDeleteHandler _deleteHandler;

    private static Menu_Edit _editMenu;

    private TableLayout layout;

    protected int lastRow = 1;

    private FormController fc;

    private Element top_el;

    private TableRowHiderButton hider;

    private JLabel panelLbl;

    static {
        popupMenu = new JPopupMenu();
    }

    /**
     * A container panel to display elements that have many child elements
     * 
     * @param root
     * @param controller
     */
    public FormSubPanel(Element root, FormController controller) {
        super();
        top_el = root;
        double size[][] = { { BORDER, FILLWIDTH, BORDER }, //Columns
                { BORDER, PREFDHEIGHT, BORDER } }; // Rows

        layout = new TableLayout(size);
        setLayout(layout);
        layout.setVGap(1);
        if (fc == null) {
            fc = controller;
        }
        setOpaque(false);
        addMouseListener(new PanelMouseListener());

        if (root.isRootElement()) {
            double rootSize[][] = { { BORDER, FILLWIDTH, 50 }, //Columns
                    { BORDER, PREFDHEIGHT, 3 } }; // Rows

            layout = new TableLayout(rootSize);
            setLayout(layout);
        }

        //	Add the Group Label
        if ((root.getName() != null)) {
            setLabel(root);
        }

        //the followin for checking whether this is mixed type content
        // if so add some extra fields ?
        //added on 11/03/2006
        XMLPath rootPath = XMLPath.getXMLPathForElement(root);
        SchemaElement rootNode =  (SchemaElement) fc.getMetadata()
        							.getSchemaController().getSchemaNode(rootPath);
        if ((rootNode != null) && (rootNode.isMixedType())) {
            FormField mdField = new ElementTextOnlyField(fc
                    .getMetadata(), root, rootNode);

            if (mdField != null) {
                mdField.setValue(root.getTextTrim());
                add(mdField.getComponent(), "1,1, 1, 1");
                //lastRow++;
            }
            
        }
        // end mixed type stuff
        //FIXME
            
        fc.addFormComponent(root.hashCode(), this);
        // Get the Children
        List children = root.getChildren();
        if (children != null) {
            Iterator iterator = children.iterator();

            while (iterator.hasNext()) {
                Element child = (Element) iterator.next();
                XMLPath cPath = XMLPath.getXMLPathForElement(child);
                SchemaElement schemaNode = (SchemaElement) fc.getMetadata()
                        .getSchemaController().getSchemaNode(cPath);
                SchemaElement schemaParentElement = null;

                if (schemaNode == null) {
                    // first check whether the schema node is null
                    //if so try to get it for wild card extensions
                    String nsURI = child.getNamespaceURI();

                    //System.out.println(" schema node null " + nsURI + " name
                    // " + child.getName());

                    Element parentElement = child.getParentElement();
                    XMLPath pXPath = XMLPath
                            .getXMLPathForElement(parentElement);
                    //schemaParentElement = (SchemaElement) fc.getMetadata()
                    //								.getSchemaController().getSchemaNode(pXPath);
                    schemaParentElement = SchemaUtils.getSchemaElementfromPath(
                            fc.getMetadata().getSchemaController()
                                    .getSchemaModel().getRootElement(), pXPath);

                    if ((schemaParentElement != null)
                            && (SchemaUtils.getExtURItoSchemaMap().get(nsURI) != null)) {
                        XSDSchema extSchema = (XSDSchema) SchemaUtils
                                .getExtURItoSchemaMap().get(nsURI);
                        schemaParentElement.attachExtSchemaElement(extSchema,
                                child.getName());

                    } else {
                        // here try to load the extension schema using extension
                        // schema namespace and schema location
                        //System.out.println("ATTEMPTING TO LOAD SCHEMA From
                        // element NS and location");
                        Namespace childNS = child.getNamespace();
                        if (childNS != null) {
                            String extLocn = XMLUtils.getSchemaLocation(child
                                    .getDocument(), childNS);

                            if ((extLocn != null) && (!extLocn.equals(""))
                                    && (extLocn.indexOf("http") == -1)) {

                                File schemaFile = new File(fc.getMetadata()
                                        .getFile().getParent(), extLocn);
                                if (schemaFile.isFile() && schemaFile.exists()) {
                                    SchemaModel newSM = new SchemaModel();
                                    XSDSchema extSchema = null;
                                    try {
                                        extSchema = newSM
                                                .loadSchema(schemaFile);
                                        //System.out.println("\t schema loaded
                                        // " + nsURI + " locn " + extLocn);
                                    } catch (IOException e) {
                                        // TODO Auto-generated catch block
                                        e.printStackTrace();
                                    } catch (SchemaException e) {
                                        // TODO Auto-generated catch block
                                        e.printStackTrace();
                                    }
                                    if (extSchema != null) {
                                        schemaParentElement
                                                .attachExtSchemaElement(
                                                        extSchema, child
                                                                .getName());
                                        SchemaUtils.getExtURItoSchemaMap().put(
                                                childNS.getURI(), extSchema);
                                        SchemaUtils.getExtURItoPrefxMap().put(
                                                childNS.getURI(),
                                                childNS.getPrefix());

                                    }
                                }
                            }
                        }

                    }

                    if (schemaParentElement != null) {
                        //System.out.println("\t schema node NOOOT null " +
                        // nsURI + " name " + schemaParentElement.getName());
                        schemaNode = schemaParentElement.getChild(child
                                .getName(), child.getNamespace());

                    }

                }

                if (schemaNode != null) {

                    boolean hasLangChild = schemaNode.hasChild("langstring");
                    int childCount = schemaNode.getChildCount();
                    schemaParentElement = (SchemaElement) schemaNode
                            .getParent();
                    if ((child.getName().endsWith("metadata"))
                            && (cPath.toString().indexOf("vdex") != 1)) {
                        //this is for vdex metadata elements as they are to be
                        // opened in a seperate dialog
                        controller.addElement(child);
                    } else if (((child.getName().equals("langstring") && (schemaParentElement
                            .getChildCount() == 1)))) {
                        // do something here
                        addValueField(child, ++lastRow);
                        //System.out.println(" adding a lang string element wth
                        // one child " + child.getName());
                    } /*else if (schemaNode.isMixedType()) { // TODO for mixed
                                                           // type
                        //System.out.println(" adding a mixed mode child " +
                        // child.getName());
                        //System.out.println(" \tFOMRSUBPANEL this is mixed
                        // type " + cPath.getPath());
                        FormSubPanel sp = new FormSubPanel(child, fc);
                        //this is for collapsed view of the panel
                        layout.insertRow(++lastRow, 15);
                        String rowLocn = "1" + "," + Integer.toString(lastRow);
                        FormField mdField = new ElementTextOnlyField(fc
                                .getMetadata(), child, schemaNode);

                        if (mdField != null) {
                            mdField.setValue(child.getTextTrim());
                            sp.add(mdField.getComponent(), "1,1, 1, 1");
                            sp.lastRow++;

                        }
                        add(sp, rowLocn);

                    } */else if (schemaNode.isEmptyType()) {
                        //do something here
                        if (!(schemaNode.getChildCount() > 0)) {
                            //System.out.println("adding empty as a field");
                            addEmptyValueField(child, schemaNode, ++lastRow);
                        } else {
                            //System.out.println("adding empty as a panel");
                            FormSubPanel sp = new FormSubPanel(child, fc);
                            //this is for collapsed view of the panel
                            layout.insertRow(++lastRow, 15);
                            String rowLocn = "1" + ","
                                    + Integer.toString(lastRow);
                            add(sp, rowLocn);
                        }

                    } else if ((schemaNode.isComplexType() && ((childCount == 1) && (hasLangChild)))
                            || (schemaNode.isValueType())) {
                        //System.out.println(" adding a value mode child 2 nd
                        // time" + child.getName());
                        addValueField(child, schemaNode, ++lastRow);
                    } else if (schemaNode.isComplexType()) {
                        // This is for cases where child of this element is not
                        // a lang
                        // string child
                        //System.out.println(" adding a complex mode child " +
                        // child.getName());
                        FormSubPanel sp = new FormSubPanel(child, fc);
                        //this is for collapsed view of the panel
                        layout.insertRow(++lastRow, 15);
                        String rowLocn = "1" + "," + Integer.toString(lastRow);
                        add(sp, rowLocn);
                    } else {
                        //System.err.println("Skipping element in form view: "
                        // + child.getName());
                        ;
                    }

                } else {                    
                    if (child.getChildren().size() > 0) {
                        FormSubPanel sp = new FormSubPanel(child, fc);
                        //this is for collapsed view of the panel
                        layout.insertRow(++lastRow, 15);
                        String rowLocn = "1" + "," + Integer.toString(lastRow);
                        add(sp, rowLocn);
                    } else {                        
                        addValueField(child, ++lastRow);
                    }
                }
            }
        }

    }

    /**
     * @return Returns the hider.
     */
    public TableRowHiderButton getHider() {
        return hider;
    }

    /**
     *  
     */
    public void destroy() {

    }

    /**
     * set the label for this element sub panel and add listeners/hider button
     * 
     * @param element
     */
    public void setLabel(Element element) {
        panelLbl = new JLabel(element.getName());
        XMLPath elPath = XMLPath.getXMLPathForElement(element);
        String fname = fc.getMetadata().getSchemaController()
                .getElementFriendlyName(elPath);
        if (fname != null) {
            panelLbl.setText(fname);
        }
        if (fc.isMandatory(element)) {
            panelLbl.setFont(DweezilUIManager.boldFont12);
        }
        panelLbl.setOpaque(true);

        panelLbl.setBorder(new EmptyBorder(0, 3, 0, 0));
        // this is for updating the element tip/highlight/update attribute
        // editor
        panelLbl.addMouseListener(new LabelListener(element, elPath));

        // this is for shrinking the panel/table row using the south/east button
        // - hider button
        hider = new TableRowHiderButton(this);
        if (!element.isRootElement()) {
            add(hider, "0,0");
            add(panelLbl, "1,0, 1, 0");
        } else {
            add(panelLbl, "0,0, 1, 0");
        }
    }

    /**
     * add a value field to the parent panel as a row
     * 
     * @param child
     * @param schemaNode
     */

    public void addValueField(Element child, SchemaElement schemaNode) {
        if ((schemaNode.hasChild("langstring") && (schemaNode.getChildren().length == 1))) {
            addStringValueField(child, ++lastRow);
        } else {
            addValueField(child, ++lastRow);
        }
    }

    public void addValueField(Element child, SchemaElement schemaNode, int indx) {
        if ((schemaNode.hasChild("langstring") && (schemaNode.getChildren().length == 1))) {
            addStringValueField(child, indx);
        } else {
            addValueField(child, indx);
        }
    }

    /**
     * add an empty field for Complex schema elements with empty content
     * 
     * @param child
     * @param schemaNode
     */

    public void addEmptyValueField(Element child, SchemaElement schemaNode,
            int indx) {
        FormField mdField;
        FieldPanel fp;
        final XMLPath childPath = XMLPath.getXMLPathForElement(child);
        // Add a Label
        JLabel lbl = createLblComponent(child, childPath);

        mdField = new ElementEmptyField(fc.getMetadata(), child, schemaNode);
        if (mdField == null) {
            return;
        }
        // this is for removing listeners later
        fc.get_fields().add(mdField);
        mdField.getComponent().addFocusListener(
                new FieldListener(child, childPath));
        fp = new FieldPanel(lbl, (JComponent) mdField.getComponent());
        fc.addFormComponent(child.hashCode(), fp);
        layout.insertRow(indx, PREFDHEIGHT); // increment row only here once

        String rowLocn = "1" + "," + Integer.toString(indx);
        add(fp, rowLocn);
        this.revalidate();
        return;
    }

    /**
     * add a value field to the parent panel as a row
     * 
     * @param child
     * @param indx
     */

    public void addValueField(Element child, int indx) {
        ElementField mdField;
        FieldPanel fp;
        final XMLPath childPath = XMLPath.getXMLPathForElement(child);
        // Add a Label
        JLabel lbl = createLblComponent(child, childPath);
        //Ask the Model for the Widget to use
        mdField = createWidget(child);

        if (mdField == null) {
            return;
        }
        // this is for removing listeners later
        fc.get_fields().add(mdField);
        mdField.getComponent().addFocusListener(
                new FieldListener(child, childPath));

        fp = new FieldPanel(lbl, (JComponent) mdField.getComponent());
        fc.addFormComponent(child.hashCode(), fp);
        layout.insertRow(indx, PREFDHEIGHT);

        String rowLocn = "1" + "," + Integer.toString(indx);
        add(fp, rowLocn);
        this.revalidate();
        return;

    }

    /**
     * Add an element with String value
     * 
     * @param child
     * @param indx
     */

    public void addStringValueField(Element child, int indx) {
        ElementField mdField;
        FieldPanel fp;
        final XMLPath childPath = XMLPath.getXMLPathForElement(child);
        // Add a Label
        JLabel lbl = createLblComponent(child, childPath);

        Element langStringChild = child.getChild("langstring", child
                .getNamespace());

        // Ask the Model for the Widget to use
        if (langStringChild != null) {
            mdField = createWidget(langStringChild);
        } else {
            fp = new FieldPanel(lbl);
            layout.insertRow(indx, PREFDHEIGHT);
            String rowLocn = "1" + "," + Integer.toString(indx);
            add(fp, rowLocn);
            fc.addFormComponent(child.hashCode(), fp);
            //System.err.println("Unable to get field component
            // addStringValueField(Element child, int indx)");
            return;
        }
        //		Add this component

        // this is for removing listeners later
        fc.get_fields().add(mdField);
        fp = new FieldPanel(lbl, (JComponent) mdField.getComponent());
        //add focus listener to the field

        XMLPath lchildPath = XMLPath.getXMLPathForElement(langStringChild);
        mdField.getComponent().addFocusListener(
                new FieldListener(langStringChild, lchildPath));

        layout.insertRow(indx, PREFDHEIGHT);
        fc.addFormComponent(child.hashCode(), fp);
        //will this help locating the first item

        fc.addFormComponent(langStringChild.hashCode(), (JComponent) mdField
                .getComponent());

        String rowLocn = "1" + "," + Integer.toString(indx);
        add(fp, rowLocn);

        List children = child.getChildren();
        // now try to add langstring children in case there are more than one
        if ((children.size() > 1)) {
            // add rest of the elements - not the first as it is added
            for (int i = 1; i < children.size(); i++) {
                appendStringFieldAt((Element) children.get(i), fp, i);
            }
        }
        this.revalidate();
        return;
    }

    /**
     * Create a label component to display next to editable fields
     * 
     * @param child
     * @param childPath
     * @return label component
     */

    public JLabel createLblComponent(Element child, XMLPath childPath) {
        JLabel lbl = new JLabel(child.getName());
        lbl.setBorder(new EmptyBorder(0, INDENT, 0, 0));
        String fname = fc.getMetadata().getSchemaController()
                .getElementFriendlyName(childPath);

        if (fname != null) {
            lbl.setText(fname);
        }
        if (fc.isMandatory(child)) { // for elements that are mandatory -
                                     // hightligh somehow
            lbl.setFont(DweezilUIManager.boldFont11);
        }

        // this is for updating the attribubtes of this element if any &
        // activate popup menu
        lbl.addMouseListener(new LabelListener(child, childPath));

        return lbl;
    }

    /**
     * this is for adding additional row to a panel containing key/string value
     * pairs mainly used for langstring elements with multiple langstring child
     * elements to a parent
     * 
     * @param langEl
     * @param parentPanel
     * @param indx
     */

    public void appendStringFieldAt(Element langEl, FieldPanel parentPanel,
            int indx) {
        ElementField mdField;

        final XMLPath langchildPath = XMLPath.getXMLPathForElement(langEl);
        // Ask the Model for the Widget to use
        mdField = createWidget(langEl);
        if (mdField != null) {
            //this is for removing listeners later
            fc.get_fields().add(mdField);
            fc.addFormComponent(langEl.hashCode(), (JComponent) mdField
                    .getComponent());
            // add focus listener to the field
            mdField.getComponent().addFocusListener(
                    new FieldListener(langEl, langchildPath));

            if ((indx == 0)
                    && (((Element) langEl.getParent()).getChildren().size() == 1)) {
                parentPanel.addFirstRow((JComponent) mdField.getComponent());
                return;
            }

            //add label for the rest
            JLabel dummyLbl = new JLabel("...");
            dummyLbl.setHorizontalAlignment(SwingConstants.RIGHT);
            // this for adding listener to label - highlight, attribute update
            // and popup
            dummyLbl.addMouseListener(new LabelListener(langEl, langchildPath));

            // add to the parent panel
            parentPanel.addRowAt(dummyLbl, (JComponent) mdField.getComponent(),
                    indx);
        } else {
            System.err
                    .println("Unable to get field component appendStringFieldAt(Element langEl, FieldPanel parentPanel, int indx)");
            return;
        }
    }

    /**
     * This is to be called from FormController for adding langstring fields
     * when more than one langstring child elements are present per element
     * 
     * @param child
     * @param indx
     */

    public void addLangStringField(final Element child, int indx) {
        // first get the parent component of this langstring element
        JComponent pComp = fc.getFormComponent(child.getParent().hashCode());

        if (pComp instanceof FieldPanel) {
            appendStringFieldAt(child, (FieldPanel) pComp, indx);
        } else {
            System.err.println("\nUnable to add a field");
            return;
        }
    }

    /**
     * Creates an widget to display in the form view for the element
     * 
     * @param el
     *            jdom element of the xml document to be displayed
     * @return Field widget to display in the form view
     */
    public ElementField createWidget(Element el) {

        XMLPath path = new XMLPath(XMLPath.getXMLPathForElement(el));

        SchemaNode schemaNode = fc.getMetadata().getSchemaController()
                .getSchemaNode(path);
        // Element
        if (schemaNode instanceof SchemaElement) {
            return createElementWidget((SchemaElement) schemaNode, el);
        } else if ((schemaNode == null) && (el != null)) {
            return new ElementTextField(fc.getMetadata(), el);
        } else {
            return null;
        }

    }

    /**
     * Create a widget bound to an Element
     * 
     * @param schemaElement
     *            The Element to Widgetise
     * @return A MD_Field
     */
    protected ElementField createElementWidget(SchemaElement schemaElement,
            Element el) {
        // Do we have a vocabulary?
        SchemaController sc = fc.getMetadata().getSchemaController();
        VocabularyList vList = sc.getVocabularyList(schemaElement);

        // If we do, make a combo box
        if (vList != null) {
            ElementComboBox ecb = new ElementComboBox(fc.getMetadata(), schemaElement, el,
                    vList);
           
            //((JComboBox)ecb.getComponent()).addMouseListener(new ComboBoxListener(el, 
            //                schemaElement, fc.getMetadata()));
            ((JComboBox)ecb.getComponent()).addItemListener(new ComboBoxListener(el, 
                    schemaElement, fc.getMetadata()));
            return ecb;
            //return new ElementComboBox(fc.getMetadata(), schemaElement, el,
            //        vList);
            
        }
        //Else make a Text Field
        return new ElementTextField(fc.getMetadata(), el, schemaElement);
    }

    /**
     * @param controller
     */
    public void setFormController(FormController controller) {
        fc = controller;
    }

    /**
     * @return Returns the layout.
     */
    public TableLayout getTableLayout() {
        return layout;
    }

    /**
     * Check to see if we have triggered the popup menu.
     * 
     * @param e
     *            The MouseEvent that has been triggered.
     */
    protected void checkPopupTrigger(MouseEvent e) {
        if (e.isPopupTrigger()) {
            updateMenus(top_el);
            popupMenu.show(this, e.getX(), e.getY());
        }
    }

    /**
     * Clear any popup or other menus
     */
    protected static synchronized void clearMenus() {
        popupMenu.removeAll();

    }

    /**
     * Update the menus according to the selected node on the tree. This has to
     * be synchronized so different threads don't access it at the same time
     *  
     */
    protected synchronized void updateMenus(Element el) {
        /**
         * The Edit menu which we will use
         */
        _editMenu = new Menu_Edit();

        // Clear the deck regardless
        clearMenus();

        if (el == null) {
            return;
        }

        /**
         * The Proxy Delete Handler
         */

        // New Delete Handler
        _deleteHandler = new ProxyDeleteHandler(_editMenu.actionDelete);
        _deleteHandler.update(el);
        popupMenu.add(_deleteHandler.getMenuAction());

        // Get SchemaElement
        XMLPath path = XMLPath.getXMLPathForElement(el);
        SchemaElement schemaElement = (SchemaElement) fc.getMetadata()
                .getSchemaController().getSchemaNode(path);
        SchemaController controller = fc.getMetadata().getSchemaController();
        // If the Schema Element has Children display them in the menu
        if (schemaElement != null && schemaElement.hasChildren()) {
            popupMenu.addSeparator();
            SchemaElement[] children = schemaElement.getChildren();
            for (int i = 0; i < children.length; i++) {
                SchemaElement childSchemaElement = children[i];
                // the following is just to make sure that we only add normal
                // elements here not extension schema elements
                Action_AddChildElement actionAddElement = new Action_AddChildElement(
                        el, childSchemaElement);
                popupMenu.add(actionAddElement);

            }
            // here try to add wildcard extension if specified

            if ((controller instanceof GenSchemaController)
                    || (controller instanceof GenMDSchemaController)) {
                if ((schemaElement.getChildWild() != null)) {

                    List extNSURIs = schemaElement.getChildWild()
                            .getNsURIList();

                    if (extNSURIs.size() > 0) {
                        //TODO removed by Roy on 6/2/2006 to make things work
                        // with in a generic way
                        // not just for generic schema instance handling
                        for (Iterator iter = extNSURIs.iterator(); iter
                                .hasNext();) {
                            String extnsURI = (String) iter.next();

                            XSDSchema smSchema = (XSDSchema) (SchemaUtils
                                    .getExtURItoSchemaMap().get(extnsURI));
                            String extRoot = (String) (SchemaUtils
                                    .getExtURItoRootMap().get(extnsURI));
                            //String prefx = (String) (SchemaUtils
                            //       .getExtURItoPrefxMap().get(extnsURI));

                            if (smSchema != null) {
                                if (!schemaElement.isResolvedWildCard()) {
                                    List lst = new ArrayList();
                                    if((extRoot !=null)&& !("".equals(extRoot))){
                                        lst = schemaElement
                                        .attachExtSchemaElement(smSchema, extRoot);
                                    }else{
                                     lst = schemaElement
                                            .attachExtSchemaElement(smSchema);
                                    }
                                    //List lst = schemaElement
                                    //        .attachExtSchemaElement(smSchema);
                                    if (lst != null) {
                                        for (Iterator iterator = lst.iterator(); iterator
                                                .hasNext();) {
                                            SchemaElement childSchemaElement = (SchemaElement) iterator
                                                    .next();
                                            Action_AddChildElement actionAddElement = new Action_AddChildElement(
                                                    el, childSchemaElement);
                                            popupMenu.add(actionAddElement);
                                            //System.out
                                            //.println(" adding from the
                                            // generic controller 1");
                                        }
                                    }
                                }

                            } else {
                                //System.out
                                //       .println(" NOT adding in the generic
                                // controller 1 as schema was null");
                            }
                        }
                        // }
                    }
                }
            }

            // now here check for the extension type and then add option to add
            // them
            // first get the namespace from the complex type of the element -
            // element -
            // xsdelementdeclaration-xsdcomplextypedefinition-getnamespaceString
            // use namespaceURI to look up in a hash table and get the schema
            // then get the new schema root element
        } else if ((controller instanceof GenSchemaController)
                || (controller instanceof GenMDSchemaController)) {
            if ((schemaElement != null)
                    && ("anyType".equals(schemaElement.getBaseTypeName()))) {

                String[] extNSURI = SchemaUtils.getExtElNS(schemaElement
                        .getElementDecl());
                //System.out.println("\n\nI AM IN THE UNKNOWN LAND \t namespace
                // URI " +extNSURI[0] );
                if (!("".equals(extNSURI[0]))) {
                    for (int i = 0; i < extNSURI.length; i++) {

                        XSDSchema smSchema = (XSDSchema) (SchemaUtils
                                .getExtURItoSchemaMap().get(extNSURI[i]));
                        //String prefx = (String) (SchemaUtils
                        //        .getExtURItoPrefxMap().get(extNSURI[i]));
                        
                        String extRoot = (String) (SchemaUtils
                                .getExtURItoRootMap().get(extNSURI[i]));
                        if (smSchema != null) {
                            if (!schemaElement.isResolvedWildCard()) {
                                List lst = new ArrayList();
                                if((extRoot !=null)&& !("".equals(extRoot))){
                                    lst = schemaElement
                                    .attachExtSchemaElement(smSchema, extRoot);
                                }else{
                                 lst = schemaElement
                                        .attachExtSchemaElement(smSchema);
                                }
                                for (Iterator iterator = lst.iterator(); iterator
                                        .hasNext();) {
                                    SchemaElement childSchemaElement = (SchemaElement) iterator
                                            .next();
                                    Action_AddChildElement actionAddElement = new Action_AddChildElement(
                                            el, childSchemaElement);
                                    popupMenu.add(actionAddElement);
                                    //System.out
                                    //        .println(" adding from the generic
                                    // controller 2");

                                }
                            }

                        }
                    }
                }

            } else if (schemaElement == null) {

                schemaElement = SchemaUtils.getSchemaElementfromPath(fc
                        .getMetadata().getSchemaController().getSchemaModel()
                        .getRootElement(), path);
                if ((schemaElement != null)) {
                    popupMenu.addSeparator();
                    SchemaElement[] children = schemaElement.getChildren();
                    //System.out.println("\n \t Adding new found extended
                    // children" );
                    for (int i = 0; i < children.length; i++) {
                        SchemaElement childSchemaElement = children[i];
                        Action_AddChildElement actionAddElement = new Action_AddChildElement(
                                el, childSchemaElement);
                        popupMenu.add(actionAddElement);
                    }
                }
            }
        }

    }

    /**
     * This is for popup menu when panels containing a parent element is clicked
     */
    class PanelMouseListener extends MouseAdapter {

        public void mousePressed(MouseEvent evt) {
            checkPopupTrigger(evt);
        }

        public void mouseReleased(MouseEvent evt) {
            checkPopupTrigger(evt);

        }
    }

    /**
     * This is for popup menu when element labels are clicked
     */
    class LabelListener extends MouseAdapter {

        private XMLPath elPath;

        private Element element;

        //  this element binding is used for updating attribute editor panel
        private ElementBinding eb;

        /**
         *  
         */
        LabelListener(Element el, XMLPath path) {
            elPath = path;
            element = el;

        }

        /**
         * update tip panel and highlight the label
         */
        public void mouseEntered(MouseEvent evt) {
            ((JLabel) evt.getSource()).setForeground(Color.lightGray);
            ((FormPanel) (fc.getMainPanel())).getTipPanel().setTip(
                    fc.getMetadata().getSchemaController(),
                    (SchemaElement) fc.getMetadata().getSchemaController()
                            .getSchemaNode(elPath));
        }

        public void mouseExited(MouseEvent evt) {
            ((JLabel) evt.getSource()).setForeground(Color.black);
            ((FormPanel) (fc.getMainPanel())).getTipPanel().clear();

        }

        /**
         * update attribute editor
         */
        public void mouseClicked(java.awt.event.MouseEvent evt) {
            eb = new ElementBinding(element, (SchemaElement) fc.getMetadata()
                    .getSchemaController().getSchemaNode(elPath), fc
                    .getMetadata());
            ((FormPanel) (fc.getMainPanel())).getAttrPanel().setElementBinding(
                    eb);
            fc.getMainPanel().repaint();
        }

        /**
         * update popup menu
         */
        public void mousePressed(MouseEvent evt) {
            if (evt.isPopupTrigger()) {
                updateMenus(element);
                popupMenu.show(((JLabel) evt.getSource()), evt.getX(), evt
                        .getY());
            }
        }

        public void mouseReleased(MouseEvent evt) {
            if (evt.isPopupTrigger()) {
                updateMenus(element);
                popupMenu.show(((JLabel) evt.getSource()), evt.getX(), evt
                        .getY());
            }
        }
    }

    /**
     * This is for focus listeners
     */
    class FieldListener extends FocusAdapter {

        private Element element;

        private XMLPath path;

        //  this element binding is used for updating attribute editor panel
        private ElementBinding eb;

        private SchemaElement schemaElement;

        /**
         *  
         */
        FieldListener(Element el, XMLPath path) {
            element = el;
            this.path = path;

        }

        /**
         * update attribute panel
         */
        public void focusGained(FocusEvent e) {
            schemaElement = (SchemaElement) fc.getMetadata()
                    .getSchemaController().getSchemaNode(path);

            if (schemaElement == null) {
                schemaElement = SchemaUtils.getSchemaElementfromPath(fc
                        .getMetadata().getSchemaController().getSchemaModel()
                        .getRootElement(), path);
            }

            eb = new ElementBinding(element, schemaElement, fc.getMetadata());
            ((FormPanel) (fc.getMainPanel())).getTipPanel().setTip(
                    fc.getMetadata().getSchemaController(), schemaElement);
            ((FormPanel) (fc.getMainPanel())).getAttrPanel().setElementBinding(
                    eb);
            fc.getMainPanel().repaint();
        }

        public void focusLost(FocusEvent e) {
            ((FormPanel) (fc.getMainPanel())).getTipPanel().clear();
            fc.getMainPanel().repaint();
        }
    }
    
    /**
     * An Item listener to change the attribute panel to show attributes for
     * combo box items
     * 
     * @author Roy P Cherian
     * 
     * TODO
     */
    class ComboBoxListener implements ItemListener{

        private ElementBinding _eb;

        ComboBoxListener(Element el, SchemaElement schEl, SchemaDocument schDoc) {
            _eb = new ElementBinding(el, schEl, schDoc);

        }

        public void itemStateChanged(ItemEvent arg0) {
            // TODO Auto-generated method stub
            ((FormPanel) (fc.getMainPanel())).getAttrPanel().setElementBinding(
                    _eb);

        }      
    }

    // ==============================================================================
    //ADD HANDLER
    //==============================================================================

    /**
     * An Action Class that allows us to add a new Child Element to a Parent
     * Element There will be some validity checks.
     */
    class Action_AddChildElement extends AbstractAction {

        /**
         * The parent element
         */
        private Element parentElement;

        /**
         * The schema element of the child element that we want to add
         */
        private SchemaElement childSchemaElement;

        /**
         * The name that will be displayed on the Menu
         */
        private String name;

        /**
         * Constructor
         * 
         * @param parentElement
         *            the parent element
         * @param childSchemaElement
         *            the schema element of the child element that we want to
         *            add
         */
        Action_AddChildElement(Element parentElement,
                SchemaElement childSchemaElement) {
            this.parentElement = parentElement;
            this.childSchemaElement = childSchemaElement;

            // Set up name that will be displayed on the Menu
            name = fc.getMetadata().getSchemaController()
                    .getElementFriendlyName(childSchemaElement.getXMLPath());
            if (name == null) {
                name = childSchemaElement.getName();
            }
            putValue(Action.NAME, "Add " + name);

            // Set Enabled according to whether we are allowed to add this child
            setEnabled(fc.getMetadata().canAddElement(parentElement,
                    childSchemaElement));
        }

        /**
         * Add action to be performed
         * 
         * @param e
         *            the ActionEvent
         */
        public void actionPerformed(ActionEvent e) {
            //System.out.println(" adding elements in ActionADD " +
            // childSchemaElement.getName());
            fc.getMetadata().addElementBySchemaUndoable(FormSubPanel.this,
                    parentElement, childSchemaElement, true);
        }
    }

    //==============================================================================
    //DELETE HANDLER
    //==============================================================================
    /**
     * Delete Element Proxy Action
     */
    class ProxyDeleteHandler extends ProxyAction {

        /**
         * The element to delete
         */
        private Element element;

        /**
         * Constructor
         * 
         * @param proxyMenuAction
         *            the MenuAction
         */
        ProxyDeleteHandler(MenuAction proxyMenuAction) {
            super(proxyMenuAction);
        }

        public void update(Element elmnt) {
            this.element = elmnt;
            if (fc.getMetadata().canDeleteElement(element)) {
                setEnabled(true);
                addListener();
            } else {
                clear();
            }
        }

        /**
         * The delete element action to be performed when the menu item is
         * selected
         * 
         * @param event
         *            the DweezilMenuEvent
         */
        public void menuActionPerformed(DweezilMenuEvent event) {
            fc.getMetadata().deleteElementUndoable(FormSubPanel.this, element);
        }

    }

    /**
     * @return Returns the panelLbl.
     */
    public JLabel getPanelLbl() {
        return panelLbl;
    }

    /**
     * 
     * @return form controller
     */
    public FormController getFormController() {
        return fc;
    }

}