/**
 *  RELOAD TOOLS
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Phillip Beauvoir
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Phillip Beauvoir
 *  e-mail:   p.beauvoir@bolton.ac.uk
 *
 *  Web:      http://www.reload.ac.uk
 *
 */
package uk.ac.reload.editor.metadata.editor.formPlus;

import java.awt.Component;
import java.io.File;
import java.io.IOException;
import java.util.StringTokenizer;

import javax.swing.JDialog;
import javax.swing.JOptionPane;

import org.jdom.Document;
import org.jdom.Element;

import uk.ac.reload.editor.EditorFrame;
import uk.ac.reload.editor.Messages;
import uk.ac.reload.editor.genschema.GenSchemaController;
import uk.ac.reload.editor.metadata.editor.formPlus.cv.CommonValidatorCRT;
import uk.ac.reload.editor.metadata.editor.formPlus.cv.ValidnResultDialog;
import uk.ac.reload.jdom.XMLUtils;
import uk.ac.reload.moonunit.SchemaDocument;

/**
 * Document validator for jdom document using schema
 */
public class CVDocValidator {

    
    File tmpDocFile;

    String validnMessage = Messages.getString("CVDocValidator.0"); //$NON-NLS-1$

   

    // this is the dialog that displays the validation message
    private static JDialog dialog;
    
    
      
    /**
     * this function is used to validate any XML document 
     */
    public static void validateXMLDoc(SchemaDocument schemaDoc){
        
        File tmpDocFile;
        String validnMessage =""; //$NON-NLS-1$
        CommonValidatorCRT cv = new CommonValidatorCRT();
        try {
           
            if ((schemaDoc.getFile() != null) && (schemaDoc.getFile().exists())) {

            
                    schemaDoc.saveDocument();
                    tmpDocFile = schemaDoc.getFile();
                    
            
            } else {
                tmpDocFile = File.createTempFile("validnInstance", ".xml"); //$NON-NLS-1$ //$NON-NLS-2$
                tmpDocFile.deleteOnExit();
                XMLUtils.write2XMLFile(schemaDoc.getDocument(), tmpDocFile);
            }
            
            
            String schemaLocn =""; //$NON-NLS-1$
            if(schemaDoc.getSchemaController().getSchemaFile() != null){
                schemaLocn = schemaDoc.getSchemaController().getSchemaFile()
                    .getAbsolutePath();
            	
            }else if(schemaDoc.getSchemaController() instanceof GenSchemaController){
                schemaLocn = ((GenSchemaController)schemaDoc.getSchemaController()).getSchemaUrl();
            }
           
            String[] schemaLocns = { schemaLocn };
            
            // added for getting schema location value from the instance schema location attribute
            String schLocnStr = schemaDoc.getDocument().getRootElement().getAttributeValue(XMLUtils.XSI_SchemaLocation, XMLUtils.XSI_Namespace);
            if((schLocnStr !=null)&& !("".equals(schLocnStr))){ //$NON-NLS-1$
                
                StringTokenizer parser = new StringTokenizer(schLocnStr);
                int noOfLocn = parser.countTokens()/2;
                String[] locns = new String[noOfLocn];
                while (parser.hasMoreTokens()) {
                    parser.nextToken();
                    String schemaLoc = parser.nextToken();
                    locns[--noOfLocn] = schemaLoc;
                    //System.out.println(" location is "  + schemaLoc);                   
                    
               }
               
                schemaLocns = locns;
                //System.out.println(" Getting new schema location string from instance " + schLocnStr);
            }
            
           
            try {
                cv.validateInstance(tmpDocFile.getAbsolutePath(), schemaLocns);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(EditorFrame.getInstance(),
                        e.getMessage(),
                        Messages.getString("CVDocValidator.6"), //$NON-NLS-1$
                        JOptionPane.ERROR_MESSAGE);
                return;
            }
            String valResult = cv.getValidationResult();
            //System.out.println("Validation result : \n"  + valResult);
            Document result = XMLUtils.readXMLString(cv.getValidationResult());
            if (result.getRootElement().getChildren("element").size() == 0) { //$NON-NLS-1$
                String message = Messages.getString("CVDocValidator.8"); //$NON-NLS-1$
                JOptionPane.showMessageDialog(EditorFrame.getInstance(), message);
                
            } else {
                //System.out.println("Validation result : \n"  );
                validnMessage = Messages.getString("CVDocValidator.9"); //$NON-NLS-1$
                // get the first error element
                Element errEl = result.getRootElement().getChild("element"); //$NON-NLS-1$

                if (errEl != null) {
                    Element pathEl = errEl.getChild("xpath"); //$NON-NLS-1$
                    String pathStr = pathEl.getTextTrim();
                    Element msgEl = errEl.getChild("errmsg"); //$NON-NLS-1$
                }
              
                if (result != null) {
                    if ((dialog != null) && (dialog.isShowing())) {
                        dialog.dispose();
                    }
                    dialog = ValidnResultDialog.getDialog(result
                            .getRootElement());
                    dialog.show();
                } else {
                    String message = Messages.getString("CVDocValidator.13"); //$NON-NLS-1$
                    JOptionPane.showMessageDialog(EditorFrame.getInstance(),
                            message);
                }
            }

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }      
        }
    
    
    /**
     * this function is used to validate any XML document 
     */
    public static void validateXMLDoc(SchemaDocument schemaDoc,Component comp, FormController fc){
        
        File tmpDocFile;
        String validnMessage =""; //$NON-NLS-1$
        CommonValidatorCRT cv = new CommonValidatorCRT();
        try {
           
            if ((schemaDoc.getFile() != null) && (schemaDoc.getFile().exists())) {
                	schemaDoc.saveDocument();
                    tmpDocFile = schemaDoc.getFile();
            
            } else {
                tmpDocFile = File.createTempFile("validnInstance", ".xml"); //$NON-NLS-1$ //$NON-NLS-2$
                tmpDocFile.deleteOnExit();
                XMLUtils.write2XMLFile(schemaDoc.getDocument(), tmpDocFile);
            }
            
           
            
            
            String schemaLocn =""; //$NON-NLS-1$
            String schemaParent=""; //$NON-NLS-1$
            //          System.out.println(" location original is "  + schemaLocn + " parent is " + schemaParent);
            String[] schemaLocns = {""};
            if(schemaDoc.getSchemaController().getSchemaFile() != null){
                schemaLocn = schemaDoc.getSchemaController().getSchemaFile()
                    .getAbsolutePath();
                schemaLocns = new String[] { schemaLocn };
            	
            }else if(schemaDoc.getSchemaController() instanceof GenSchemaController){
                schemaLocn = ((GenSchemaController)schemaDoc.getSchemaController()).getSchemaUrl();
                // added for getting schema location value from the instance schema location attribute
                // so that multiple schema locations can be loaded
                String schLocnStr = schemaDoc.getDocument().getRootElement().getAttributeValue(XMLUtils.XSI_SchemaLocation, XMLUtils.XSI_Namespace);
                if((schemaDoc.getFile() != null) && (schLocnStr !=null)&& !("".equals(schLocnStr))){                 //$NON-NLS-1$
                    StringTokenizer parser = new StringTokenizer(schLocnStr);
                    int noOfLocn = parser.countTokens()/2;
                    if ((noOfLocn > 0)) {
                        String[] locns = new String[noOfLocn];
                        while (parser.hasMoreTokens()) {
                            parser.nextToken();
                            String schemaLoc = parser.nextToken();
                            locns[--noOfLocn] = schemaLoc;
                            /*
                             * //locns[--noOfLocn] = schemaParent + schemaLoc; //
                             * the above was commented out to get schema locations
                             * that might contain // reference to schema url on web
                             * etc if(schemaLoc.indexOf("http") == -1){
                             * locns[--noOfLocn] = schemaLoc; //locns[--noOfLocn] =
                             * schemaParent + schemaLoc; }else{ locns[--noOfLocn] =
                             * schemaLoc; }
                             */
                            //System.out.println(" location is from tokenizer iss "
                            // + (schemaParent + schemaLoc));
                        }
                        schemaLocns = locns;
                    }
                    
                }
            }
            if(schemaLocn.indexOf("http") == -1){ //$NON-NLS-1$
                int indx = schemaLocn.lastIndexOf(File.separatorChar);
                schemaParent = schemaLocn.substring(0, indx+1);
            }
            
            

            try {
                cv.validateInstance(tmpDocFile.getAbsolutePath(), schemaLocns);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(EditorFrame.getInstance(),
                        e.getMessage(),
                        Messages.getString("CVDocValidator.21"), //$NON-NLS-1$
                        JOptionPane.ERROR_MESSAGE);
                return;
            }
            //String valResult = cv.getValidationResult();           
            Document result = XMLUtils.readXMLString(cv.getValidationResult());
            if (result.getRootElement().getChildren("element").size() == 0) { //$NON-NLS-1$
                String message = Messages.getString("CVDocValidator.23"); //$NON-NLS-1$
                JOptionPane.showMessageDialog(EditorFrame.getInstance(), message);
                
            } else {
                validnMessage = Messages.getString("CVDocValidator.24"); //$NON-NLS-1$
                // get the first error element
                Element errEl = result.getRootElement().getChild("element"); //$NON-NLS-1$

                if (errEl != null) {
                    Element pathEl = errEl.getChild("xpath"); //$NON-NLS-1$
                    String pathStr = pathEl.getTextTrim();
                    Element msgEl = errEl.getChild("errmsg"); //$NON-NLS-1$
                }
              
                if (result != null) {
                    if ((dialog != null) && (dialog.isShowing())) {
                        dialog.dispose();
                    }
                    dialog = ValidnResultDialog.getDialog(result
                            .getRootElement(), comp, fc);
                    dialog.show();
                } else {
                    String message = Messages.getString("CVDocValidator.28"); //$NON-NLS-1$
                    JOptionPane.showMessageDialog(EditorFrame.getInstance(),
                            message);
                }
            }

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        
        
    }
    
    public static void validateXMLDocOld(SchemaDocument schemaDoc,Component comp, FormController fc){
        
        File tmpDocFile;
        String validnMessage =""; //$NON-NLS-1$
        CommonValidatorCRT cv = new CommonValidatorCRT();
        try {
           
            if ((schemaDoc.getFile() != null) && (schemaDoc.getFile().exists())) {
                	schemaDoc.saveDocument();
                    tmpDocFile = schemaDoc.getFile();
            
            } else {
                tmpDocFile = File.createTempFile("validnInstance", ".xml"); //$NON-NLS-1$ //$NON-NLS-2$
                tmpDocFile.deleteOnExit();
                XMLUtils.write2XMLFile(schemaDoc.getDocument(), tmpDocFile);
            }
            
           
            
            
            String schemaLocn =""; //$NON-NLS-1$
            String schemaParent=""; //$NON-NLS-1$
            if(schemaDoc.getSchemaController().getSchemaFile() != null){
                schemaLocn = schemaDoc.getSchemaController().getSchemaFile()
                    .getAbsolutePath();
            	
            }else if(schemaDoc.getSchemaController() instanceof GenSchemaController){
                schemaLocn = ((GenSchemaController)schemaDoc.getSchemaController()).getSchemaUrl();
            }
            if(schemaLocn.indexOf("http") == -1){ //$NON-NLS-1$
                int indx = schemaLocn.lastIndexOf(File.separatorChar);
                schemaParent = schemaLocn.substring(0, indx+1);
            }
            //System.out.println(" location original is "  + schemaLocn + " parent is " + schemaParent);
            String[] schemaLocns = { schemaLocn };
            
          // added for getting schema location value from the instance schema location attribute
            // so that multiple schema locations can be loaded
            String schLocnStr = schemaDoc.getDocument().getRootElement().getAttributeValue(XMLUtils.XSI_SchemaLocation, XMLUtils.XSI_Namespace);
            if((schemaDoc.getFile() != null) && (schLocnStr !=null)&& !("".equals(schLocnStr))){                 //$NON-NLS-1$
                StringTokenizer parser = new StringTokenizer(schLocnStr);
                int noOfLocn = parser.countTokens()/2;
                if ((noOfLocn > 0)) {
                    String[] locns = new String[noOfLocn];
                    while (parser.hasMoreTokens()) {
                        parser.nextToken();
                        String schemaLoc = parser.nextToken();
                        locns[--noOfLocn] = schemaLoc;
                        /*
                         * //locns[--noOfLocn] = schemaParent + schemaLoc; //
                         * the above was commented out to get schema locations
                         * that might contain // reference to schema url on web
                         * etc if(schemaLoc.indexOf("http") == -1){
                         * locns[--noOfLocn] = schemaLoc; //locns[--noOfLocn] =
                         * schemaParent + schemaLoc; }else{ locns[--noOfLocn] =
                         * schemaLoc; }
                         */
                        //System.out.println(" location is from tokenizer iss "
                        // + (schemaParent + schemaLoc));
                    }
                    schemaLocns = locns;
                }
                
            }
            try {
                cv.validateInstance(tmpDocFile.getAbsolutePath(), schemaLocns);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(EditorFrame.getInstance(),
                        e.getMessage(),
                        Messages.getString("CVDocValidator.21"), //$NON-NLS-1$
                        JOptionPane.ERROR_MESSAGE);
                return;
            }
            String valResult = cv.getValidationResult();
            //System.out.println(" validation result !!!1");
            //System.out.println(valResult);
            Document result = XMLUtils.readXMLString(cv.getValidationResult());
            if (result.getRootElement().getChildren("element").size() == 0) { //$NON-NLS-1$
                String message = Messages.getString("CVDocValidator.23"); //$NON-NLS-1$
                JOptionPane.showMessageDialog(EditorFrame.getInstance(), message);
                
            } else {
                validnMessage = Messages.getString("CVDocValidator.24"); //$NON-NLS-1$
                // get the first error element
                Element errEl = result.getRootElement().getChild("element"); //$NON-NLS-1$

                if (errEl != null) {
                    Element pathEl = errEl.getChild("xpath"); //$NON-NLS-1$
                    String pathStr = pathEl.getTextTrim();
                    Element msgEl = errEl.getChild("errmsg"); //$NON-NLS-1$
                }
              
                if (result != null) {
                    if ((dialog != null) && (dialog.isShowing())) {
                        dialog.dispose();
                    }
                    dialog = ValidnResultDialog.getDialog(result
                            .getRootElement(), comp, fc);
                    dialog.show();
                } else {
                    String message = Messages.getString("CVDocValidator.28"); //$NON-NLS-1$
                    JOptionPane.showMessageDialog(EditorFrame.getInstance(),
                            message);
                }
            }

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        
        
    }

}

