/**
 *  RELOAD TOOLS
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Phillip Beauvoir
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Phillip Beauvoir
 *  e-mail:   p.beauvoir@bolton.ac.uk
 *
 *  Web:      http://www.reload.ac.uk
 *
 */
package uk.ac.reload.editor.metadata.editor.formPlus.gui;

import java.text.SimpleDateFormat;

import javax.swing.text.DateFormatter;

/**
 * @author Roy P Cherian
 * Set the date and time types for built-in xsd types 
 * 
 */
public class DateTimeTypes {
    
    public static void setDateTimeType(DateFormatter fmt, String type){
        if(type.equals("dateTime")){
            fmt.setFormat(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss"));            
        }else if(type.equals("time")){
            fmt.setFormat(new SimpleDateFormat("hh:mm:ss"));
        }else if(type.equals("date")){
            fmt.setFormat(new SimpleDateFormat("yyyy-MM-dd"));
        }else if(type.equals("gYear")){
            fmt.setFormat(new SimpleDateFormat("yyyy"));
        }else if(type.equals("gYearMonth")){
            fmt.setFormat(new SimpleDateFormat("yyyy-MM"));
        }else if(type.equals("gMonth")){
            fmt.setFormat(new SimpleDateFormat("'--'MM"));
        }else if(type.equals("gDay")){
            fmt.setFormat(new SimpleDateFormat("'---'dd"));
        }/*else if(type.equals("duration")){
            fmt.setFormat(new SimpleDateFormat("'P'"));
        }*/
    }

}
