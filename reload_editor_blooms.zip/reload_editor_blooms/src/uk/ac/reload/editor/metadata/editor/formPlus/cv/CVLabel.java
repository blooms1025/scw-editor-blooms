/**
 *  Content Re-Engineerng Tool
 *
 *  Copyright (c) 2003 Oleg Liber, Bill Olivier, Roy P Cherian
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *  Project Management Contact:
 *
 *  Oleg Liber
 *  Bolton Institute of Higher Education
 *  Deane Road
 *  Bolton BL3 5AB
 *  UK
 *
 *  e-mail:   o.liber@bolton.ac.uk
 *
 *
 *  Technical Contact:
 *
 *  Roy P Cherian
 *  e-mail:   rc3@bolton.ac.uk
 *
 *
 */
package uk.ac.reload.editor.metadata.editor.formPlus.cv;

import java.awt.Color;
import java.awt.Container;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.ToolTipManager;

import org.jdom.Attribute;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.xpath.XPath;

import uk.ac.reload.dweezil.gui.ErrorDialogBox;
import uk.ac.reload.editor.Messages;
import uk.ac.reload.editor.metadata.editor.formPlus.FieldPanel;
import uk.ac.reload.editor.metadata.editor.formPlus.FormController;
import uk.ac.reload.editor.metadata.editor.formPlus.FormPanel;
import uk.ac.reload.editor.metadata.editor.formPlus.FormSubPanel;

/**
 * @author Roy P Cherian
 *
 * TODO
 */
public class CVLabel extends JLabel {
    static String xpathlbl = Messages.getString("CVLabel.0"); //$NON-NLS-1$

    String xpathstr;

    FormController fc;
    static {
        ToolTipManager.sharedInstance().setInitialDelay(0);
    }

    /**
     * 
     * @param xpath
     * @param fc
     */
    public CVLabel(String xpath, FormController fc) {
        super("<html><font size=3 color=blue> <u>" + xpathlbl + xpath //$NON-NLS-1$
                + "<u><br>"); //$NON-NLS-1$
        this.xpathstr = xpath;
        this.fc = fc;
        // TODO Auto-generated constructor stub
        addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                if (evt.getClickCount() == 2) {
                    selectXPathElement(evt);
                }
            }
        });

        setToolTipText(Messages.getString("CVLabel.3")); //$NON-NLS-1$
    }

    /**
     * Highlight in the form view the wrong element from the XPath values shown in the validation
     * result dialog box. In the case of attributes, parent elements will be highlighted
     * @param evt
     */
    protected void selectXPathElement(MouseEvent evt) {
        // TODO Auto-generated method stub
        XPath xpath;
        Element elmnt = null;
        try {
            // the following for getting the element of an attribute so that we can highlight
            // in the form view not possible for attribute !
            if(xpathstr.indexOf("@")!= -1){ //$NON-NLS-1$
                xpathstr = xpathstr.substring(0, xpathstr.indexOf("@")-1); //$NON-NLS-1$
            }
            
            // more kludge - since langstring elements are not displayed as is, go up to parent
            // element and display it
            // xpath like: /*[local-name()='vdex']/*[local-name()='term'][47]/*[local-name()='description']/*[local-name()='langstring']
            // is modified to /*[local-name()='vdex']/*[local-name()='term'][47]/*[local-name()='description'] i.e. move left by 17 chars ??
            
            if(xpathstr.indexOf("langstring")!= -1){ //$NON-NLS-1$
                //System.out.println("XPath is " + xpathstr);
                xpathstr = xpathstr.substring(0, xpathstr.indexOf("langstring")-17); //$NON-NLS-1$
            }            
            // this is another kludge for xpath returned by common validator like - "[.='null']"
            if(xpathstr.indexOf("[. = '")!= -1){ //$NON-NLS-1$
                xpathstr = xpathstr.substring(0, xpathstr.indexOf("[. = '"));                 //$NON-NLS-1$
            }            
            xpath = XPath.newInstance(xpathstr);

            // now let us try to get the failed element
            /**
             * TODO This require tidying up as currently it is assuming that we
             * are getting elements the first selected item, which may be of
             * types: Element, Attribute, Text, CDATA, Comment,
             * ProcessingInstruction, Boolean, Double, String, or null if no
             * item was selected.
             */
            Object node = xpath
                    .selectSingleNode(fc.getMetadata().getDocument());
            if (node != null) {
                if (node instanceof Element) {
                    elmnt = (Element) node;
                } else if (node instanceof Attribute) {
                    Attribute att = (Attribute) node;
                    elmnt = att.getParent();
                }else{
                    ;//System.out.println("Node object is of type " + node.getClass().getName());
                }
            }else{
                ;//System.out.println("Node object is NULLLLLe " );
            }

        } catch (JDOMException e1) {
            // TODO Auto-generated catch block
            ErrorDialogBox.showWarning(Messages.getString("CVLabel.10"), Messages.getString("CVLabel.11") ,e1); //$NON-NLS-1$ //$NON-NLS-2$
            //e1.printStackTrace();
        }
        if (elmnt != null) {
            JComponent panel = fc.getFormComponent(elmnt.hashCode());
            if (panel != null) {
                //TODO
                /**
                 * Here we may have to check the following cases
                 * 1. current panel is sub panel and parent is form panel - following code is ok
                 * 2. current panel is subpanel and parent is also sub panel - do what ?
                 * 3. current panel is field panel (?) and parent is subpanel - do what ?
                 * also what do we do with nested panels hidden - and an element to be highlighted is inside 
                 * one of the nested panels 
                 */
                if (panel instanceof FormSubPanel) {
                    //((FormSubPanel)panel).getHider().showComponent(true);
                    showParentPanels((FormSubPanel) panel);
                    ((FormSubPanel) panel).getPanelLbl().setForeground(
                            Color.RED);
                    //System.out.println("repainging sub panel");
                    Point pt = panel.getLocation();
                    ((FormPanel) fc.getMainPanel()).scrollTo(pt);
                } else if (panel instanceof FieldPanel) {
                    FieldPanel fp = (FieldPanel) panel;
                    //((FormSubPanel)panel.getParent()).getHider().showComponent(true);
                    showParentPanels(((FormSubPanel) panel.getParent()));
                    fp.getLabel().setForeground(Color.RED);
                    fp.repaint();
                    //System.out.println("repainging field panel");
                    Point pt = panel.getLocation();
                    ((FormPanel) fc.getMainPanel()).scrollTo(pt);
                }else{
                    ;//System.out.println("Class for component is " + panel.getClass().getName());
                    ;//System.out.println("IT IS NEITHER PANEL NOT FIELD");
                }

            }else{
                ;//System.out.println("PANEL IS NULL");
            }
        }
    }

    /**
     * shows collapsed panels that are parents of this panel 
     * @param panel
     */

    public void showParentPanels(FormSubPanel panel) {
        panel.getHider().showComponent(true);
        Container parent = panel.getParent();
        if ((parent != null) && (parent instanceof FormSubPanel)) {
            showParentPanels((FormSubPanel) parent);
        } else {
            return;
        }

    }

}