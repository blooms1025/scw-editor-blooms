/* **************************************************************************
    Common Validator -  Performs wellformedness checks of XML file and 
                        validates XML Instances, Schemas and Schematon
                        rules

    File :              Validator.java

Copyright (c) 2004  The Open Group
Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to 
deal in the Software without restriction, including without limitation the
rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
IN THE SOFTWARE.

Dave Scholefield
The Open Group, 
Thames Tower, 
37-45 Station Road,
Reading, 
Berkshire, 
RG1 1LX
United Kingdom 

* *************************************************************************/

package uk.ac.reload.editor.metadata.editor.formPlus.cv;

import java.io.*;

public abstract class Validator {

/** 
The Common Validator component is used by the test system to validate 
content metadata against both XML schema and Schematron files that are used 
to define application profiles. The component is common to several tools in 
the TELCERT project. Within the test system it is used by the resultProcessor 
class of the test handler for the Metadata test suite through a 
validationResult method.
<br>
The component is a container for existing third party XML schema and 
Schematron validation tools (which are freely available).
<br>
The validity checking allows for the validation of the loaded profile against 
the following :
<ul>
<li>Application Profile
<li>Schema 
<li>Schema and Schematron file 
</ul>
<br>
If the validation fails, then the following error information is available 
<ul>
<li>the location in the profile where a conformance violation was found 
(as XPATH) 
for violations of cardinality conditions the actual count and the current borders of the count. 
for violations of type, the object found at this place and the type of the object expected at this place 
in the case of a conditional modification the truth values of all XPATH expressions of conditions applied at the current location together with the conditions imposed by these modifications. At each modified element in the instance document where there is a condition attached the following should be reported for each condition:
<ul>
<li>Result of the evaluation of the XPath expression in the condition
<li>The modification to which this element was attached
<li>The &lt;modification&gt; element referencing this condition
<li>The element found at this place in the instance document
</ul>
<li>profile file not found 
<li>required schema file not found 
<li>required schematron file not found
</ul>
*/
 

/**
Used in Validator constructors to declare that the path being loaded
is the path to a <b>profile</b>.
*/
public static final int PROFILEFILEPATH	= 1;
/**
Used in Validator constructors to declare that the path being loaded
is the path to a modified <b>schema</b>.
*/
public static final int SCHEMAFILEPATH	= 2; 
/**
Used in Validator constructors to declare that the path being loaded
is the path to an XML document.
*/
public static final int XMLDOCFILEPATH	= 3; 

/**
Performs a check on the well formedness of the loaded schema, profile or XML
instance.
@return true if file is well formed, false if not.
*/
public abstract boolean checkFormed(String file)
throws Exception;

/** 
Performs a validation on a XML schema.
@return true if the XML schema is valid, false if not.
*/
public abstract boolean validateSchema(String file)
throws Exception;

/** 
Performs a validation on a set of Schematron Rules 
@return true if rules is valid, false if not.
*/
public abstract boolean validateSchematron(String instancefile, String schematronfile)
throws Exception;

/** 
Performs a validation on an XML instance (not a schema or set of schematron
rules.
@return true if the XML instance is valid, false if not.
*/
public abstract boolean validateInstance(String instancefile)
throws Exception;

/**
Returns the URL of the profile being validated 
@return URL of profile, if no profile is loaded, then NULL is
returned.
*/
public abstract java.net.URL getFullProfileName()
throws Exception;

/**
Returns the path (URI) to the last schema that was used as for validation. 
@return path of schema, if no profile is loaded, then NULL is returned
*/
public abstract java.lang.String getFullSchemaName()
throws Exception;

/**
Returns the name of the profile being validated
@return profile name, returns null if name not available
*/
public abstract java.lang.String getProfileName();


/**
Returns the name of the last schema that were used as for validation.
@return schema name.
*/
public abstract java.lang.String getSchemaName();


/**
Returns the name of the last schematron rules that were used as for validation.
@return Schematron name.
*/
public abstract java.lang.String getSchematronName();

/**
Returns the result of the last validation attempt.
@return last validation result, false if no validation has been performed.
*/
public abstract boolean checkValidationResult();

/**
Returns the result of the last validation attempt.
@return last validation result, false if no validation has been performed.
*/
public abstract boolean checkValidationResult(String str);

/**
validates the existing profile.
@return true if profile validates, false is validation fails.  
*/
public abstract boolean validateProfile(String instancefile, String baseschema, String outputdir)
throws Exception;


/**
Returns details of validation. This will be in XML.
@return result of validation as a string
*/
public abstract java.lang.String getValidationResult()
throws IOException;


}


